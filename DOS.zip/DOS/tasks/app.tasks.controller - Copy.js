/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview startup module for the application 
* @author Badrinarayana G.V
*/

(function () {
    'use strict';

    angular.module('app.tasks.module')
           .controller("TasksController", TasksController)

    TasksController.$inject = ['$scope', '$window', '$document', '$rootScope', '$location', '$translate', '$q', '$timeout', '$sce', 'app.common.httpService', 'app.common.factory.loggerFactory',
                                      'app.common.factory.notificationsFactory', 'app.common.utilitiesFactory', 'app.common.appcontext.factory', 'app.tasks.service'];

    function TasksController($scope, $window, $document, $rootScope, $location, $translate, $q, $timeout, $sce, httpService, logger, notifications, utility, appContext, taskService) {

        var vm = this;
        //soniya
        var title = '';
        $scope.class = "mainPanelContainer";


        function renderTaskSummaryChart(summary) {
            vm.summary = summary;
            vm.donutChartOptions = {
                //title: {
                //    position: "top",
                //    text: "Task Summary"
                //},
                legend: {
                    visible: false,
                  
                },
                

                chartArea: {
                    background: "",
                    margin: 0,
                    padding: 0,
                    height: 230

                },
                seriesDefaults: {
                    type: "donut",
                    size: 15,
                    holeSize: 50,
                    startAngle: 150,
                    height: 230
                },
                series: [{
                    overlay:{
                        gradient:"none"
                    },
                    highlight: {
                        visible:false
                    },
                    name: "Tasks",
                    visibleInLegends: true,
                    data: [{
                        category: "Completed",
                        value: summary.Completed,
                        color: "#bfd99c"
                    }, {
                        category: "Inprogress",
                        value: summary.InProgress,
                        color: "#8bc9f2"
                    }, {
                        category: "Planned",
                        value: summary.Planned,
                        color: "#ffe393"
                    }, {
                        category: "Draft",
                        value: summary.Draft,
                        color: "#c0c0c0"
                    }],


                    labels: {
                        visible: false,
                        background: "transparent",
                        position: "outsideEnd",
                        template: "#= category #: \n #= value#%"
                    }
                }],
                tooltip: {
                    visible: true,
                    template: "#= category # : #= value #"

                }
            }
        }

        vm.hideViewLayoutX = function () {
            vm.showViewLayout = false;
            $('.scrollableTasksCompleteContent').height("99%");
            $('.scrollableTasksCompleteContent').height("100%");

        }




        vm.GetNewTaskHtml = false;

        vm.filter = false;
        vm.LocalizedStrings;
        vm.createTaskOptions = {
            width: "98%",
            height: "90%",
            top: "10px"


        }
        //end


        vm.AssigningDatasource = [];
        vm.selectedtaskstatus = [];
        vm.selectedtaskpriority = [];
        vm.selectedtasktype = [];
        vm.selectedtaskassignee = [];
        vm.showViewLayout = false;
        vm.noTasksAssigned = false;
        vm.NoTasks = false;
        vm.isActivethree = false;
        vm.accordianWorkflow = false;
        vm.ganttLoading = true;
        vm.isCompleteTask = false;
        vm.ViewGroup = true;

        //private variables
        var _taskSummaryCollection = {}; //this will be refreshed during paging, this is per page collection
        var _isDataBoundCompletedOnce = false;

        //below colors are used for task summary
        var _Ganttcolors = {
            Overlap: "#f69791",
            Inprogress: "#8bc9f2",
            Planned: "#ffe393",
            Completed: "#bfd99c",
            Draft: "#c0c0c0"
        };

        vm.RenderingComplete = true;
        vm.shiftDurationExceeded = false;

      
        vm.createNewTask = function () {
            title = vm.LocalizedStrings.Add_New_Task;
            $scope.createTask.title(title);
            $scope.createTask.open();

            $scope.createTask.center();

            $scope.$broadcast("AddTask");


        }



        vm.editTask = function (data) {
            title = vm.LocalizedStrings.Edit_Task;
            $scope.createTask.title(title);
            $scope.createTask.open();
            $scope.createTask.center();
            //vm.ShowUserSpecificTasks = false;
            //vm.showViewLayout = false;
            $scope.$broadcast("EditTask", { data: data });
        }

        vm.commentTask = function (event, taskId, startTime) {
            event.stopImmediatePropagation();
            vm.CommentWindow.title("Add Comment");
            vm.CommentWindow.open();
            vm.CommentWindow.center();

            //remove and add task id
            vm.CommentWindow.wrapper.removeAttr('taskid');
            vm.CommentWindow.wrapper.attr('taskid', taskId);

            vm.TaskId = taskId;
            vm.tasksStrtDateTime = startTime;

            //console.log("this is comment");
            //console.log("TaskId :" + taskId);
        }

        vm.submitTask = function (event, taskId, optonalComment) {
            event.stopImmediatePropagation();
            //console.log("this is submit task");
            //console.log("TaskId :" + taskId);

            var WorkFlowViewModel = {
                TaskId: taskId
            };

            taskService.submitTask(WorkFlowViewModel).then(function (response) {
                if (!utility.isError(response)) {
                    onQuickActionResponse(response, 'Task submitted successfully.');
                }
            });
        }

        vm.startTask = function (event, taskId, optonalComment) {
            event.stopImmediatePropagation();
            vm.isCompleteTask = false;
            vm.actualStartTime = getCurrentDate();
            vm.ScheduleDialogWindow.title("Set Actual Time");
            vm.ScheduleDialogWindow.open();
            vm.ScheduleDialogWindow.center();

            //remove and add task id
            vm.ScheduleDialogWindow.wrapper.removeAttr('taskid');
            vm.ScheduleDialogWindow.wrapper.attr('taskid', taskId);
        }

        vm.CancelSetTime = function () {
            //console.log('this is cancel comment');
            vm.ScheduleDialogWindow.close();
        }

        vm.SaveSetTime = function () {
            
            
            if (vm.isCompleteTask) {
                if (validateDate()) {
                    var WorkFlowViewModel = {
                        TaskId: vm.ScheduleDialogWindow.wrapper.attr('taskid'),
                        StartTime: utility.toUTCDate(vm.actualStartTime, true),
                        EndTime: utility.toUTCDate(vm.actualEndTime, true)
                    };

                    taskService.completeTask(WorkFlowViewModel).then(function (response) {
                        if (!utility.isError(response)) {
                            onQuickActionResponse(response, 'Task completed successfully.');
                        }
                    });
                    vm.ScheduleDialogWindow.close();
                }
            }
            else {
                if (validateDate()) {
                    var WorkFlowViewModel = {
                        TaskId: vm.ScheduleDialogWindow.wrapper.attr('taskid'),
                        StartTime: utility.toUTCDate(vm.actualStartTime, true),
                    };

                    taskService.startTask(WorkFlowViewModel).then(function (response) {
                        if (!utility.isError(response)) {
                            onQuickActionResponse(response, 'Task started successfully.');
                        }
                    });
                    vm.ScheduleDialogWindow.close();
                }
            }
            
        }

        vm.completeTask = function (event, taskId, startTime) {
            event.stopImmediatePropagation();
            vm.isCompleteTask = true;

            vm.actualStartTime = startTime;
            vm.actualEndTime = getCurrentDate();
            vm.ScheduleDialogWindow.title("Set Actual Time");
            vm.ScheduleDialogWindow.open();
            vm.ScheduleDialogWindow.center();

            //remove and add task id
            vm.ScheduleDialogWindow.wrapper.removeAttr('taskid');
            vm.ScheduleDialogWindow.wrapper.attr('taskid', taskId);
        }

        vm.savePercentCompleted = function (event, taskId, percentComplete) {
            event.stopImmediatePropagation();
            //console.log("this is savePercentCompleted");
            //console.log("TaskId :" + taskId);
            //console.log("TaskId :" + percentComplete);

            if (percentComplete < 0 || percentComplete > 100 || percentComplete == undefined) {
                notifications.error(vm.LocalizedStrings.Task_Percent_Invalid, false, true);
                return false;
            }

            var WorkFlowViewModel = {
                TaskId: taskId,
                PercentComplete: percentComplete
            };

            if (percentComplete == 100) {
                taskService.completeTask(WorkFlowViewModel).then(function (response) {
                    if (!utility.isError(response)) {
                        onQuickActionResponse(response, 'Task completed successfully.');
                    }
                });
            }
            else {
                taskService.updatePercentComplete(WorkFlowViewModel).then(function (response) {
                    onQuickActionResponse(response, 'Task progress updated successfully.');
                });
            }
        }

        vm.updateTask = function (event, taskId) {
            event.stopImmediatePropagation();

            title = vm.LocalizedStrings.Edit_Task;
            $scope.createTask.title(title);
            $scope.createTask.open();
            $scope.createTask.center();

            $scope.$broadcast("EditTask", { taskId: taskId });

            //console.log("this is updateTask");
            //console.log("TaskId :" + taskId);

            //call the set tasks 
        }

        vm.deleteTask = function (event, taskId) {
            event.stopImmediatePropagation();

            var WorkFlowViewModel = {
                TaskId: taskId
            };

            taskService.deleteTask(WorkFlowViewModel).then(function (response) {
                notifications.success('Task Deleted Successfully.', false, true);
                vm.showViewLayout = false;
                vm.ShowUserSpecificTasks = false;
                getTaskSummary();
            });
        }

        vm.requestForCarryOver = function (event, taskId) {

            event.stopImmediatePropagation();
            //console.log("this is requestForCarryOver");
            //console.log("TaskId :" + taskId);

            var WorkFlowViewModel = {
                TaskId: taskId
            };

            taskService.carryForwardTask(WorkFlowViewModel).then(function (response) {
                onQuickActionResponse(response, 'Carry Over Requested Successfully.');
            });
        }

        vm.applyFilters = function () {
            $scope.class = "mainPanelContainer";
            vm.ShowUserSpecificTasks = false;
            vm.noTasksAssigned = false;
            vm.showViewLayout = false;
            saveFiltersinAppContext();
            displayAppliedFilters();
            getTaskSummary();
        }

        vm.CancelComment = function () {
            //console.log('this is cancel comment');
            vm.CommentWindow.close();
        }

        vm.SaveComment = function () {
            //console.log('this is save comment');
            vm.CommentWindow.close();
            var WorkFlowViewModel = {
                TaskId: vm.CommentWindow.wrapper.attr('taskid'),
                PlainComment: $('<div>' + vm.Comments + '</div>').text(),
                RichComment: vm.Comments
            };

            taskService.addComment(WorkFlowViewModel).then(function (response) {
                if (!utility.isError(response)) {
                    if (response.Results && response.Results.length > 0) {
                        vm.Comments = "";
                        if (response.Results[0].Status == "False") {
                            notifications.error(response.Results[0].Message, false, true);
                        }
                        else {
                            //refresh workflow history
                            activecomments();
                            notifications.success("Comment added successfully", false, true);
                        }
                    }
                }
            });
        }

        vm.activeButtonthree = function () {
            vm.isActivethree = !vm.isActivethree;
        }

        vm.toggleAccordianWorkflow = function () {
            vm.accordianWorkflow = vm.accordianWorkflow === false ? true : false;
            if (vm.accordianWorkflow == true) {
                activecomments();
            }
        };

        vm.refreshWorkflow = function (event) {
            event.stopImmediatePropagation();
            vm.accordianWorkflow = true;
            activecomments();
        };

        vm.filterAsigneeList = function () {
            var viewSelected = '';
            var filteredAssigningDatasource = '';
            viewSelected = vm.ViewPerson ? "Person" : "";
            if (viewSelected) {
                viewSelected += ",";
            }

            viewSelected += vm.ViewGroup ? "Group" : "";

            if (viewSelected.indexOf(",") > -1)
                viewSelected = viewSelected.substring(0, viewSelected.length);
            if (viewSelected == "Person,") {
                viewSelected = viewSelected.substring(0, viewSelected.length - 1);
            }
            if (viewSelected.includes("Person") && !viewSelected.includes("Group")) {
                filteredAssigningDatasource = vm.AssigningDatasource.filter(function (el) {
                    return el.IsGroup == false;
                });
            }
            else if (!viewSelected.includes("Person") && viewSelected.includes("Group")) {
                filteredAssigningDatasource = vm.AssigningDatasource.filter(function (el) {
                    return el.IsGroup == true;
                });
            }
            else {
                filteredAssigningDatasource = vm.AssigningDatasource;
            }
            vm.filterAssigneeOptions =
                        {
                            placeholder: "Select Type",
                            dataTextField: "DisplayName",
                            dataValueField: "UserPrincipal",
                            valuePrimitive: true,
                            autoBind: true,
                            dataSource: filteredAssigningDatasource,
                            filter: "contains"
                        }
        }

        function validateDate() {
            var startDate = kendo.parseDate(vm.actualStartTime, 'g');
            if (Object.prototype.toString.call(startDate) === "[object Date]") {
                if (isNaN(startDate.getTime())) {  // d.valueOf() could also work
                    notifications.error(vm.LocalizedStrings.actualStartTime_Invalid, false, true);
                    return false;
                }
            }
            else {
                notifications.error(vm.LocalizedStrings.actualStartTime_Invalid, false, true);
                return false;
            }

            if (vm.isCompleteTask) {
                var endDate = kendo.parseDate(vm.actualEndTime, 'g');
                if (Object.prototype.toString.call(endDate) === "[object Date]") {
                    if (isNaN(endDate.getTime())) {  // d.valueOf() could also work
                        notifications.error(vm.LocalizedStrings.actualEndTime_Invalid, false, true);
                        return false;
                    }
                }
                else {
                    notifications.error(vm.LocalizedStrings.actualEndTime_Invalid, false, true);
                    return false;
                }
            
                if (!vm.actualStartTime || !vm.actualEndTime) {
                    notifications.error(vm.LocalizedStrings.StartTime_EndTime_Empty, false, true);
                    return false;
                }
                if (vm.actualStartTime && vm.actualEndTime) {
                    //validations for end date before  start date                
                    if (kendo.parseDate(vm.actualStartTime) >= kendo.parseDate(vm.actualEndTime)) {
                        notifications.error(vm.LocalizedStrings.StartTime_exceeds_EndTime, false, true);
                        return false;
                    };
                }
            }
            return true;
        }

        function activecomments() {
            var taskId = vm.TaskId;
            var starttime = vm.tasksStrtDateTime;
            taskService.getAllComments(taskId, starttime)
            .then(function (data) {
                if (!utility.isError(data)) { // to handle our custom errors
                    vm.AllComments = data.TaskWorkflowHistoryCollection;

                    vm.NoWorkFlowHistory = false;

                    for (var i = 0; i < vm.AllComments.length; i++) {
                        vm.AllComments[i].ActionTime = utility.toLocalDate(vm.AllComments[i].ActionTime);
                        vm.AllComments[i].Comment = $sce.trustAsHtml(vm.AllComments[i].Comment);
                    }
                }
            });
        }

        function onQuickActionResponse(response, successMessage) {
            if (!utility.isError(response)) {
                if (response.Results && response.Results.length > 0) {
                    if (response.Results[0].Status == "False") {
                        notifications.error(response.Results[0].Message, false, true);
                    }
                    else {
                        notifications.success(successMessage, false, true);
                        vm.ShowUserSpecificTasks = false;
                        vm.showViewLayout = false;
                        getTaskSummary();
                    }
                }
            }
        }

        function saveFiltersinAppContext() {

            vm.selectedtaskstatusString = vm.selectedtaskstatus.toString();

            var filters = {
                status: vm.selectedtaskstatus,
                priorities: vm.selectedtaskpriority,
                type: vm.selectedtasktype,
                assignees: vm.taskAssignee.dataItems().toString(),
                context: getSelectedView()
            };

            appContext.setFilters(filters);
        }

        function getCurrentDate() {
            var newDate = new Date();

            var sMonth = padValue(newDate.getMonth() + 1);
            var sDay = padValue(newDate.getDate());
            var sYear = newDate.getFullYear();
            var sHour = newDate.getHours();
            var sMinute = padValue(newDate.getMinutes());
            var sAMPM = "AM";

            var iHourCheck = parseInt(sHour);

            if (iHourCheck > 12) {
                sAMPM = "PM";
                sHour = iHourCheck - 12;
            }
            else if (iHourCheck === 0) {
                sHour = "12";
            }

            sHour = padValue(sHour);

            return sMonth + "/" + sDay + "/" + sYear + " " + sHour + ":" + sMinute + " " + sAMPM;
        }

        function padValue(value) {
            return (value < 10) ? "0" + value : value;
        }

        // JavaScript source code
        function displayAppliedFilters() {

            vm.selectedtaskstatusString = "";
            vm.selectedtaskpriorityString = "";
            vm.selectedtasktypeString = "";
            vm.selectedtaskassigneeString = "";
            vm.selectedviewString = "";

            var taskstatusDataItems = vm.taskStatus.dataItems();
            var priorityDataItems = vm.taskPriority.dataItems();
            var typeDataItems = vm.taskType.dataItems();
            var assigneeDataItems = vm.taskAssignee.dataItems();

            for (var i = 0; i < taskstatusDataItems.length; i++) {
                vm.selectedtaskstatusString += taskstatusDataItems[i].DisplayName + ",";
            }
            for (var i = 0; i < priorityDataItems.length; i++) {
                vm.selectedtasktypeString += priorityDataItems[i].DisplayName + ",";
            }
            for (var i = 0; i < typeDataItems.length; i++) {
                vm.selectedtaskpriorityString += typeDataItems[i].DisplayName + ",";
            }
            for (var i = 0; i < assigneeDataItems.length; i++) {
                vm.selectedtaskassigneeString += assigneeDataItems[i].DisplayName + ",";
            }
            if (vm.selectedtaskstatusString) {
                vm.selectedtaskstatusString = vm.selectedtaskstatusString.substring(0, vm.selectedtaskstatusString.length - 1);
            }
            if (vm.selectedtaskpriorityString) {
                vm.selectedtaskpriorityString = vm.selectedtaskpriorityString.substring(0, vm.selectedtaskpriorityString.length - 1);
            }
            if (vm.selectedtasktypeString) {
                vm.selectedtasktypeString = vm.selectedtasktypeString.substring(0, vm.selectedtasktypeString.length - 1);
            }
            if (vm.selectedtaskassigneeString) {
                vm.selectedtaskassigneeString = vm.selectedtaskassigneeString.substring(0, vm.selectedtaskassigneeString.length - 1);
            }

            vm.selectedviewString = getSelectedView();

            if (vm.selectedtaskstatusString == "" && vm.selectedtaskpriorityString == "" && vm.selectedtasktypeString == "" && vm.selectedviewString == "" && vm.selectedtaskassigneeString == "") {
                vm.filtersApplied = false;
            }
            else {
                vm.filtersApplied = true;
            }
        }

        vm.getFilterWidth = function (filtersCount) {
            return 100 / filtersCount;
        }

        function getSelectedView() {
            var Viewselected = '';
            Viewselected = vm.ViewPerson ? "Person" : "";
            if (Viewselected) {
                Viewselected += ",";
            }

            Viewselected += vm.ViewGroup ? "Group" : "";

            if (Viewselected.indexOf(",") > -1)
                Viewselected = Viewselected.substring(0, Viewselected.length);
            if (Viewselected == "Person,") {
                Viewselected = Viewselected.substring(0, Viewselected.length - 1);
            }

            return Viewselected;
        }


        vm.clearAllFilters = function () {
            $scope.class = "mainPanelContainer";
            vm.ShowUserSpecificTasks = false;
            vm.showViewLayout = false;
            vm.noTasksAssigned = false;
            vm.filtersApplied = false;
            vm.selectedtaskstatus = [];
            vm.selectedtaskpriority = [];
            vm.selectedtasktype = [];
            vm.selectedtaskassignee = [];
            vm.ViewPerson = "";
            vm.ViewGroup = "";
            getTaskSummary();
        }

        $scope.$on("SHIFT_CHANGED", function () {
            vm.showViewLayout = false;
            vm.ShowUserSpecificTasks = false;
            vm.noTasksAssigned = false;
            $scope.class = "mainPanelContainer";

            //tasks related calls
            getTaskSummary();
        });

        $scope.$on("ASSET_CHANGED", function () {
            //tasks related calls
            $scope.class = "mainPanelContainer";
            initialize();
        });

        $scope.$on("kendoWidgetCreated", function (ev, widget) {
            if (widget == vm.gantt) {

                //not differentiating work hours and non hours
                $(".k-gantt-columns").find("td").removeClass("k-nonwork-hour");
                $(".k-grid-header").find("th").removeClass("k-nonwork-hour");

                //by default collapsing all the users in gantt chart
                //vm.gantt.dataSource.view().forEach(function (e) {
                //    e.expanded = false;
                //});
                //vm.gantt.refresh();

                //hide expand and collapse
                $(".k-gantt-layout").find(".k-icon.k-i-expand").hide();

                //remove the splitter functionality
                //$(".k-gantt").find(".k-gantt-layout").removeClass("k-splitbar k-state-default k-splitbar-horizontal k-splitbar-draggable-horizontal");

                //$timeout(function () {
                //    vm.RenderingComplete = true;
                //}, 1000);

                ////console.log("kendoWidgetCreated");
                //$("#divTaskContainer").show();
            }

            if (widget.$angular_scope.CommentWindow && ev.currentScope.vm.CommentWindow == undefined) {
                ev.currentScope.vm.CommentWindow = widget;
            }

            if (widget.$angular_scope.ScheduleDialogWindow && ev.currentScope.vm.ScheduleDialogWindow == undefined) {
                ev.currentScope.vm.ScheduleDialogWindow = widget;
            }

        });


        $scope.$on("kendoRendered", function (ev, widget) {
            //$timeout(function () {
            //    vm.RenderingComplete = true;
            //}, 1000);

            //console.log("kendoRendered");
            //$("#divTaskContainer").show();
        });

        $scope.$on("TaskCancel", function () {
            $scope.createTask.close();
        });

        $scope.$on("TaskSaved", function () {
            $scope.createTask.close();
            vm.showViewLayout = false;
            vm.ShowUserSpecificTasks = false;
            getTaskSummary();
        });

        $scope.$on("UpdateConfigData", function () {
            getTaskConfigData();
        });

        $scope.$watch("vm.TaskSummary", function (newValue, oldValue, scope) {
            //http://www.telerik.com/forums/rendering-with-angularjs-directive-ng-hide
            //if (newValue)
            //    $("#divGanttChart").show();
            //else
            //    $("#divGanttChart").hide();
        });

        //$scope.$watchGroup(['vm.selectedtaskassignee', 'vm.selectedtasktype', 'vm.selectedtaskpriority', 'vm.selectedtaskstatus'], function (newValues, oldValues, scope) {
        //    vm.oneOrMoreFiltersChanged = true;
        //});

        $scope.$on("Intuition.ActionBarItemClicked", actionbarClicked);

        function actionbarClicked(event, actionText) {
            if (actionText == "TASKS_SAVE") {
                $scope.$apply(function () {
                    vm.saveTaskDetails();
                });
            }
            else if (actionText == "TASK_FILTER") {
                getUsers();
                $scope.$apply(function () {
                    vm.filter = !vm.filter;
                    if (vm.filter) {

                        $scope.class = "widthoverFhide";
                    }

                    else {
                        vm.filter = false;
                        $scope.class = "mainPanelContainer";
                    }


                });
            }
        }
        //end     







        function getAllTaskSummary(assignee) {

            //check grid view or gantt view. if gantt view assignees should be from gantt
            //else it should be from filters

            //below section is only for gantt
            var assignees = [];
            var allAssignees = vm.taskDatasource;
            for (var i = 0; i < allAssignees.length; i++) {
                if (allAssignees[i].title == assignee) {
                    var assignee = {}
                    if (allAssignees[i].IsPerson) {
                        assignee = {
                            DisplayName: allAssignees[i].title,
                            IsGroup: !allAssignees[i].IsPerson,
                            UserPrincipal: allAssignees[i].context
                        };
                    }
                    else {
                        assignee = {
                            EID: allAssignees[i].context,
                            IsGroup: !allAssignees[i].IsPerson,
                            UserPrincipal: allAssignees[i].title
                        };
                    }

                    assignees.push(assignee);
                    break;
                }
            }

            var TaskGridViewModel = {
                AssetName: appContext.getAssetName(),
                Hierarchy: appContext.getHierarchyName(),
                StartTime: appContext.getStartTime(),
                EndTime: appContext.getEndTime(),
                Priorities: vm.selectedtaskpriority,
                Statuses: vm.selectedtaskstatus,
                Types: vm.selectedtasktype,
                //GroupBy: getSelectedView()
                Assignees: assignees
            };

            taskService.getAllTaskSummary(TaskGridViewModel).then(function (response) {
                if (!utility.isError(response)) {
                    if (response.AllTasksSummaryByStatus && response.AllTasksSummaryByStatus.length > 0) {

                        var summryByStatus = response.AllTasksSummaryByStatus;
                        var summary = {
                            Draft: 0,
                            InProgress: 0,
                            Planned: 0,
                            Completed: 0
                        };
                        for (var i = 0; i < summryByStatus.length; i++) {
                            switch (summryByStatus[i].Status) {
                                case "Draft":
                                    summary.Draft = summryByStatus[i].Count;
                                    break;
                                case "InProgress":
                                    summary.InProgress = summryByStatus[i].Count;
                                    break;
                                case "Planned":
                                    summary.Planned = summryByStatus[i].Count;
                                    break;
                                case "Completed":
                                    summary.Completed = summryByStatus[i].Count;
                                    break;
                            }
                        }
                        renderTaskSummaryChart(summary);
                    }
                }
            });
        }


        function initialize() {
            vm.showViewLayout = false;
            vm.ShowUserSpecificTasks = false;
            vm.noTasksAssigned = false;
            getLocalizedMessages();
            resetUserandConfigData();
            getTaskConfigData();
            $scope.createTask.close();
            getTaskSummary();
            initializeKendoEditorWidgetOptionsForPopup();
        }

        function initializeAssignee(response) {
            vm.AssigningDatasource = response;

            vm.filterAssigneeOptions =
                      {
                          placeholder: "Select Type",
                          dataTextField: "DisplayName",
                          dataValueField: "UserPrincipal",
                          valuePrimitive: true,
                          autoBind: true,
                          dataSource: vm.AssigningDatasource,
                          filter: "contains",
                          clearButton: true
                      }
        }

        //Soniya
        function getLocalizedMessages() {
            $translate(['Add_New_Task', 'Edit_Task', 'Task_Percent_Invalid', 'StartTime_EndTime_Empty', 'StartTime_exceeds_EndTime',
            'actualStartTime_Invalid', 'actualEndTime_Invalid'])
                    .then(function (translations) {
                        vm.LocalizedStrings = translations;
                    });
        }
        //end

        function resetUserandConfigData() {
            appContext.setUsers(null);
            appContext.setConfigData(null);
        }

        // service calls
        function getTaskConfigData() {
            taskService.getTaskConfigData(appContext.getAssetName())
            .then(function (response) {
                if (!utility.isError(response)) {
                    if (response != undefined) {

                        appContext.setConfigData(response);

                        vm.StatusDatasource = response.ConfigData.States;

                        vm.filterStatusOptions = {
                            placeholder: "Select Status",
                            dataTextField: "DisplayName",
                            dataValueField: "Name",
                            valuePrimitive: true,
                            autoBind: true,
                            dataSource: vm.StatusDatasource,
                            filter: "contains"

                        };

                        vm.PriorityDatasource = response.ConfigData.TaskPriorities;

                        vm.filterPriorityOptions =
                            {
                                placeholder: "Select Priority",
                                dataTextField: "DisplayName",
                                dataValueField: "Order",
                                valuePrimitive: true,
                                autoBind: true,
                                dataSource: vm.PriorityDatasource,
                                filter: "contains"
                            }


                        vm.TypeDatasource = response.ConfigData.TaskTypes;

                        vm.filterTypeOptions =
                            {
                                placeholder: "Select Type",
                                dataTextField: "DisplayName",
                                dataValueField: "Name",
                                valuePrimitive: true,
                                autoBind: true,
                                dataSource: vm.TypeDatasource,
                                filter: "contains"
                            }
                    }
                }
            });
        }

        function getUsers() {
            var deferred = $q.defer();
            if (appContext.getUsers() != null) {
                initializeAssignee(appContext.getUsers());
                deferred.resolve(true);
            }
            else {
                taskService.getUsers(appContext.getAssetName())
                .then(function (response) {
                    if (!utility.isError(response)) {
                        appContext.setUsers(response);
                        initializeAssignee(response);
                        deferred.resolve(true);
                    }
                    else {
                        deferred.resolve(false);
                    }
                });
            }
            return deferred.promise;
        }

        function getTaskSummary() {
            //display gantt maximum for a week
            var shiftDurationInDays = ((utility.convertDateStringtoDate(appContext.getEndTime()) - utility.convertDateStringtoDate(appContext.getStartTime())) / (60 * 60 * 1000)) / 24;
            if (shiftDurationInDays <= 7) {
                vm.shiftDurationExceeded = false;
                var pageNumber = 1;
                var taskSummaryFilter = {
                    "StartTime": appContext.getStartTime(),
                    "EndTime": appContext.getEndTime(),
                    "AssetName": appContext.getAssetName(),
                    "PageSize": 0,
                    "PageNumber": 0,
                    "Hierarchy": appContext.getHierarchyName(),
                    "AssignedTo": vm.selectedtaskassignee.length == 0 ? vm.selectedtaskassignee : vm.taskAssignee.dataItems(),
                    "Priorities": vm.selectedtaskpriority,
                    "Statuses": vm.selectedtaskstatus,
                    "Types": vm.selectedtasktype,
                    "View": getSelectedView()
                };

                taskService.getGrouppedTasks(taskSummaryFilter)
                           .then(function (dataResult) {
                               if (!utility.isError(dataResult)) {
                                   vm.taskDatasource = dataResult;
                                   if (dataResult.length > 0) {
                                       vm.NoTasks = false;
                                       renderTaskSummaryGanttChart(dataResult);
                                       $("#divGanttChart").show();
                                       Intuition.ActionBar.ShowIcon("TaskFilters");
                                   }
                                   else {
                                     //  Intuition.ActionBar.HideIcon("TaskFilters");
                                       vm.NoTasks = true;
                                       $("#divGanttChart").hide();

                                   }


                                   vm.ganttLoading = false;
                                   vm.filter = false;
                               }
                           });
            }
            else {
                $scope.$apply(function () {
                    vm.shiftDurationExceeded = true;
                    $("#divGanttChart").hide();
                  //  Intuition.ActionBar.HideIcon("TaskFilters");
                });
            }
        }

        function initializeKendoEditorWidgetOptionsForPopup() {
            vm.popupOptions = {
                tools: [
                             "bold",
                             "italic",
                             "underline",
                             "strikethrough",
                             "foreColor",
                             "backColor",
                             "cleanFormatting",
                             "justifyLeft",
                             "justifyCenter",
                             "justifyRight",
                             "justifyFull",
                             "insertUnorderedList",
                             "insertOrderedList",
                             "indent",
                             "fontSize",
                             {
                                 name: "fontName",
                                 items: [
                                              { text: "Andale Mono", value: "Andale Mono" },
                                              { text: "Arial", value: "Arial" },
                                              { text: "Arial Black", value: "Arial Black" },
                                              { text: "Comic Sans MS", value: "Comic Sans MS" },
                                              { text: "Courier New", value: "Courier New" },
                                              { text: "Garamond", value: "Garamond, serif" },
                                              { text: "Georgia", value: "Georgia" },
                                              { text: "Impact", value: "Impact" },
                                              { text: "Times New Roman", value: "Times New Roman" },
                                              { text: "Trebuchet MS", value: "Trebuchet MS" },
                                              { text: "Verdana", value: "Verdana" },
                                              { text: "Webdings", value: "Webdings" }
                                 ]
                             }
                ]
            }
        }

        var usersCount = 10;
        var tasksPerUser = 100;
        //var taskDataSourceNight = [];

        //for (var i = 0; i < usersCount; i++) {
        //    var user = { id: i, orderId: 0, parentId: null, title: "user_" + i + "(" + tasksPerUser + ")", summary: true, expanded: true, start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:00"), percentcomplete: 0, priority: "High" };
        //    taskDataSourceNight.push(user);
        //    for (var j = 1000; j < 1000 + tasksPerUser; j++) {
        //        var orderId = 0;
        //        if (j % 2 == 0)
        //            var task = { id: "user_" + i + "_" + j, orderId: orderId, parentId: i, title: "Task_" + i + "_" + j, start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:00"), percentcomplete: 0, priority: "High" }
        //        else
        //            var task = { id: "user_" + i + "_" + j, orderId: orderId, parentId: i, title: "Task_" + i + "_" + j, start: new Date("2017/2/23 22:30"), end: new Date("2017/2/23 23:30"), percentcomplete: 0, priority: "High" }
        //        orderId++;
        //        taskDataSourceNight.push(task);
        //    }
        //}

        var taskDataSourceNight = [

        //{ id: 1, orderId: 0, parentId: null, title: "Raja", summary: true, expanded: true, start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:00") },
        //{ id: 2, orderId: 0, parentId: 1, title: "Task1", start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:00") },
        //{ id: 3, orderId: 1, parentId: 1, title: "Task2", start: new Date("2017/2/23 22:30"), end: new Date("2017/2/23 23:30"), summary: true, expanded: true },
        //        { id: 31, orderId: 0, parentId: 3, title: "Sub Task 31", start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:30") },
        //        { id: 32, orderId: 1, parentId: 3, title: "Sub Task 32", start: new Date("2017/2/23 22:30"), end: new Date("2017/2/23 23:40") },
        //        { id: 33, orderId: 2, parentId: 3, title: "Sub Task 33", start: new Date("2017/2/23 23:30"), end: new Date("2017/2/23 23:55") },
        //{ id: 4, orderId: 2, parentId: 1, title: "Task3", start: new Date("2017/2/23 23:30"), end: new Date("2017/2/24 00:30") },
        //{ id: 5, orderId: 3, parentId: 1, title: "Task3", start: new Date("2017/2/24 1:30"), end: new Date("2017/2/24 3:30") },
        //{ id: 6, orderId: 4, parentId: 1, title: "Task4", start: new Date("2017/2/24 6:30"), end: new Date("2017/2/24 7:30"), summary: true, expanded: true },
        //        { id: 61, orderId: 0, parentId: 6, title: "Sub Task 61", start: new Date("2017/2/24 2:30"), end: new Date("2017/2/24 3:30") },
        //        { id: 62, orderId: 1, parentId: 6, title: "Sub Task 62", start: new Date("2017/2/24 3:30"), end: new Date("2017/2/24 4:30") },
        //        { id: 63, orderId: 2, parentId: 6, title: "Sub Task 63", start: new Date("2017/2/24 4:30"), end: new Date("2017/2/24 5:30") },

        { id: 7, orderId: 0, parentId: null, title: "User1", summary: true, expanded: true, start: new Date("2017/2/24 22:00"), end: new Date("2017/2/24 23:00"), percentcomplete: 0, priority: "High" },
        { id: 8, orderId: 0, parentId: 7, title: "Task1", start: new Date("2017/2/24 10:00"), end: new Date("2017/2/24 12:00"), percentcomplete: 0, priority: "Medium" },
        { id: 9, orderId: 1, parentId: 7, title: "Task2", start: new Date("2017/2/24 12:30"), end: new Date("2017/2/24 13:30"), percentcomplete: 0.10, priority: "High" },
        //{ id: 10, orderId: 2, parentId: 7, title: "Task3", start: new Date("2017/2/23 23:35"), end: new Date("2017/2/24 00:30"), percentcomplete: 1, priority: "low" },
        //{ id: 11, orderId: 3, parentId: 7, title: "Task4", start: new Date("2017/2/24 1:30"), end: new Date("2017/2/24 3:30"), percentcomplete: 0, priority: "High" },
        //{ id: 12, orderId: 4, parentId: 7, title: "Task5", start: new Date("2017/2/24 6:30"), end: new Date("2017/2/24 7:30"), percentcomplete: 0, priority: "Medium" },

          { id: 13, orderId: 0, parentId: null, title: "User2", summary: true, expanded: true, start: new Date("2017/2/24 22:15"), end: new Date("2017/2/24 23:00"), percentcomplete: 0, priority: "Medium" },
        { id: 14, orderId: 0, parentId: 13, title: "Task1", start: new Date("2017/2/24 10:10"), end: new Date("2017/2/24 13:10"), percentcomplete: 0, priority: "Medium" },
        { id: 15, orderId: 1, parentId: 13, title: "Task2", start: new Date("2017/2/24 11:40"), end: new Date("2017/2/24 13:20"), percentcomplete: 0, priority: "Medium" },
        //{ id: 16, orderId: 2, parentId: 13, title: "Task3", start: new Date("2017/2/23 23:45"), end: new Date("2017/2/24 00:45"), percentcomplete: 0, priority: "Medium" },
        //{ id: 17, orderId: 3, parentId: 13, title: "Task3", start: new Date("2017/2/24 1:50"), end: new Date("2017/2/24 3:50"), percentcomplete: 0, priority: "Medium" },
        //{ id: 18, orderId: 4, parentId: 13, title: "Task4", start: new Date("2017/2/24 6:25"), end: new Date("2017/2/24 7:10"), percentcomplete: 0, priority: "Medium" }

        ];


        var taskDataSourceDay = [

       //{ id: 1, orderId: 0, parentId: null, title: "Raja", summary: true, expanded: true, start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:00") },
       //{ id: 2, orderId: 0, parentId: 1, title: "Task1", start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:00") },
       //{ id: 3, orderId: 1, parentId: 1, title: "Task2", start: new Date("2017/2/23 22:30"), end: new Date("2017/2/23 23:30"), summary: true, expanded: true },
       //        { id: 31, orderId: 0, parentId: 3, title: "Sub Task 31", start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:30") },
       //        { id: 32, orderId: 1, parentId: 3, title: "Sub Task 32", start: new Date("2017/2/23 22:30"), end: new Date("2017/2/23 23:40") },
       //        { id: 33, orderId: 2, parentId: 3, title: "Sub Task 33", start: new Date("2017/2/23 23:30"), end: new Date("2017/2/23 23:55") },
       //{ id: 4, orderId: 2, parentId: 1, title: "Task3", start: new Date("2017/2/23 23:30"), end: new Date("2017/2/24 00:30") },
       //{ id: 5, orderId: 3, parentId: 1, title: "Task3", start: new Date("2017/2/24 1:30"), end: new Date("2017/2/24 3:30") },
       //{ id: 6, orderId: 4, parentId: 1, title: "Task4", start: new Date("2017/2/24 6:30"), end: new Date("2017/2/24 7:30"), summary: true, expanded: true },
       //        { id: 61, orderId: 0, parentId: 6, title: "Sub Task 61", start: new Date("2017/2/24 2:30"), end: new Date("2017/2/24 3:30") },
       //        { id: 62, orderId: 1, parentId: 6, title: "Sub Task 62", start: new Date("2017/2/24 3:30"), end: new Date("2017/2/24 4:30") },
       //        { id: 63, orderId: 2, parentId: 6, title: "Sub Task 63", start: new Date("2017/2/24 4:30"), end: new Date("2017/2/24 5:30") },

       { id: 7, orderId: 0, parentId: null, title: "User3", summary: true, expanded: true, start: new Date("2017/2/23 22:00"), end: new Date("2017/2/23 23:00"), percentcomplete: 0, priority: "High" },
       { id: 8, orderId: 0, parentId: 7, title: "Task1", start: new Date("2017/2/23 18:30"), end: new Date("2017/2/23 23:00"), percentcomplete: 0, priority: "Medium" },
       //{ id: 9, orderId: 1, parentId: 7, title: "Task2", start: new Date("2017/2/23 22:30"), end: new Date("2017/2/23 23:30"), percentcomplete: 0.10, priority: "High" },
       //{ id: 10, orderId: 2, parentId: 7, title: "Task3", start: new Date("2017/2/23 23:35"), end: new Date("2017/2/24 00:30"), percentcomplete: 1, priority: "low" },
       //{ id: 11, orderId: 3, parentId: 7, title: "Task4", start: new Date("2017/2/24 1:30"), end: new Date("2017/2/24 3:30"), percentcomplete: 0, priority: "High" },
       //{ id: 12, orderId: 4, parentId: 7, title: "Task5", start: new Date("2017/2/24 6:30"), end: new Date("2017/2/24 7:30"), percentcomplete: 0, priority: "Medium" },

         { id: 13, orderId: 0, parentId: null, title: "User4", summary: true, expanded: true, start: new Date("2017/2/23 22:15"), end: new Date("2017/2/23 23:00"), percentcomplete: 0, priority: "Medium" },
       { id: 14, orderId: 0, parentId: 13, title: "Task1", start: new Date("2017/2/23 22:10"), end: new Date("2017/2/23 23:10"), percentcomplete: 0, priority: "Medium" },
       { id: 15, orderId: 1, parentId: 13, title: "Task2", start: new Date("2017/2/23 22:40"), end: new Date("2017/2/23 23:20"), percentcomplete: 0, priority: "Medium" },
       //{ id: 16, orderId: 2, parentId: 13, title: "Task3", start: new Date("2017/2/23 23:45"), end: new Date("2017/2/24 00:45"), percentcomplete: 0, priority: "Medium" },
       //{ id: 17, orderId: 3, parentId: 13, title: "Task3", start: new Date("2017/2/24 1:50"), end: new Date("2017/2/24 3:50"), percentcomplete: 0, priority: "Medium" },
       //{ id: 18, orderId: 4, parentId: 13, title: "Task4", start: new Date("2017/2/24 6:25"), end: new Date("2017/2/24 7:10"), percentcomplete: 0, priority: "Medium" }

        ];

        //renderTaskSummaryGanttChart(taskDataSourceDay);

        function renderTaskSummaryGanttChart(dataSource) {

            //console.log(dataSource);

            _resetTaskSummaryGanttChart();

            appContext.setGanttHourSpan(_getGanttHourSpan());

            for (var i = 0; i < dataSource.length; i++) {
                dataSource[i].start = kendo.parseDate(utility.toLocalDate(dataSource[i].start));
                dataSource[i].end = kendo.parseDate(utility.toLocalDate(dataSource[i].end));
            }

            var gantDataSource = new kendo.data.GanttDataSource({
                data: dataSource
            });

            //console.log(gantDataSource);

            vm.ganttOptions = {
                //autoBind: true,
                dataSource: gantDataSource,
                columnResizeHandleWidth: 15,
                taskTemplate: $("#task-template").html(),
                hourSpan: appContext.getGanttHourSpan(),
                tooltip: {
                    visible: false,
                    //template: $("#tasktooltip-template").html()
                },
                toolbar: [
                        //{ name: "Next" },
                        //{ name: "Prev" }
                ],
                height: 500,
                listWidth: 200,
                currentTimeMarker: {
                    updateInterval: 100 // will update current time for every configured milliseconds
                },
                views: [
                    {
                        type: "day",
                        selected: true,
                        slotSize: 120,
                        dayHeaderTemplate: kendo.template("#=kendo.toString(start, 'd')#"),
                        range: {
                            start: kendo.parseDate(utility.toLocalDate(appContext.getStartTime())),
                            end: kendo.parseDate(_getGanttEndTime(appContext.getEndTime()))
                        }
                    }
                ],
                columns: [
                    { field: "title", title: "Task Assignees", editable: false }
                ],
                showWorkHours: false,
                showWorkDays: false,
                editable: {
                    resize: false,
                    create: false,
                    confirmation: false,
                    dependencyCreate: false,
                    dependencyDestroy: false,
                    dragPercentComplete: false,
                    destroy: false,
                    move: false,
                    reorder: false,
                    update: false
                },
                add: addTask,
                edit: editTask,
                remove: removeTask,
                cancel: cancelTask,
                save: updateTask,
                change: selectionChange,
                moveStart: moveStart,
                move: moveTask,
                moveEnd: moveEnd,
                dataBound: dataBound
            };

            // _attachGanttEvents();
        }



        function addTask(e) {
            //console.log("Add", e.task.title);
        }

        function editTask(e) {
            //console.log("Editing task: ", e.task.title);
        }

        function removeTask(e) {
            if (e.task) {
                //console.log("Removing task:", e.task.title);
                //console.log(kendo.format("Removing {0} related dependencies", e.dependencies.length));
            } else {
                //console.log("Removing dependency with id:", e.dependencies[0].id);
            }
        }

        function cancelTask(e) {
            //console.log("Cancel editing task: ", e.task.title);
        }

        function updateTask(e) {
            //console.log("Save task:", e.task.title);
        }

        function getSummary() {
             var summary = {
                Draft: 0,
                InProgress: 0,
                Planned: 0,
                Completed: 0
             };
             return summary;
        }
        function selectionChange(e) {
            var selection = this.select();
            var task;
            if (selection) {
                task = this.dataItem(selection);
                if (task != undefined) {//clicking on gantt can throw undefined.
                    vm.selectedAsignee = task.title;
                    //console.log(kendo.format("{0} is selected", task.title));
                    //$("#gd").focus();
                    

                    
                    vm.showViewLayout = false;
                    $scope.$apply(function () {
                        
                        //getAllTaskSummary(task.title);

                        var tasks = vm.taskDatasource.filter(function (el) { return el.parentId == task.id });

                        var summary = getSummary();

                        for (var index = 0; index < tasks.length; index++) {
                            switch (tasks[index].status) {
                                case "Draft":
                                    summary.Draft = summary.Draft+1;
                                    break;
                                case "InProgress":
                                    summary.InProgress = summary.InProgress+1;
                                    break;
                                case "Planned":
                                    summary.Planned = summary.Planned+1;
                                    break;
                                case "Completed":
                                    summary.Completed = summary.Completed+1;
                                    break;
                            }
                        }

                         renderTaskSummaryChart(summary);

                        vm.gridDataSource = [];
                        if (tasks.length) {
                            for (var index = 0; index < tasks.length; index++) {
                                var taskObj = {};
                                taskObj["taskId"] = tasks[index].taskId;
                                taskObj["startTime"] = utility.toLocalDate(tasks[index].startTime);
                                taskObj["endTime"] = utility.toLocalDate(tasks[index].endTime);
                                taskObj["title"] = tasks[index].title;
                                taskObj["priority"] = tasks[index].priority;
                                taskObj["status"] = tasks[index].status;
                                taskObj["taskpercentcomplete"] = parseInt(tasks[index].percentcomplete);
                                taskObj["actualStartTime"] = utility.toLocalDate(tasks[index].actualStartTime)?utility.toLocalDate(tasks[index].actualStartTime):"-";
                                taskObj["actualEndTime"] = utility.toLocalDate(tasks[index].actualEndTime)?utility.toLocalDate(tasks[index].actualEndTime):'-';

                                //below security permissions
                                taskObj["canSave"] = tasks[index].CanPercentageUpdate;
                                taskObj["canSubmit"] = tasks[index].CanSubmit;
                                taskObj["canStart"] = tasks[index].CanStart;
                                taskObj["canComplete"] = tasks[index].CanComplete;
                                taskObj["canComment"] = tasks[index].CanComment;
                                taskObj["canEdit"] = tasks[index].CanEdit;
                                taskObj["canCarryforward"] = tasks[index].CanCarryforward;
                                taskObj["togglePercent"] = false;

                                vm.gridDataSource.push(taskObj);
                            }
                            //getTasks();
                            //vm.gridDataSource = [{ "title": "Task1", "status": "Draft" }, { "title": "Task2", "status": "Planned" }];
                            vm.noTasksAssigned = false;
                            renderTaskGrid(vm.gridDataSource);
                        }
                        else {
                            vm.noTasksAssigned = true;
                        }
                    });
                }
                this.clearSelection(); //no need  to highlight the selected task, so clearing it.
            }
            $('.scrollableTasksCompleteContent').animate({ scrollTop: $("#UserSpecificTasksContainer").position().top }, 200);
        }

        function getTasks(userOrGroup) {
            var taskGridFilter = {};
            taskGridFilter.AssetName = appContext.getAssetName();
            taskGridFilter.HierarchyName = appContext.getHierarchyName();
            taskGridFilter.StartTime = appContext.getStartTime();
            taskGridFilter.EndTime = appContext.getEndTime();

            //populate assignees, priorities and status and types

            httpService.getAllTasks(taskGridFilter).then(function (response) {

                var dataSource = response.

                vm.TaskGridOptions = {
                    dataSource: dataSource,
                    //navigatable: true,
                    //pageable: true,
                    height: 550,
                    toolbar: ["create", "save", "cancel"],
                    columns: [
                        "ProductName",
                        { field: "UnitPrice", title: "Unit Price", format: "{0:c}", width: 120 },
                        { field: "UnitsInStock", title: "Units In Stock", width: 120 },
                        { field: "Discontinued", width: 120 },
                        { command: "destroy", title: "&nbsp;", width: 150 }],
                    editable: true
                };
            });
            vm.ShowUserSpecificTasks = true;
        }


        function renderTaskGrid(data) {
           
            vm.ShowUserSpecificTasks = true;
            vm.TaskGridOptions = {

                dataSource: {
                    data: data,                    
                 //pageSize: 10
                },
                //scrollable: {
                //    virtual: true
                //},
               
               

                columns: [
                      { field: "title", title: "Task Name", headerAttributes: { title: "Task Name" }, attributes: { title: "#= title #" }, width: "11%", filterable: true },
                        { title: "Planned Start Time", template: "#= kendo.toString(startTime, 'MM/dd/yyyy HH:mm')#", attributes: { title: "#= startTime #" }, filterable: false, width: "14%" },
                        { title: "Planned End Time", template: "#= kendo.toString(endTime, 'MM/dd/yyyy HH:mm') #",  attributes: { title: "#= endTime #" }, filterable: false, width: "14%" },

                         { title: "Actual Start Time", template: "#= kendo.toString(actualStartTime, 'MM/dd/yyyy HH:mm')#", attributes: { title: "#= actualStartTime #" }, filterable: false, width: "14%" },
                        { title: "Actual End Time", template: "#= kendo.toString(actualEndTime, 'MM/dd/yyyy HH:mm') #", attributes: { title: "#= actualEndTime #" }, filterable: false, width: "14%" },


                        { field: "priority", title: "Priority", headerAttributes: { title: "Priority" }, attributes: { title: "#= priority #" }, width: "8%", filterable: true },

                        { title: "Status", template: $('#task-detail-template').html(), headerAttributes: { title: "Status" }, attributes: { title: "#= status #" }, filterable: false, sortable: false, width: "14%" },
                        { title: "Actions", template: $('#task-action-template').html(), headerAttributes: { title: "Actions" }, filterable: false, sortable: false, width: "11%" }
                        //kendo.toString(new Date("2017-03-07 18:30:00"), 'MM/dd/yyyy HH:mm')
                ],
              
               height: 366,
                sortable: false,
                filterable: true,
                selectable: true,
                change: function (e) {
                    var taskId = this.dataItem(this.select()).taskId;
                    taskService.getTaskDetails(taskId)
                    .then(function (response) {
                        if (!utility.isError(response)) {
                            if (response != undefined) {
                                var data = response.Tasks[0];
                                populateTaskDetails(data);

                            }
                        }
                    });

                },
                dataBound: function () {
                    //console.log('databound event');
                }

            };

            //$('#GridName').data('kendoGrid').dataSource.read();
            //$('#GridName').data('kendoGrid').refresh();
        }

        function populateTaskDetails(data) {
            vm.TaskId = data.TaskId;
            vm.TaskName = data.Name;
            vm.tasksStrtDateTime = utility.toLocalDate(data.StartTime);
            vm.tasksEndDateTime = utility.toLocalDate(data.EndTime);
            vm.Priority = data.Priority;
            vm.Type = data.TypeDisplayName;
            vm.tasksStatus = data.State;
            vm.assetName = appContext.getAssetName();
            vm.isTaskOverdue = data.IsOverdue;



            var assignedToObject = [];
            if (data.TaskDetails.GroupAssignees) {
                var groups = data.TaskDetails.GroupAssignees;
                for (var i = 0; i < groups.length; i++) {

                    var displayName = groups[i].Name;
                    if (groups[i].Scope)
                        displayName = displayName + "(" + groups[i].Scope + ")";

                    var groupsAssignee = {
                        UserPrincipal: groups[i].Name,
                        DisplayName: displayName,
                        EID: groups[i].Scope,
                        IsGroup: true
                    };

                    assignedToObject.push(groupsAssignee);
                }
            }
            if (data.TaskDetails.PersonAssignees) {
                var persons = data.TaskDetails.PersonAssignees;
                for (var i = 0; i < persons.length; i++) {

                    var personAssignee = {
                        UserPrincipal: persons[i].UserPrincipal,
                        DisplayName: persons[i].DIsplayName,
                        Email: persons[i].EmailId,
                        EID: persons[i].EID,
                        IsGroup: false
                    };

                    assignedToObject.push(personAssignee);
                }
            }


            vm.selectedAssignedTo = assignedToObject;
            //for (var index = 0; index < assignedToObject.length; index++) {
            //    if (vm.selectedAssignedTo.length > 0)
            //        vm.selectedAssignedTo = vm.selectedAssignedTo.concat(', ');
            //    vm.selectedAssignedTo = vm.selectedAssignedTo.concat(assignedToObject[index].DisplayName);
            //}

            vm.carryOverDayValue = data.TaskDetails.CarryOverDays;
            vm.carryOverHourValue = data.TaskDetails.CarryOverHours;
            vm.taskDescription = $sce.trustAsHtml(data.TaskDetails.Description);
            vm.Url = "";
            vm.DisplayName = "";
            vm.Attachfile = "";
            vm.accordianNewtask = false;
            vm.accordianTaskDetails = false;
            vm.isActiveNewTask = false;
            vm.accordianWorkflow = false;
            vm.links = [];
            vm.attachments = [];

            if (data.TaskDetails.Links == null && vm.Readonly == true) {
                vm.DisplayName = vm.LocalizedStrings.No_links_added;

            }

            if (data.TaskDetails.Links != null) {
                for (var i = 0; i < data.TaskDetails.Links.length; i++) {
                    vm.showlinkContainer = true;
                    vm.showlinkContainer = vm.showlinkContainer;
                    var lnkDetails = {
                        Url: data.TaskDetails.Links[i].Link,
                        DisplayName: data.TaskDetails.Links[i].DisplayName

                    };
                    vm.links.push(lnkDetails);
                    vm.Link = '';
                    vm.DisplayName = '';
                }
            }

            if (data.TaskDetails.Attachments == null && vm.Readonly == true) {
                vm.AttachDisplayName = vm.LocalizedStrings.No_documents_uploaded;
            }
            if (data.TaskDetails.Attachments != null) {
                for (var i = 0; i < data.TaskDetails.Attachments.length; i++) {
                    vm.showAttachmentContainer = true;
                    vm.showAttachmentContainer = vm.showAttachmentContainer;

                    var fileNameandPath = data.TaskDetails.Attachments[i].FileName.split(";");
                    var attachdetails = {
                        Attachfile: fileNameandPath[1],
                        AttachDisplayName: data.TaskDetails.Attachments[i].DisplayName,
                        Name: fileNameandPath[0]

                    };
                    vm.attachments.unshift(attachdetails);

                }
            }
            vm.showViewLayout = true;
            var si = setInterval(function () {

                if (!$("#taskDetailsContainerX").hasClass("ng-hide")) {
                    $('.scrollableTasksCompleteContent').animate({ scrollTop: $("#taskDetailsContainerX").position().top }, 200);

                    clearInterval(si);
                }

            }, 10);
        }

        function moveStart(e) {
            //console.log("Move start ", e.task.title);
        }

        function moveTask(e) {
            //console.log(kendo.format("task's curren Start {0:g}", e.start));
            //console.log(kendo.format("task's curren End {0:g}", e.end));
        }

        function moveEnd(e) {
            //console.log(kendo.format("task's new Start {0:g}", e.start));
            //console.log(kendo.format("task's new End {0:g}", e.end));
        }
        function setGanttHeight() {
            var height = $("#divGanttChart").height();
            $("#divGanttChart").height(height - 30);

        }

        function dataBound(e) {
            setGanttHeight();
            console.time("dataBound");
            if (!_isDataBoundCompletedOnce) {

                var gantt = this;
                var slots = gantt.timeline.view()._timeSlots();
                var dataSource = gantt.dataSource;
                var tasks = gantt.dataSource.view();
                //getting the width of the slots
                var slotWidth = slots[0].offsetWidth;


                //assuiming no editable features, so databound fires only once when data is completely binded
                //check on expand event fires or not ...? yes fires
                //by default expanded should be true after that collapse all , in case flickering is there hide from the biginning once complete show it

                //check if it is summary or task first task.summary
                //check task is child task.parentId is not null
                //find the .k-task .k-task-single with data-uid of task.uid
                //find whose closest task-wrap and left value            
                // if task.parent()[0].parentId == null and task.parent()[0].uid
                //first get the parent uid and check parent exists in object create the child 
                //else create a parent object and include the child
                //create an object with parent,child task name and left {parent :"uid",child:"uid", childwidth:"98px", left :"150",}
                //loop through all the parents and apply the child width


                //a custom function to get the overlap tooltip names
                var taskParentUid = "";

                console.time("taskIteration");

                var timelineObject = angular.element(".k-gantt-layout.k-gantt-timeline");
                for (var i = 0; i < tasks.length; i++) {

                    var task = tasks[i];
                    if (task.summary) { //we are going to modify summary, considering only child ignoring summary
                        taskParentUid = task.uid;
                        continue;
                    }

                    //if it is task child not task summary
                    if (task.parentId != "" && task.parentId != null && task.parentId != undefined) {
                        //var eachTaskRow = angular.element(timelineObject).find("[data-uid='" + task.uid + "'].k-task.k-task-single").closest(".k-task-wrap");

                        //var taskWidth = angular.element(timelineObject).find("[data-uid='" + task.uid + "'].k-task.k-task-single").closest(".k-task-wrap").width();
                        //var taskLeft = parseInt(angular.element(timelineObject).find("[data-uid='" + task.uid + "'].k-task.k-task-single").closest(".k-task-wrap").position().left);

                        //taking difference of end and start time and converting it to hour and multiplying by 100 which is slot width
                        //below code to improve performance

                        var taskMetaData = _createTaskMetatData(task, taskParentUid, slotWidth);

                        //there can be multiple parent and child
                        //if parent exists add child to that else create a  parent
                        if (_taskSummaryCollection[taskParentUid] == undefined) {
                            _taskSummaryCollection[taskParentUid] = [];
                            _taskSummaryCollection[taskParentUid].push(taskMetaData);
                        }
                        else {
                            //adding childs to existing parent
                            _taskSummaryCollection[taskParentUid].push(taskMetaData);
                        }
                    }
                }
                console.timeEnd("taskIteration");

                //updating tooltip property and overlap property for each task metadata, based on its siblings
                console.time("overlapLogic");

                _updateOverlapForTasks(slotWidth);

                console.timeEnd("overlapLogic");

                _attachGanttEvents();
                _isDataBoundCompletedOnce = true;
            }
            _createSummaryStyles(_taskSummaryCollection);
            //console.log(_taskSummaryCollection);
            console.timeEnd("dataBound");



        }

        //below are private function for creating custom task summary

        //below metod replaces the default task summary with customized task summary with showing free time slots
        function _createSummaryStyles() {
            //var taskSummaryPosition = 0;
            console.time("createSummaryStyles");
            if (_taskSummaryCollection) {
                for (var eachTask in _taskSummaryCollection) {

                    //++taskSummaryPosition;
                    var taskSummaryChildren = _taskSummaryCollection[eachTask];
                    var taskSummaryString = '<div data-uid="' + eachTask + '" ></div>';

                    for (var i = 0; i < taskSummaryChildren.length; i++) {

                        var left, width, tooltip, title, percentComplete, priority, label, isOverdue, tooltipLabel, tooltipclass;


                        left = taskSummaryChildren[i].left;
                        width = taskSummaryChildren[i].width;
                        tooltip = taskSummaryChildren[i].tooltip;
                        title = taskSummaryChildren[i].title;
                        percentComplete = taskSummaryChildren[i].percentComplete;
                        priority = taskSummaryChildren[i].priority;
                        isOverdue = taskSummaryChildren[i].isOverdue;

                        var color = _Ganttcolors.Overlap;

                        if (taskSummaryChildren[i].isOverlap == true) {
                            label = "";
                            tooltipLabel = "";
                        }
                        else if (isOverdue == true) {
                            label = "<i class='icon-overdue small-icon overdue-task'></i>" + "<b>" + title + "</b>" + " (" + priority + ") " + percentComplete + "%";
                            tooltipLabel = title + " (" + priority + ") " + percentComplete + "%";
                        } else {
                            label = "<b>" + title + "</b>" + " (" + priority + ") " + percentComplete + "%";
                            tooltipLabel = title + " (" + priority + ") " + percentComplete + "%";
                        }
                       
                        tooltipclass = "";
                        if (label != "" && label != null && label != undefined)
                        {
                            tooltipclass = "task-summary-show-tooltip";
                        }

                        if (!taskSummaryChildren[i].isOverlap) {
                            switch (taskSummaryChildren[i].status) {
                                case "Planned":
                                    color = _Ganttcolors.Planned;
                                    break;
                                case "InProgress":
                                    color = _Ganttcolors.Inprogress;
                                    break;
                                case "Completed":
                                    color = _Ganttcolors.Completed;
                                    break;
                                case "Draft":
                                    color = _Ganttcolors.Draft;
                                    break;
                            }
                        }

                        var labelWidth = width - 5;

                        tooltip = "";

                        var summary = '<div class="k-task-wrap custom-wrap" style="left: ' + left + 'px;">' +
                                      '<div class="k-task k-task-summary" style="border-color:' + color + ';background-color:' + color + ';width: ' + width + 'px;">' +
                                      '<div class="k-task-summary-progress" style="width: 0px;">' +
                                      '<div class="k-task-summary-complete" style="width: 0px;">' +
                                      '</div></div></div>' +
                                      '<span title="' + tooltipLabel + '" class="spn-summarylabel ' + tooltipclass + '" style="width:' + labelWidth + 'px">' + label + '</span>' +
                                      '</div>';


                        //var summary = '<div style="width:' + width + 'px;left:' + left + 'px;background-color:green; display:block"></div>';

                        taskSummaryString += summary;
                    }

                    //use eachTask variable to get the parent summary element     
                    var taskSummaryContainer = angular.element(".k-gantt-layout.k-gantt-timeline").find("[data-uid='" + eachTask + "'].k-task.k-task-summary").closest(".k-task-wrap").closest("td");
                    angular.element(taskSummaryContainer).html(taskSummaryString);
                }

            }
            var taskSummaryShowTooltip = $("#divGanttChart").kendoTooltip({
                filter: ".task-summary-show-tooltip",
                width: 150,
                position: "left",
                callout: false,
            }).data("kendoTooltip");

            angular.element(".k-task-wrap").not(".custom-wrap").each(function () {
                $(this).hide();
            });

            console.timeEnd("createSummaryStyles");
        }

        //all the events in the gantt chart
        function _attachGanttEvents() {
            //$(document).off("click", ".k-gantt-ExpandAll");
            //$(document).on("click", ".k-gantt-ExpandAll", function (e) {
            //    $rootScope.$emit("showLoadingIcon");
            //    vm.gantt.dataSource.view().forEach(function (e) {
            //        //e.expanded = true;
            //        e.set("expanded", true);
            //    })
            //    $(this).hide();
            //    $(".k-gantt-CollapseAll").show();
            //    vm.gantt.refresh();
            //    $rootScope.$emit("hideLoadingIcon");
            //});

            //$(document).off("click", ".k-gantt-CollapseAll");
            //$(document).on("click", ".k-gantt-CollapseAll", function (e) {
            //    $rootScope.$emit("showLoadingIcon");
            //    vm.gantt.dataSource.view().forEach(function (e) {
            //        //e.expanded = false;
            //        e.set("expanded", false);
            //    })
            //    $(this).hide();
            //    $(".k-gantt-ExpandAll").show();
            //    vm.gantt.refresh();
            //    $rootScope.$emit("hideLoadingIcon");
            //});

            //$(".k-gantt-AddNewTask").off("click");
            //$(".k-gantt-AddNewTask").on("click", function (e) {

            //    $scope.$apply(function () {
            //        $location.path('/addEditTasks');
            //    });

            //    _updateTaskSummary();
            //});

            //$(".k-gantt-Prev").off("click");
            //$(".k-gantt-Prev").on("click", function (e) {
            //    _updateGanttDataSource(taskDataSourceNight);
            //});

            //$(".k-gantt-Next").off("click");
            //$(".k-gantt-Next").on("click", function (e) {
            //    _updateGanttDataSource(taskDataSourceDay);
            //});

            //$(".k-task-single").click(function (e) {
            //    //console.log("edit task");
            //});

            $(".k-view-day").hide();
            $(".k-gantt-CollapseAll").hide();
        }

        //creates an object which is used for creating task summary
        //if addition fields/features required in task summary means below code needs to be modified
        function _createTaskMetatData(task, parentId, slotWidth) {

            var taskWidth = ((task.end - task.start) / (1000 * 60 * 60) * slotWidth) / appContext.getGanttHourSpan();

            //1.do not consider the minutes here
            var taskLeft = ((task.start - kendo.parseDate(utility.toLocalDateWithoutMinutes(appContext.getStartTime()))) / (1000 * 60 * 60) * slotWidth) / appContext.getGanttHourSpan();

            var taskUid = task.uid;
            var taskParentUid = parentId; //dataSource.taskParent(dataSource.at(i)).uid; /// task.parent()[0].uid;
            var taskOverlap = false;
            var taskTooltip = task.title;

            //forming task meta data , based on this manipulation is done task summary later
            var taskMetaData = {
                //gantt properties
                parentUid: taskParentUid,
                uid: taskUid,
                width: taskWidth,
                left: taskLeft,
                isOverlap: taskOverlap,
                isOverdue: task.IsOverdue,
                tooltip: taskTooltip,

                //task properties
                status: task.status,
                title: task.title,
                priority: task.priority,
                percentComplete: task.percentcomplete,
                startTime: task.startTime,
                endTime: task.endTime,
            };

            return taskMetaData;
        }


        function sortByLeft(a, b) {
            if (a.left < b.left)
                return -1;
            if (a.left > b.left)
                return 1;
            return 0;
        }

        //below function to update the tasks whether ovarlap is happening or not and also it updates the tooltip for normal task as well as overlap tasks
        function _updateOverlapForTasks(slotWidth) {
            if (_taskSummaryCollection) {
                for (var eachTask in _taskSummaryCollection) {
                    var taskSummaryChildren = _taskSummaryCollection[eachTask];

                    //sort the tasks based on the left property
                    taskSummaryChildren.sort(sortByLeft);

                    if (taskSummaryChildren && taskSummaryChildren.length > 0) {
                        for (var i = 0; i < taskSummaryChildren.length; i++) {

                            //update complete data in tool tip
                            var tooltipHTML = "<div><table><tr><td>" + taskSummaryChildren[i].title + "</td><td>" + taskSummaryChildren[i].startTime + "</td><td>" + taskSummaryChildren[i].endTime + "</td></tr></table></div>";
                            taskSummaryChildren[i].tooltip = tooltipHTML;

                            if (i == 0) { // ignoring first child of parent since it will not over lap                                
                                continue;
                            }
                            //var isOverLap = (taskSummaryChildren[i].left - taskSummaryChildren[i - 1].left) < slotWidth;
                            var isOverLap = (taskSummaryChildren[i].left < (taskSummaryChildren[i - 1].left + taskSummaryChildren[i - 1].width));
                            taskSummaryChildren[i].isOverlap = isOverLap;
                            if (isOverLap && i >= 0) {
                                taskSummaryChildren[i - 1].isOverlap = isOverLap;

                                taskSummaryChildren[i].tooltip = taskSummaryChildren[i - 1].tooltip + "<br/>" + taskSummaryChildren[i].tooltip;
                                taskSummaryChildren[i - 1].tooltip = taskSummaryChildren[i].tooltip;
                            }
                        }
                    }
                }
            }
        }

        function _updateTaskSummary() {
            //1.read the index from edit form
            var index = 1;
            var dataSource = vm.gantt.dataSource;
            var task = dataSource.at(index);

            //2.update the task with new data
            dataSource.update(task, { title: "task1 updated", start: new Date("2017/2/23 22:15"), end: new Date("2017/2/23 23:15"), priority: "High", percentcomplete: "1" });

            //3.get slotwidth and parent id for the task
            var slotWidth = vm.gantt.timeline.view()._timeSlots()[0].offsetWidth;
            var parentId = dataSource.taskParent(dataSource.at(index)).uid; /// task.parent()[0].uid;

            //4.create the meta data
            var taskMetaData = _createTaskMetatData(task, parentId, slotWidth);

            //5.update the existing colletion            
            if (_taskSummaryCollection) {
                for (var eachParent in _taskSummaryCollection) {
                    if (eachParent == parentId) {
                        var allChilds = _taskSummaryCollection[eachParent];
                        for (var i = 0; i < allChilds.length; i++) {
                            if (allChilds[i].uid == task.uid) {
                                allChilds[i] = taskMetaData;
                            }
                        }
                    }
                }
            }

            //6.update the overlap logic  
            _updateOverlapForTasks(slotWidth);

            //7.redraw the summary styles
            _createSummaryStyles();
        }

        function _AddNewTask() {
            //1.read the index from edit form
            var index = 1;
            var dataSource = vm.gantt.dataSource;
            var task = dataSource.at(index);

            //2.update the task with new data
            dataSource.update(task, { title: "task1 updated", start: new Date("2017/2/23 22:15"), end: new Date("2017/2/23 23:15"), priority: "High", percentcomplete: "1" });

            //3.get slotwidth and parent id for the task
            var slotWidth = vm.gantt.timeline.view()._timeSlots()[0].offsetWidth;
            var parentId = dataSource.taskParent(dataSource.at(index)).uid; /// task.parent()[0].uid;

            //4.create the meta data
            var taskMetaData = _createTaskMetatData(task, parentId, slotWidth);

            //5.update the existing colletion            
            if (_taskSummaryCollection) {
                for (var eachParent in _taskSummaryCollection) {
                    if (eachParent == parentId) {
                        var allChilds = _taskSummaryCollection[eachParent];
                        for (var i = 0; i < allChilds.length; i++) {
                            if (allChilds[i].uid == task.uid) {
                                allChilds[i] = taskMetaData;
                            }
                        }
                    }
                }
            }

            //6.update the overlap logic  
            _updateOverlapForTasks(slotWidth);

            //7.redraw the summary styles
            _createSummaryStyles();
        }


        //below function to update the existing datasoure with new data source
        function _updateGanttDataSource(newDataSource) {
            _isDataBoundCompletedOnce = false;
            _taskSummaryCollection = {};
            var gantDataSource = new kendo.data.GanttDataSource({
                data: newDataSource
            });
            vm.gantt.setDataSource(gantDataSource);

            //check if any is expanded or not then collapse all
            vm.gantt.dataSource.view().forEach(function (e) {
                e.expanded = false;
            });
            vm.gantt.refresh();
        }

        //reset the gantt chart. this method should be called, when ever rebind required
        function _resetTaskSummaryGanttChart() {
            _taskSummaryCollection = {};
            _isDataBoundCompletedOnce = false;
        }

        //be default gantt will not round to sucessor time instead it rounds to prredecessor time. 
        //For ex: if shift end time is 8:30 pm it will plot till 8:00 pm, to plot till 9:00 pm below code is written
        function _getGanttEndTime(utcString) {
            if (utcString) {

                var dateTimeArray = utcString.split(" ");

                var dateArray = dateTimeArray[0].split("-");
                var timeArray = dateTimeArray[1].split(":");

                var utcDate = new Date(dateArray[0], dateArray[1] - 1, dateArray[2], timeArray[0], timeArray[1], timeArray[2]);
                var offset = utcDate.getTimezoneOffset() * 60000;
                utcDate.setTime(utcDate.getTime() - offset);

                if (utcDate.getMinutes() > 0)
                    utcDate.setHours(utcDate.getHours() + 1, 0, 0);

                return kendo.toString(utcDate, "g");
            }
            return null;
        }

        //by default slot width is 100        
        function _getGanttHourSpan() {
            var startime = utility.convertDateStringtoDate(appContext.getStartTime());
            var endTime = utility.convertDateStringtoDate(appContext.getEndTime());

            var delta = (endTime - startime) / (1000 * 60 * 60);
            var hourSpan = 1;

            switch (true) {
                case delta <= 12:
                    hourSpan = 1;
                    break;
                case delta > 12 && delta <= 24:
                    hourSpan = 2;
                    break;
                case delta > 24:
                    hourSpan = 4;
                    break;
            }

            return hourSpan;
        }
    }



})();



