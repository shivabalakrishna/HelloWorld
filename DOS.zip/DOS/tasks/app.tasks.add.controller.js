/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview startup module for the application 
* @author Badrinarayana G.V
*/

(function () {
    'use strict';

    angular.module('app.tasks.module')
           .controller("addTasksController", addTasksController)
           .directive('dosLink', dosLink)
           .directive('dosAttachment', dosAttachment);

    addTasksController.$inject = ['$scope', '$window', '$document', '$rootScope', '$location', '$q', '$translate', 'app.common.httpService', 'app.common.factory.loggerFactory',
                                      'app.common.factory.notificationsFactory', 'app.common.utilitiesFactory', 'app.common.appcontext.factory', 'app.tasks.service'];

    function addTasksController($scope, $window, $document, $rootScope, $location, $q, $translate, httpService, logger, notifications, utility, appContext, taskService) {

        var vm = this;
        var CurrentDate = kendo.toString(kendo.parseDate(new Date()), utility.getCustomDateTimeFormat());
        var Security = {};


        var title = '';
        vm.accordianNewtask = false;
        vm.accordianTaskDetails = false;

        vm.isActiveNewTask = false;
        vm.Readonly = false;

        vm.selectedAssignedTo = [];
        vm.AssignedToDatasource = [];
        vm.carryOverDayDatasource = [];
        vm.PriorityDatasource = [];
        vm.links = [];
        vm.attachments = [];
        vm.LocalizedStrings;

        vm.carryOverDayValue = "";
        vm.carryOverHourValue = "";
        vm.Priority = "";
        vm.TaskId = "";
        vm.TemplateId = "";
        vm.TaskName = "";
        vm.tasksStrtDateTime = "";
        vm.tasksEndDateTime = "";
        vm.taskDescription = "";
        vm.emptyins = false;
        vm.isstatdategreater = false;
        vm.invalidAssignedTo = false;
        vm.invalidTaskDescription = false;
        vm.invalidType = false;
        vm.invalidPriority = false;
        vm.isActiveTaskDetails = false;

        vm.securityConfigureSetting = false;
        vm.selectedPriorityId = "";
        vm.selectedTypeId = "";

        vm.isActiveNewTask = false;
        vm.newPriorityPopup = newPriorityPopup;
        vm.newPriorityEditPopup = newPriorityEditPopup;
        vm.onPriorityCancel = onPriorityCancel;
        vm.onPrioritySave = onPrioritySave;
        vm.newTypePopup = newTypePopup;
        vm.onTypeSave = onTypeSave;
        vm.onTypeCancel = onTypeCancel;
        vm.newTypeEditPopup = newTypeEditPopup;
        vm.saveTaskDetails = saveTaskDetails;
        vm.addLinks = addLinks;
        vm.delLinks = delLinks;
        vm.delAttachments = delAttachments;
        vm.showlinkContainer = false;
        vm.showAttachmentContainer = false;
        $scope.addAttachment = addAttachment;// Here scope is mandatory


        vm.isTimeBasedRecurrenceEnabled = false;
        vm.recurrencePattern = "Daily";
        vm.rdbRecurEveryOrWeekDay = "EveryNday";
        vm.weekDaySelection = [];
        vm.recurMonthly = 'Day';
        vm.recurYearly = 'Month';
        vm.recurrenceRange = "NoEndDate";
        vm.rdbRecurEveryNDay = "";
        vm.txtRecurMonthly_Day = "";
        vm.txtRecurMonthly_Month = "";
        vm.txtRecurrentYearlyOnDay = "";
        vm.errRecurrence = "";
        vm.errInvalidShift = "";
        vm.rdbRecurShift = false;
        vm.ShiftNames = [];

        vm.getCornExpression = function () {

            return getCronExpression();
        }


        function isValidCornExpression() {

            vm.errRecurrence = "";

            var error = "Please fill all the appropriate values in the recurrence";

            var patternType = vm.recurrencePattern;

            if (patternType == "Daily") {
                if (vm.rdbRecurEveryOrWeekDay == "EveryNday") {

                    if (vm.rdbRecurEveryNDay == null || vm.rdbRecurEveryNDay == "") {
                        vm.errRecurrence = error;
                    }
                }

            }
            else if (patternType == "Weekly") {
                var days = "";

                for (var i = 0 ; i < vm.weekDaySelection.length; i++) {
                    if (days != "") {
                        days += ",";
                    }
                    days += vm.weekDaySelection[i];
                }
                if (days == "") {
                    vm.errRecurrence = error;
                }
            }
            else if (patternType == "Monthly") {
                if (vm.recurMonthly == "Day") {

                    if (vm.txtRecurMonthly_Day == null || vm.txtRecurMonthly_Month == null || vm.txtRecurMonthly_Day == "" || vm.txtRecurMonthly_Month == "") {
                        vm.errRecurrence = error;
                    }
                }
                else if (vm.recurMonthly == "Month") {

                    if (vm.txtRecurMonthly_Month2 == null || vm.txtRecurMonthly_Month2 == "") {
                        vm.errRecurrence = error;
                    }
                }
            }
            else if (patternType == "Yearly") {
                if (vm.recurYearly == "Month") {
                    if (vm.txtRecurrentYearlyOnDay == null || vm.txtRecurrentYearlyOnDay == "") {
                        vm.errRecurrence = error;
                    }
                }
            }
            if (vm.recurrenceRange == 'EndBy') {
                if (vm.recurrenceEndTime == null || vm.recurrenceEndTime == "") {
                    vm.errRecurrence = "Please provide the recurrence end date";
                }
                else {

                }
            }

            if (vm.errRecurrence != "") {
                return false;
            }

            return true;

        }



        function setCronExporession(expression) {

            if (expression != null && expression != "") {
                var expressionArray = expression.split(" ");
                var minutes = expressionArray[0];
                var hour = expressionArray[1];
                var day = expressionArray[2];
                var month = expressionArray[3];
                var week = expressionArray[4];

                var patternType = "";


                if (week == "*" && month == "*") {

                    vm.recurrencePattern = "Daily";
                    vm.rdbRecurEveryOrWeekDay = "EveryNday";
                    vm.rdbRecurEveryNDay = parseInt(day.split("/")[1]);
                    //the above line is not actually setting the value in the respective control so we going with the below one




                }
                else if (week == "MON-FRI") {
                    vm.recurrencePattern = "Daily";
                    vm.rdbRecurEveryOrWeekDay = "EveryWeekDay";
                }
                else if (month == "*" && day == "*") {
                    vm.recurrencePattern = "Weekly";
                    vm.weekDaySelection = [];
                    var weeks = week.split(",");
                    if (weeks.length > 0) {
                        for (var i = 0 ; i < weeks.length; i++) {
                            vm.weekDaySelection.push(weeks[i]);
                        }
                    }
                }
                else if (week == "*" && month.indexOf("/") > 0) {
                    vm.recurrencePattern = "Monthly";
                    vm.recurMonthly = "Day";
                    month = month.split("/")[1];
                    vm.txtRecurMonthly_Day = day;
                    vm.txtRecurMonthly_Month = month;
                }
                else if (month.indexOf("/") > 0 && day == "*") {
                    vm.recurrencePattern = "Monthly";
                    vm.recurMonthly = "Month";
                    month = month.split("/")[1];
                    var dayNumber = week.substring(0, 3);
                    var weekNumber = week.substring(3, 5);
                    vm.txtRecurMonthly_Month2 = month;
                    vm.cmbRecurMonthlyDayNumber.value(dayNumber);
                    vm.cmbRecurMonthlyWeekNumber.value(weekNumber);
                }
                else {
                    vm.recurrencePattern = "Yearly";
                    if (day == "*") {
                        vm.recurYearly = "Yearly";
                        vm.cmbRecurYearlyYearOnMonth.value(month);
                        var dayNumber = week.substring(0, 3);
                        var weekNumber = week.substring(3, 5);
                        vm.cmbRecurYearlyDayNumber.value(dayNumber);
                        vm.cmbRecurYearlyWeekNumber.value(weekNumber);
                    }
                    else {
                        vm.recurYearly = "Month";
                        vm.cmbRecurYearlyOnMonth.value(month);
                        vm.txtRecurrentYearlyOnDay = day;
                    }
                }
            }
        }

        function getCronExpression() {


            var generateAtTimepicker = kendo.parseDate(vm.tasksStrtDateTime, utility.getCustomDateTimeFormat());
            var hour = kendo.toString(generateAtTimepicker, "HH");
            var min = kendo.toString(generateAtTimepicker, "mm")

            var patternType = vm.recurrencePattern;
            var expression = "";
            if (patternType == "Daily") {
                if (vm.rdbRecurEveryOrWeekDay == "EveryNday") {

                    if (vm.rdbRecurEveryNDay != null && vm.rdbRecurEveryNDay != "") {
                        expression = min + " " + hour + " " + "*/" + vm.rdbRecurEveryNDay + " * *";
                        //occurs every n days 
                    }
                }
                else if (vm.rdbRecurEveryOrWeekDay == "EveryWeekDay") {
                    expression = min + " " + hour + " * * MON-FRI";
                    //Occurs every weekday
                }

            }
            else if (patternType == "Weekly") {
                var days = "";

                for (var i = 0 ; i < vm.weekDaySelection.length; i++) {
                    if (days != "") {
                        days += ",";
                    }
                    days += vm.weekDaySelection[i];
                }
                if (days != "") {
                    expression = min + " " + hour + " * * " + days;
                }
                //Occurs weekly on Monday, Thursday
            }
            else if (patternType == "Monthly") {
                if (vm.recurMonthly == "Day") {

                    if (vm.txtRecurMonthly_Day != null && vm.txtRecurMonthly_Month != null && vm.txtRecurMonthly_Day != "" && vm.txtRecurMonthly_Month != "") {
                        expression = min + " " + hour + " " + vm.txtRecurMonthly_Day + " */" + vm.txtRecurMonthly_Month + " *";
                        //occurs monthly on day x of every y months
                    }
                }
                else if (vm.recurMonthly == "Month") {

                    if (vm.txtRecurMonthly_Month2 != null && vm.txtRecurMonthly_Month2 != "") {
                        expression = min + " " + hour + " * */" + vm.txtRecurMonthly_Month2 + " " + vm.cmbRecurMonthlyDayNumber.value() + vm.cmbRecurMonthlyWeekNumber.value();
                        //occurs on the First Monday of every 5 month(s)

                    }
                }
            }
            else if (patternType == "Yearly") {
                if (vm.recurYearly == "Month") {
                    if (vm.txtRecurrentYearlyOnDay != null && vm.txtRecurrentYearlyOnDay != "") {
                        expression = min + " " + hour + " " + vm.txtRecurrentYearlyOnDay + " " + vm.cmbRecurYearlyOnMonth.value() + " *";
                        //Occurs yearly on Jan 3
                    }
                }
                else if (vm.recurYearly == "Yearly") {
                    expression = min + " " + hour + " * " + vm.cmbRecurYearlyYearOnMonth.value() + " " + vm.cmbRecurYearlyDayNumber.value() + vm.cmbRecurYearlyWeekNumber.value();

                    //Occurs on the first Monday of Jan
                }
            }
            return expression;
        }






        vm.toggleWeekDaySelection = function (day) {
            var idx = vm.weekDaySelection.indexOf(day);
            if (idx > -1) {
                vm.weekDaySelection.splice(idx, 1);
            }
            else {
                vm.weekDaySelection.push(day);
            }
        }
        vm.onRecurrenceIconClick = function ($event) {
            $event.stopPropagation();
            if (vm.TemplateId == "") {
                vm.isTimeBasedRecurrenceEnabled = !vm.isTimeBasedRecurrenceEnabled;
                clearRecurrenceValues();
                if (vm.isTimeBasedRecurrenceEnabled == true) {
                    vm.onRecurrencePatternChange($event, 'Daily');
                }
            }
        }

        function clearRecurrenceValues() {
            $scope.vm.recurrenceEndTime = "";
            $scope.vm.recurrencePattern = "";
            $scope.vm.rdbRecurEveryOrWeekDay = "";
            $scope.vm.rdbRecurEveryNDay = "";
            $scope.vm.rdbRecurEveryOrWeekDay = "";
            $scope.vm.weekDaySelection = [];
            $scope.vm.recurMonthly = "";
            $scope.vm.txtRecurMonthly_Day = "";
            $scope.vm.txtRecurMonthly_Month = "";
            $scope.vm.txtRecurMonthly_Month2 = "";
            $scope.vm.cmbRecurMonthlyDayNumber.value("");
            $scope.vm.cmbRecurMonthlyWeekNumber.value("");
            $scope.vm.recurYearly = "";
            $scope.vm.cmbRecurYearlyYearOnMonth.value("");
            $scope.vm.cmbRecurYearlyDayNumber.value("");
            $scope.vm.cmbRecurYearlyWeekNumber.value("");
            $scope.vm.recurYearly = "";
            $scope.vm.cmbRecurYearlyOnMonth.value("");
            $scope.vm.txtRecurrentYearlyOnDay = "";
            $scope.vm.rdbRecurShift = false;
            $scope.vm.recurrenceRange = 'EndBy';
        }


        vm.onRecurrencePatternChange = function ($event, value) {

            $event.stopPropagation();
            vm.recurrencePattern = value;
            if (value == "Daily") {
                vm.rdbRecurEveryOrWeekDay = "EveryNday";
                vm.rdbRecurEveryNDay = "";
                utility.focusControl("txtRecurDay_Every_N_Days", "textbox");
            }
            else if (value == "Weekly") {
                vm.weekDaySelection = [];
                utility.focusControl("divWeeklyOnMON", "textbox");
            }
            else if (value == "Monthly") {
                vm.recurMonthly = 'Day';
                vm.txtRecurMonthly_Day = "";
                vm.txtRecurMonthly_Month = "";
                vm.cmbRecurMonthlyWeekNumber.value("#1");
                vm.cmbRecurMonthlyDayNumber.value("MON");
                vm.txtRecurMonthly_Month2 = "";
                utility.focusControl("txtRecurMonthly_Day", "textbox");
            }
            else if (value == "Yearly") {
                vm.recurYearly = 'Month';
                vm.txtRecurrentYearlyOnDay = "";
                vm.cmbRecurYearlyOnMonth.value("1");

                vm.cmbRecurYearlyWeekNumber.value("#1");
                vm.cmbRecurYearlyDayNumber.value("MON");
                vm.cmbRecurYearlyYearOnMonth.value("1");

                utility.focusControl("cmbRecurYearlyOnMonth", "kendoDropDownList");
            }
        }
        vm.onRecurrenceDailyEveryChange = function (value) {
            utility.focusControl("txtRecurDay_Every_N_Days", "textbox");
        }


        // Accordions strt
        vm.activeButtonNewTask = function () {
            vm.isActiveNewTask = !vm.isActiveNewTask;
        };
        vm.toggleAccordianNewTask = function () {
            vm.accordianNewTask = vm.accordianNewTask === false ? true : false;

        };

        vm.toggleAccordianTaskDetails = function () {
            vm.accordianTaskDetails = vm.accordianTaskDetails === false ? true : false;
        };

        vm.activeButtonTaskDetails = function () {
            vm.isActiveTaskDetails = !vm.isActiveTaskDetails;
        };


        vm.dateControlOptions = {
            format: utility.getCustomDateFormat()
        };

        vm.tasksPlannedStrtDateOptions = {
            format: utility.getCustomDateTimeFormat()
        };
        vm.tasksPlannedEndDateOptions = {
            format: utility.getCustomDateTimeFormat()
        };

        vm.autoFilledDisplayName = function () {
            vm.typeDisplayName = vm.typeName;
        }

        $scope.$on("AddTask", function (event, data) {
            loadConfigData(false, data, false);

            $("#taskName").focus();
        });

        $scope.$on("EditTask", function (event, data) {

            if (!(data && data.taskId)) {
                notifications.error("Fetching task details failed. Please contact the system administrator", false, true);
                return;
            }

            loadConfigData(true, data, false);
        });

        $scope.$on("EditTaskRecurrence", function (event, data) {

            if (!(data && data.templateId)) {
                notifications.error("Fetching task details failed. Please contact the system administrator", false, true);
                return;
            }

            loadConfigData(true, data, true);
        });

        function getLocalizedMessages() {
            $translate(['No_priorityname', 'No_priorityvalue', 'New_priority_created_successfully', 'Priority_updated_successfully', 'Task_saved_successfully', 'FileName_Exist',
                        'Validation_File_size_exceeds', 'Validation_Successful', 'Validation_File_Extension', 'is_not_supported', 'No_typedisplayname', 'No_typename', 'New_type_created_successfully',
                        'Type_updated_successfully', 'Edit_Priority', 'Add_Priority', 'Add_Type', 'Edit_Type'])
                    .then(function (translations) {
                        vm.LocalizedStrings = translations;
                    });
        }

        vm.validateAssignedTo = function () {
            if (!vm.selectedAssignedTo.length) {
                vm.invalidAssignedTo = true;
            }
            else {
                vm.invalidAssignedTo = false;
            }
        }

        vm.validateTaskDescription = function () {
            if (!vm.taskDescription.length) {
                vm.invalidTaskDescription = true;
            }
            else {
                vm.invalidTaskDescription = false;
            }
        }

        vm.validateType = function () {
            if (vm.typeDropDown.value() == undefined || vm.typeDropDown.value() == '') {
                vm.invalidType = true;
            }
            else {
                vm.invalidType = false;
            }
        }

        vm.validatePriority = function () {
            if (vm.ddlPriority.value() == undefined || vm.ddlPriority.value() == '') {
                vm.invalidPriority = true;
            }
            else {
                vm.invalidPriority = false;
            }
        }

        function validateTaskForm() {
            if (vm.taskForm.$invalid) {
                vm.taskForm.$submitted = true;
                return false;
            }
            vm.taskForm.$submitted = true;
            return true;
        }

        function EnddatebeforeStartdate() {

            if (!!vm.tasksStrtDateTime && !!vm.tasksEndDateTime && vm.taskForm.startTime && vm.taskForm.endTime) {
                //validations for end date before  start date                
                vm.taskForm.startTime.$error.endbeforestart = kendo.parseDate(vm.tasksStrtDateTime, utility.getCustomDateTimeFormat()) >= kendo.parseDate(vm.tasksEndDateTime, utility.getCustomDateTimeFormat());
                vm.taskForm.endTime.$error.endbeforestart = kendo.parseDate(vm.tasksStrtDateTime, utility.getCustomDateTimeFormat()) >= kendo.parseDate(vm.tasksEndDateTime, utility.getCustomDateTimeFormat());
            }
        }


        vm.onCancelCreateNewTask = function () {
            $scope.$emit("TaskCancel");
        }


        // service calls
        function getTaskConfigData() {
            var deferred = $q.defer();
            if (appContext.getConfigData() != null) {
                initializeConfigData(appContext.getConfigData());
                deferred.resolve(true);
            }
            else {
                taskService.getTaskConfigData(appContext.getAssetName())
                .then(function (response) {
                    if (!utility.isError(response)) {
                        if (response != undefined) {
                            initializeConfigData(response);
                            deferred.resolve(true);
                        }
                    }
                    else {
                        deferred.resolve(false);
                    }
                });
            }
            return deferred.promise;
        }

        function initializeConfigData(response) {
            vm.PriorityDatasource = response.ConfigData.TaskPriorities;

            vm.dropDownPriorityOptions = {
                dataTextField: "DisplayName",
                dataValueField: "Order",
                autoBind: true,
                dataSource: vm.PriorityDatasource,
                template: '<div class="pull-left addPriorityDropDown"   title="" data-id={{dataItem.Order}}>{{dataItem.DisplayName}}</div><div><i ng-show="vm.securityConfigureSetting" class="icon-edit small-icon pull-right" style="line-height:22px;" ng-click="vm.newPriorityEditPopup($event, dataItem.TaskPriority_PK_Id, dataItem.Order, dataItem.DisplayName)"></i></div>',
                headerTemplate: '<div ng-show="vm.securityConfigureSetting" class="p4 k-widget k-header">{{ "Add_priority" | translate}} <i class="icon-add pull-right small-icon" ng-click="vm.newPriorityPopup()" style="margin-top:-2px" ></i></div>'
            };

            vm.Priority = vm.PriorityDatasource[0];
            vm.TypeDatasource = response.ConfigData.TaskTypes;

            vm.typeDDOptions = {
                template: '<div class="pull-left addPriorityDropDown"   title="" data-id={{dataItem.Order}}>{{dataItem.DisplayName}}</div><div><i ng-show="vm.securityConfigureSetting" class="icon-edit pull-right small-icon" style="line-height:22px;" ng-click="vm.newTypeEditPopup($event, dataItem.TaskType_PK_Id, dataItem.Name, dataItem.DisplayName)"></i></div>',
                headerTemplate: '<div ng-show="vm.securityConfigureSetting" class="p4 k-widget k-header">{{ "Add_type" | translate}} <i class="icon-add pull-right small-icon" ng-click="vm.newTypePopup()" style="margin-top:-2px" ></i></div>'
            };

            vm.Type = vm.TypeDatasource[0];
        }

        function getUsers() {
            var deferred = $q.defer();
            if (appContext.getUsers() != null) {
                initializeAssignee(appContext.getUsers());
                deferred.resolve(true);
            }
            else {
                taskService.getUsers(appContext.getAssetName())
                .then(function (response) {
                    if (!utility.isError(response)) {
                        appContext.setUsers(response);
                        initializeAssignee(response);
                        deferred.resolve(true);
                    }
                    else {
                        deferred.resolve(false);
                    }
                });
            }
            return deferred.promise;
        }

        function resetAddEditTaskForm() {
            vm.TaskId = "";
            vm.TemplateId = "";
            vm.TaskName = "";
            vm.tasksStrtDateTime = "";
            vm.tasksEndDateTime = "";
            vm.Priority = "";
            vm.Type = "";
            vm.selectedAssignedTo = [];
            vm.carryOverDayValue = "";
            vm.carryOverHourValue = "";
            vm.taskDescription = "";
            vm.Url = "";
            vm.DisplayName = "";
            vm.links = [];
            vm.attachments = [];
            vm.Attachfile = "";
            vm.accordianNewtask = false;
            vm.accordianTaskDetails = false;
            vm.isActiveNewTask = false;
            vm.invalidAssignedTo = false;
            vm.invalidTaskDescription = false;
            vm.invalidType = false;
            vm.invalidPriority = false;
            vm.isEmptyForm = true;
            vm.taskForm.$setPristine();
        }

        function populateTaskForm(data, isRecurringTemplate) {
            var taskDetails = null;

            vm.isTimeBasedRecurrenceEnabled = isRecurringTemplate;

            if (isRecurringTemplate == true) {
                vm.TaskId = "";
                vm.TemplateId = data.TaskTemplateId;
                taskDetails = data.TaskTemplateDetail;
                vm.tasksStrtDateTime = utility.toLocalDate(taskDetails.RangeStartTime);
                vm.tasksEndDateTime = utility.toLocalDate(taskDetails.OccurenceEndTime);
                vm.taskDescription = data.Description;



            }
            else {
                vm.TaskId = data.TaskId;
                vm.TemplateId = "";
                vm.tasksStrtDateTime = utility.toLocalDate(data.StartTime);
                vm.tasksEndDateTime = utility.toLocalDate(data.EndTime);
                taskDetails = data.TaskDetails;
                vm.taskDescription = taskDetails.Description;
            }

            vm.TaskName = data.Name;
            vm.Priority = { "Order": data.PriorityOrder };
            vm.Type = { "Name": data.TypeName };

            vm.carryOverDayValue = taskDetails.CarryOverDays;
            vm.carryOverHourValue = taskDetails.CarryOverHours;
            vm.Url = "";
            vm.DisplayName = "";
            vm.links = [];
            vm.attachments = [];
            vm.Attachfile = "";
            vm.accordianNewtask = false;
            vm.accordianTaskDetails = false;
            vm.isActiveNewTask = false;

            if (taskDetails.PersonAssignees) {
                var persons = taskDetails.PersonAssignees;
                for (var i = 0; i < persons.length; i++) {

                    var personAssignee = {
                        UserPrincipal: persons[i].UserPrincipal,
                        DisplayName: persons[i].DIsplayName,
                        Email: persons[i].EmailId,
                        EID: persons[i].EID,
                        IsGroup: false
                    };

                    vm.selectedAssignedTo.push(personAssignee);
                }
            }

            if (taskDetails.GroupAssignees) {
                var groups = taskDetails.GroupAssignees;
                for (var i = 0; i < groups.length; i++) {

                    var displayName = groups[i].Name;
                    if (groups[i].Scope)
                        displayName = displayName + "(" + groups[i].Scope + ")";

                    var groupsAssignee = {
                        UserPrincipal: groups[i].Name,
                        DisplayName: displayName,
                        EID: groups[i].Scope,
                        IsGroup: true
                    };

                    vm.selectedAssignedTo.push(groupsAssignee);
                }
            }

            vm.invalidAssignedTo = false;

            if (taskDetails.Links == null && vm.Readonly == true) {
                vm.DisplayName = vm.LocalizedStrings.No_links_added;

            }

            if (taskDetails.Links != null) {
                for (var i = 0; i < taskDetails.Links.length; i++) {
                    vm.showlinkContainer = true;
                    vm.showlinkContainer = vm.showlinkContainer;
                    var lnkDetails = {
                        Url: taskDetails.Links[i].Link,
                        DisplayName: taskDetails.Links[i].DisplayName

                    };
                    vm.links.push(lnkDetails);
                    vm.Link = '';
                    vm.DisplayName = '';
                }
            }

            if (taskDetails.Attachments == null && vm.Readonly == true) {
                vm.AttachDisplayName = vm.LocalizedStrings.No_documents_uploaded;
            }
            if (taskDetails.Attachments != null) {
                for (var i = 0; i < taskDetails.Attachments.length; i++) {
                    vm.showAttachmentContainer = true;
                    vm.showAttachmentContainer = vm.showAttachmentContainer;

                    var fileNameandPath = taskDetails.Attachments[i].FileName.split(";");
                    var attachdetails = {
                        Attachfile: fileNameandPath[1],
                        AttachDisplayName: taskDetails.Attachments[i].DisplayName,
                        Name: fileNameandPath[0]

                    };
                    vm.attachments.unshift(attachdetails);

                }
            }



            if (isRecurringTemplate == true) {
                var cornExpression = taskDetails.CronExpression;
                clearRecurrenceValues();

                setTimeout(function () {
                    if (taskDetails.RangeEndTime != null && taskDetails.RangeEndTime != "") {
                        var dateWithHourAndMin = kendo.parseDate(utility.toLocalDate(taskDetails.RangeEndTime), utility.getCustomDateFormat());
                        vm.recurrenceEndTime = kendo.toString(dateWithHourAndMin, utility.getCustomDateFormat());
                    }

                    if (vm.recurrenceEndTime != "") {
                        vm.recurrenceRange = "EndBy";
                    }
                    else {
                        vm.recurrenceRange = "NoEndDate";
                    }

                    vm.rdbRecurShift = taskDetails.IsShiftTask;
                    if (taskDetails.IsShiftTask) {

                    }
                    setCronExporession(cornExpression);
                    try {
                        $scope.$apply();
                    }
                    catch (err) {
                    }
                }, 10);


            }
        }

        vm.rdbRecurShiftChange = function () {
            vm.ShiftNames = [];

            if ($scope.vm.rdbRecurShift == false)
                $scope.vm.rdbRecurShift = true;
            else
                $scope.vm.rdbRecurShift = false;

            if ($scope.vm.rdbRecurShift == true) {
                var resourceId = appContext.getNodeId();
                var startTime = appContext.getStartTime();
                taskService.getRotationDetailsForAsset(resourceId, startTime)
                  .then(function (rotationDetails) {
                      if (!utility.isError(rotationDetails)) {
                          populateShiftDetails(rotationDetails, null);
                      }
                  });
            }
        }


        function populateShiftDetails(rotationDetails, selectedShiftName) {
            vm.ShiftNames = [];
            vm.errInvalidShift = "";
            var isShiftNamePresent = false;

            if (rotationDetails.Rotation != null && rotationDetails.Rotation.ShiftNames != null && rotationDetails.Rotation.ShiftNames.length > 0) {
                for (var i = 0 ; i < rotationDetails.Rotation.ShiftNames.length; i++) {
                    var shiftName = rotationDetails.Rotation.ShiftNames[i];
                    var rotationName = rotationDetails.Rotation.RotationName;

                    vm.ShiftNames.push({ "RotationName": rotationName, "ShiftName": shiftName });

                    if (isShiftNamePresent == false && selectedShiftName != null && selectedShiftName != "" && selectedShiftName == shiftName) {
                        isShiftNamePresent = true;
                    }
                }

                setTimeout(function () {
                    if (selectedShiftName != null && selectedShiftName != "") {
                        if (isShiftNamePresent == true) {
                            vm.shiftRotationDropDown.value(selectedShiftName);

                        }
                        else {
                            vm.shiftRotationDropDown.value(vm.ShiftNames[0].ShiftName);
                            vm.errInvalidShift = "Shift name '" + selectedShiftName + "' is got removed/modified. Please select appropriate shift name.";

                        }
                    }
                    else {
                        vm.shiftRotationDropDown.value(vm.ShiftNames[0].ShiftName);
                    }

                }, 100);

            }
        }


        function initializeAssignee(response) {
            vm.AssignedToDatasource = response;

            vm.multiSelectAssignedToOptions = {
                placeholder: "Assignees",
                dataTextField: "DisplayName",
                dataValueField: "UserPrincipal",
                valuePrimitive: true,
                autoBind: false,
                dataSource: vm.AssignedToDatasource,
                filter: "contains",
                clearButton: true
            };
        }




        function getTaskDetails() {
            taskService.getTaskDetails(1)
           .then(function (data) {
               if (!utility.isError(response)) {
                   if (response != undefined) {
                       //console.log("dataTask ", data);
                   }
               }
           });
        }



        function newPriorityEditPopup($event, id, value, name) {

            $event.preventDefault();
            title = vm.LocalizedStrings.Edit_Priority;
            $scope.createNewPriority.title(title);
            vm.priorityName = name;
            vm.priorityValue = value;
            vm.selectedPriorityId = id;
            $scope.createNewPriority.center();
            $scope.createNewPriority.open();

        }

        function newPriorityPopup() {

            title = vm.LocalizedStrings.Add_Priority;
            $scope.createNewPriority.title(title);
            vm.priorityName = '';
            vm.priorityValue = '';
            $scope.createNewPriority.center();
            $scope.createNewPriority.open();

        }

        function onPriorityCancel() {
            $scope.createNewPriority.close();
        }

        function onPrioritySave() {
            var pname = vm.priorityName;
            var pvalue = vm.priorityValue;
            var pid = vm.selectedPriorityId;
            if (pname == "") {
                notifications.error(vm.LocalizedStrings.No_priorityname, false, true);
            }
            else if (pvalue == "") {
                notifications.error(vm.LocalizedStrings.No_priorityvalue, false, true);
            }
            else {
                if (pid == "" || pid == undefined) {
                    taskService.createPriority(pname, pvalue)
                    .then(function (data) {
                        if (!utility.isError(data)) { // to handle our custom errors
                            $scope.createNewPriority.close();
                            notifications.success(vm.LocalizedStrings.New_priority_created_successfully, false, true);
                            resetPriorityAfterAddEdit(true, pvalue);
                        }
                        vm.selectedPriorityId = "";
                    });
                }
                else {
                    taskService.updatePriority(pname, pvalue, pid)
                    .then(function (data) {
                        if (!utility.isError(data)) { // to handle our custom errors
                            $scope.createNewPriority.close();
                            notifications.success(vm.LocalizedStrings.Priority_updated_successfully, false, true);
                            resetPriorityAfterAddEdit(true, pvalue);
                        }
                        vm.selectedPriorityId = "";
                    });
                }
            }

        }

        function resetPriorityAfterAddEdit(isPriorityChange, valueToSelect) {
            updateConfigData(isPriorityChange, valueToSelect); //refreshing priority dropdown with updated values
            //vm.priorityName = "";
            //vm.priorityValue = "";

        }

        function newTypePopup() {
            title = vm.LocalizedStrings.Add_Type;
            $scope.createNewType.title(title);
            vm.typeDisplayName = '';
            vm.typeName = '';
            $scope.createNewType.center();
            $scope.createNewType.open();

        }

        function newTypeEditPopup($event, id, name, dname) {
            $event.preventDefault();
            vm.typeDisplayName = dname;
            vm.typeName = name;
            vm.selectedTypeId = id;
            title = vm.LocalizedStrings.Edit_Type;
            $scope.createNewType.title(title);
            $scope.createNewType.center();
            $scope.createNewType.open();

        }

        function onTypeCancel() {
            $scope.createNewType.close();
        }

        function onTypeSave() {
            var tdisname = vm.typeDisplayName;
            var tname = vm.typeName;
            var tid = vm.selectedTypeId;
            if (tdisname == "") {
                notifications.error(vm.LocalizedStrings.No_typedisplayname, false, true);
            }
            else if (tname == "") {
                notifications.error(vm.LocalizedStrings.No_typename, false, true);
            }
            else {
                if (tid == "" || tid == undefined) {
                    taskService.createType(tdisname, tname)
                    .then(function (data) {
                        if (!utility.isError(data)) { // to handle our custom errors
                            $scope.createNewType.close();

                            notifications.success(vm.LocalizedStrings.New_type_created_successfully, false, true);
                            resetTypeAfterAddEdit(false, tname);
                        }
                        vm.selectedTypeId = "";
                    });
                }
                else {
                    taskService.updateType(tdisname, tname, tid)
                    .then(function (data) {
                        if (!utility.isError(data)) { // to handle our custom errors
                            $scope.createNewType.close();
                            notifications.success(vm.LocalizedStrings.Type_updated_successfully, false, true);
                            resetTypeAfterAddEdit(false, tname);
                        }
                        vm.selectedTypeId = "";
                    });
                }
            }
        }

        function resetTypeAfterAddEdit(isPriorityChange, valueToSelect) {
            updateConfigData(isPriorityChange, valueToSelect); //refreshing type dropdown with updated values
            //vm.typeDisplayName = "";
            //vm.typeName = "";

        }

        function updateConfigData(isPriorityChange, valueToSelect) {

            taskService.getTaskConfigData(appContext.getAssetName())
            .then(function (response) {
                appContext.setConfigData(response);
                vm.PriorityDatasource = response.ConfigData.TaskPriorities;
                vm.TypeDatasource = response.ConfigData.TaskTypes;
                $scope.$emit("UpdateConfigData");

                if (isPriorityChange) {
                    vm.invalidPriority = false;
                    setTimeout(function () { vm.ddlPriority.value(valueToSelect); }, 100);
                }
                else {
                    vm.invalidType = false;
                    setTimeout(function () { vm.typeDropDown.value(valueToSelect); }, 100);


                }
            });
        }

        function getAddorUpdateTaskData() {
            var unformattedTaskDescription = $('<div>' + vm.taskDescription + '</div>').text();
            var data = {};
            data.TaskDetail = {
                AssetName: appContext.getAssetName(),
                AssetDisplayName: appContext.getAssetDisplayName(),
                EquipmentId: appContext.getAssetId(),
                TaskId: vm.TaskId,
                TaskName: vm.TaskName,
                StartDate: utility.toUTCDate(vm.tasksStrtDateTime, false),
                EndDate: utility.toUTCDate(vm.tasksEndDateTime, false),
                PriorityOrder: vm.ddlPriority.value(),
                ActualStartTime: " ",
                ActualEndTime: " ",
                State: "Draft",
                TemplateId: vm.TemplateId,
                TypeName: vm.typeDropDown.value(),
                CarryOverDays: parseInt(vm.carryOverDayValue),
                CarryOverHours: parseInt(vm.carryOverHourValue),
                TaskDescription: vm.taskDescription,
                PlainDescription: unformattedTaskDescription,
                AssignedTo: vm.multiselectAssignedTo.dataItems(),
                LinkDetails: vm.links,
                AttachmentDetails: vm.attachments,
                RecurrenceEndDate: "",
            }

            if (vm.isTimeBasedRecurrenceEnabled) {

                if (!isValidCornExpression()) {
                    return;
                }

                data.TaskDetail.CronExpression = getCronExpression();

                data.TaskDetail.IsShiftTask = vm.rdbRecurShift;
                var selectedShiftName = "";
                var rotationName = "";
                if (vm.rdbRecurShift == true) {
                    selectedShiftName = vm.shiftRotationDropDown.value();
                    rotationName = "";
                    for (var i = 0 ; i < vm.ShiftNames.length; i++) {
                        if (vm.ShiftNames[i].ShiftName == selectedShiftName) {
                            rotationName = vm.ShiftNames[i].RotationName;
                            break;
                        }
                    }
                    rotationName = appContext.getNodeId() + "###" + rotationName;
                }

                data.TaskDetail.RotationName = rotationName;
                data.TaskDetail.ShiftName = selectedShiftName;

                if (vm.recurrenceRange == "NoEndDate") {
                    data.TaskDetail.RecurrenceEndDate = null;
                }
                else {
                    var d = kendo.parseDate(vm.recurrenceEndTime, utility.getCustomDateFormat());
                    d.setHours(23);
                    d.setMinutes(59);
                    var recurrenceEndTime = kendo.toString(d, utility.getCustomDateTimeFormat());
                    data.TaskDetail.RecurrenceEndDate = utility.toUTCDate(recurrenceEndTime, false);
                }
            }

            return data;
        }

        function saveTaskDetails() {
            vm.validateAssignedTo();
            vm.validateTaskDescription();
            vm.validateType();
            vm.validatePriority();


            if (!validateTaskForm() || vm.taskForm.startTime.$error.endbeforestart || vm.invalidTaskDescription || vm.invalidAssignedTo
                || vm.invalidType || vm.invalidPriority) {
                if (vm.taskForm.url_filed.$error.pattern) {
                    //vm.accordianTwo = false;
                    $("#txtUrl").focus();
                }
                else {
                    //vm.accordianOne = false;
                    focusRequiredFields();
                }

                return;
            }

            var taskDetails = getAddorUpdateTaskData();


            if (vm.isTimeBasedRecurrenceEnabled == false) {
                taskService.setTasks(taskDetails)
                .then(function (response) {
                    if (!utility.isError(response)) {
                        if (response.Data[0].Status == "True") {
                            vm.TaskId = response.Data[0].Reference;
                            notifications.success(vm.LocalizedStrings.Task_saved_successfully, false, true);
                            $scope.$emit("TaskSaved");
                        }
                        else {

                            if (response.Data != null && response.Data.indexOf("Error") > -1) {
                                response.Data = response.Data.replace("Error", "").replace(":", "");
                                notifications.error(response.Data, false, true);
                            }
                            else {
                                notifications.error(response.Data[0].Message, false, true);
                            }
                        }
                    }
                });
            }
            else {
                if (isValidCornExpression()) {
                    taskService.setTaskTemplates(taskDetails)
                    .then(function (response) {
                        if (!utility.isError(response)) {
                            if (response[0].CommonOperationResult.Status == "True") {
                                vm.TaskId = "";
                                vm.TemplateId = response[0].TaskTemplate.TaskTemplateId;
                                notifications.success("Task recurrence saved successfully", false, true);
                                $scope.$emit("TaskSaved");
                            }
                            else {
                                notifications.error(response[0].CommonOperationResult.Message, false, true);
                            }
                        }
                    });
                }
            }

        }

        function focusRequiredFields() {
            if (vm.TaskName == "") {
                $('#taskName').focus();
            }
            else if (vm.tasksStrtDateTime == "") {
                $('#startTime').focus();
            }
            else if (vm.tasksEndDateTime == "") {
                $('#endTime').focus();
            }
            else if (!vm.selectedAssignedTo.length) {
                vm.multiselectAssignedTo.focus();
            }
            else if (vm.taskDescription == "") {
                vm.kendotaskDescroptionOptions.focus();
                $('#taskDescription').focus();
                vm.isActiveTaskDetails = false;


            }
        }

        function addLinks() {
            //validateurl();
            var addTaskLinks = {
                Url: vm.Url,
                DisplayName: vm.DisplayName
            };
            if (addTaskLinks != null && addTaskLinks.Url !== undefined && addTaskLinks.Url !== "") {
                vm.emptyurl = false;
                if (addTaskLinks.Url != '' && addTaskLinks.DisplayName != '' && addTaskLinks.DisplayName != undefined) {
                    vm.links.unshift(addTaskLinks);
                    vm.showlinkContainer = true;
                    vm.showlinkContainer = vm.showlinkContainer;
                }
                else {

                    if (addTaskLinks.DisplayName == '' || addTaskLinks.DisplayName == null || addTaskLinks.DisplayName == undefined) {
                        addTaskLinks.DisplayName = addTaskLinks.Url;
                    }
                    vm.links.unshift(addTaskLinks);
                    vm.showlinkContainer = true;
                    vm.showlinkContainer = vm.showlinkContainer;
                }
                vm.SelectedLink = {};
                //vm.link = 
                vm.Url = '';
                vm.DisplayName = '';

            }
            else {
                vm.emptyurl = true;
                //alert("else condition");
            }
        }


        function delLinks(index) {

            vm.links.splice(index, 1);
            utility.makePageDirty();
        }

        function getSupportedFilesAndMaxFileSize() {
            taskService.getAttachmentConfigurations()
                              .then(function (dataResult) {
                                  if (!utility.isError(dataResult)) {
                                      if (dataResult.AttachmentConfiguration) {
                                          for (var i = 0; i < dataResult.AttachmentConfiguration.length; i++) {
                                              if (dataResult.AttachmentConfiguration[i].Name == "Attachments_SupportedFiles")
                                                  vm.AttachmentSupportedExtentions = dataResult.AttachmentConfiguration[i].LookupValue;
                                              else if (dataResult.AttachmentConfiguration[i].Name == "Attachments_MaxFileSize")
                                                  vm.AttachmentMaxFileSizeBytes = dataResult.AttachmentConfiguration[i].LookupValue;
                                          }
                                      }
                                  }
                              });
        }

        function clearFileUploadControl() {
            angular.element("input[type='file']").val(null);
        }

        function addAttachment(element) {
            vm.isEmptyForm = false;
            $scope.$apply(function (scope) {
                vm.validateAssignedTo();
                vm.validateTaskDescription();
                vm.validateType();
                vm.validatePriority();
                if (!validateTaskForm() || vm.taskForm.startTime.$error.endbeforestart || vm.invalidTaskDescription || vm.invalidAssignedTo
                    || vm.invalidType || vm.invalidPriority) {
                    vm.emptyins = true;
                    //vm.accordianOne = false;
                    clearFileUploadControl();
                    return;
                }

                if (vm.TaskId == "" && vm.TemplateId == "") {
                    //if task is not saved for the first time , doing auto save



                    var taskDetails = getAddorUpdateTaskData();


                    if (vm.isTimeBasedRecurrenceEnabled == false) {
                        taskService.setTasks(taskDetails)
                        .then(function (response) {
                            if (!utility.isError(response)) {
                                if (response.Data[0].Status == "False") {
                                    notifications.error(response.Data[0].Message, false, true);
                                }
                                else {
                                    vm.TaskId = response.Data[0].Reference;
                                    vm.TemplateId = "";
                                    uploadAttachment(element);
                                }
                            }
                        }, function (error) {
                            clearFileUploadControl();
                        });
                    }
                    else {
                        if (isValidCornExpression()) {
                            taskService.setTaskTemplates(taskDetails)
                            .then(function (response) {
                                if (!utility.isError(response)) {
                                    if (response[0].CommonOperationResult.Status == "False") {
                                        notifications.error(response[0].CommonOperationResult.Message, false, true);
                                    }
                                    else {
                                        vm.TaskId = "";
                                        vm.TemplateId = response[0].TaskTemplate.TaskTemplateId;
                                        uploadAttachment(element);
                                    }
                                }
                            }, function (error) {
                                clearFileUploadControl();
                            });
                        }
                    }


                }
                else {
                    uploadAttachment(element);
                }
                utility.makePageDirty();
            });
        }

        function uploadAttachment(element) {
            //check for the file count
            if (element.files != null && element.files.length > 0) {
                var filesList = [];
                logger.debug(element.files);

                var isValidationSuccess = true;

                for (var i = 0; i < element.files.length; i++) {
                    var file = element.files[i];
                    if (vm.attachments && vm.attachments.length > 0) {
                        //throw message if the same file exists already         
                        angular.forEach(vm.attachments, function (existingAttachment) {
                            if (existingAttachment.AttachDisplayName == file.name && isValidationSuccess) {
                                notifications.error(vm.LocalizedStrings.FileName_Exist, false, true);
                                clearFileUploadControl();
                                isValidationSuccess = false;
                                return;
                            }
                        });

                        if (!isValidationSuccess) {
                            break;
                            return;
                        }
                    }
                    var newFileDetail = { name: file.name, size: file.size, type: file.type, isValid: false, validationMessage: "" };

                    //file  validation for size and extensions
                    isValidationSuccess = isValidationSuccess && ValidateFileSelected(newFileDetail);
                    if (isValidationSuccess) {
                        filesList[newFileDetail.name] = newFileDetail;
                    }
                    else {
                        clearFileUploadControl();
                        notifications.error(newFileDetail.validationMessage, false, true);
                        break;
                    }
                }
                if (isValidationSuccess)
                    //hardcoded task id
                    //vm.TaskId = 'AADCC89B-7439-420C-A1C6-179FABB95819';
                    var taskOrTemplateId = vm.TaskId;
                if (vm.isTimeBasedRecurrenceEnabled == true) {
                    taskOrTemplateId = vm.TemplateId;
                }
                taskService.addAttachment(element.files, filesList, taskOrTemplateId)
                                       .then(function (dataResult) {
                                           if (!utility.isError(dataResult)) {
                                               for (var i = 0; i < dataResult.data.length; i++) {
                                                   if (dataResult.data[i].IsUploaded) {
                                                       vm.attachments.unshift({
                                                           Attachfile: dataResult.data[i].ServerURL,
                                                           Name: dataResult.data[i].FileName,
                                                           AttachDisplayName: dataResult.data[i].FileName
                                                       });
                                                   }
                                                   else {
                                                       notifications.error(dataResult.data[i].StatusMessage, false, true);
                                                   }
                                               }
                                               clearFileUploadControl();
                                           }
                                       });
            }

        }

        function ValidateFileSelected(fileDetail) {
            //Validate Size and Extension    
            fileDetail.isValid = true;
            if (fileDetail.size > (vm.AttachmentMaxFileSizeBytes)) {
                fileDetail.isValid = false;
                fileDetail.validationMessage = vm.LocalizedStrings.Validation_File_size_exceeds;
            }
            else if (CheckFileExtension(fileDetail.name)) {
                fileDetail.isValid = true;
                fileDetail.validationMessage = vm.LocalizedStrings.Validation_Successful;
            }
            else {
                fileDetail.isValid = false;
                var fileextArr = fileDetail.name.split('.');
                fileDetail.validationMessage = vm.LocalizedStrings.Validation_File_Extension + " '." + fileextArr[fileextArr.length - 1] + "' " + vm.LocalizedStrings.is_not_supported;
            }
            return fileDetail.isValid;

        }

        function CheckFileExtension(filename) {
            var supportedExtentions = vm.AttachmentSupportedExtentions.split(",");
            var hash = {};
            for (var i = 0, l = supportedExtentions.length; i < l; i++) {
                hash[supportedExtentions[i]] = true;
            }

            var re = /\.[^.]*$/;
            var ext = filename.match(re);

            if (hash[ext])
                return true;
            else
                return false;
        }

        function delAttachments(index) {

            vm.attachments.splice(index, 1);
            utility.makePageDirty();
        }



        //drop down for Carry over hours
        vm.carryOverHourDatasource = [
            { HourName: "0", HourValue: "0" },
            { HourName: "1", HourValue: "1" },
            { HourName: "2", HourValue: "2" },
            { HourName: "3", HourValue: "3" },
            { HourName: "4", HourValue: "4" },
            { HourName: "5", HourValue: "5" },
            { HourName: "6", HourValue: "6" },
            { HourName: "7", HourValue: "7" },
            { HourName: "8", HourValue: "8" },
            { HourName: "9", HourValue: "9" },
            { HourName: "10", HourValue: "10" },
            { HourName: "11", HourValue: "11" },
            { HourName: "12", HourValue: "12" },
            { HourName: "13", HourValue: "13" },
            { HourName: "14", HourValue: "14" },
            { HourName: "15", HourValue: "15" },
            { HourName: "16", HourValue: "16" },
            { HourName: "17", HourValue: "17" },
            { HourName: "18", HourValue: "18" },
            { HourName: "19", HourValue: "19" },
            { HourName: "20", HourValue: "20" },
            { HourName: "21", HourValue: "21" },
            { HourName: "22", HourValue: "22" },
            { HourName: "23", HourValue: "23" },
        ];


        vm.carryOverHourDDOptions = {
            dataSource: vm.carryOverHourDatasource,
            dataTextField: "HourName",
            dataValueField: "HourValue",
            autoBind: 'true'
        };
        //end drop down for Carry over hours



        //dropdown for type
        //vm.TypeDatasource = [
        //   { typeName: "1", typeValue: "1" },
        //   { typeName: "2", typeValue: "2" },
        //   { typeName: "3", typeValue: "3" },
        //   { typeName: "4", typeValue: "4" },
        //   { typeName: "5", typeValue: "5" },
        //   { typeName: "6", typeValue: "6" }
        //];


        vm.shiftRotationOptions = {
            height: 400,
            valueTemplate: '<span class="selected-value"" title="{{dataItem.ShiftName}}">{{dataItem.ShiftName}}</span>',
            template: '<span class="k-state-default" title="{{dataItem.ShiftName}}">{{dataItem.ShiftName}}</span>',
            placeholder: "Shift name",
        };



        vm.kendotaskDescroptionOptions = {

            resizable: {
                content: true,
                toolbar: true
            },
            pasteCleanup: {
                none: true
            },
            tools: [
                         "bold",
                         "italic",
                         "underline",
                         "strikethrough",
                         "foreColor",
                         "backColor",
                         "cleanFormatting",
                         "justifyLeft",
                         "justifyCenter",
                         "justifyRight",
                         "justifyFull",
                         "insertUnorderedList",
                         "insertOrderedList",
                         "indent",
                          "createTable",
                          "addRowAbove",
                          "addRowBelow",
                          "addColumnLeft",
                          "addColumnRight",
                          "deleteRow",
                          "deleteColumn",

                         "fontSize",
                         {
                             name: "fontName",
                             items: [
                                          { text: "Andale Mono", value: "Andale Mono" },
                                          { text: "Arial", value: "Arial" },
                                          { text: "Arial Black", value: "Arial Black" },
                                          { text: "Comic Sans MS", value: "Comic Sans MS" },
                                          { text: "Courier New", value: "Courier New" },
                                          { text: "Garamond", value: "Garamond, serif" },
                                          { text: "Georgia", value: "Georgia" },
                                          { text: "Impact", value: "Impact" },
                                          { text: "Times New Roman", value: "Times New Roman" },
                                          { text: "Trebuchet MS", value: "Trebuchet MS" },
                                          { text: "Verdana", value: "Verdana" },
                                          { text: "Webdings", value: "Webdings" }
                             ]
                         }
            ]
        }

        //For kendo editor
        var defaultTools = kendo.ui.Editor.defaultTools;
        defaultTools["insertLineBreak"].options.shift = true;
        defaultTools["insertParagraph"].options.shift = true;

        vm.initialize = function () {
            getSupportedFilesAndMaxFileSize();
            getLocalizedMessages();

            $scope.$watch('vm.tasksStrtDateTime', EnddatebeforeStartdate);
            $scope.$watch('vm.tasksEndDateTime', EnddatebeforeStartdate);
            $("#createNew").focus();
        }



        function loadConfigData(isEditTask, data, isVirtualTask) {
            vm.isTimeBasedRecurrenceEnabled = false;

            resetAddEditTaskForm();
            ConfigSecurityAccess().then(function (securityResults) {
                if (securityResults) {
                    $q.all([
                        getTaskConfigData(), getUsers()
                    ]).then(function (configResults) {
                        //check if all the config data loaded 
                        if (configResults.indexOf(false) == -1) {
                            if (isEditTask) {

                                if (isVirtualTask == true) {
                                    var templateId = data.templateId;
                                    taskService.getTaskTemplateDetail(data.templateId)
                                    .then(function (taskTemplateResult) {
                                        if (!utility.isError(taskTemplateResult)) {
                                            if (taskTemplateResult != undefined) {
                                                if (taskTemplateResult.GetTaskTemplatesDetailResult && taskTemplateResult.GetTaskTemplatesDetailResult.length > 0) {


                                                    if (taskTemplateResult.GetTaskTemplatesDetailResult[0].TaskTemplateDetail.IsShiftTask == true) {

                                                        var resourceId = taskTemplateResult.GetTaskTemplatesDetailResult[0].TaskTemplateDetail.RotationName.split("###")[0];
                                                        var startTime = appContext.getStartTime();
                                                        var selectedShiftName = taskTemplateResult.GetTaskTemplatesDetailResult[0].TaskTemplateDetail.ShiftName;

                                                        taskService.getRotationDetailsForAsset(resourceId, startTime)
                                                           .then(function (rotationDetails) {
                                                               if (!utility.isError(rotationDetails)) {
                                                                   populateShiftDetails(rotationDetails, selectedShiftName);
                                                                   populateTaskForm(taskTemplateResult.GetTaskTemplatesDetailResult[0], true);
                                                               }
                                                           });

                                                    }
                                                    else {
                                                        populateTaskForm(taskTemplateResult.GetTaskTemplatesDetailResult[0], true);

                                                    }

                                                }
                                                else {
                                                    notifications.error("Fetching task details failed. Please contact the system administrator", false, true);
                                                }

                                            }
                                        }
                                    });

                                    vm.isTimeBasedRecurrenceEnabled = isVirtualTask;


                                }
                                else {
                                    taskService.getTaskDetails(data.taskId)
                                        .then(function (response) {
                                            if (!utility.isError(response)) {
                                                if (response != undefined) {
                                                    if (response.Tasks && response.Tasks.length > 0) {
                                                        populateTaskForm(response.Tasks[0], false);
                                                    }
                                                    else {
                                                        notifications.error("Fetching task details failed. Please contact the system administrator", false, true);
                                                    }
                                                }
                                            }
                                        });
                                }
                            }
                        }
                        else {
                            notifications.error("Fetching configuration data failed. Please contact the system administrator", false, true);
                        }
                    });
                }
                else {
                    notifications.error("Fetching security failed. Please contact the system administrator", false, true);
                }
            });
        }




        function checkSecurityAccess(securityOperations) {
            var deferred = $q.defer();
            taskService.checkAssetAccessForUser(appContext.getAssetName(), securityOperations)
                               .then(function (data) {
                                   if (!utility.isError(data)) {
                                       for (var i = 0; i < data.length; i++) {
                                           if (data[i].Key == "DOTConfigureSetting")
                                               vm.securityConfigureSetting = data[i].Value;
                                       }
                                       deferred.resolve(true);
                                   }
                                   else {
                                       deferred.resolve(false);
                                   }
                               });

            return deferred.promise;
        }

        //security related functions
        function DraftSecurityAccess() {
            var securityOperations = [];
            securityOperations.push("DOTEditTask");
            securityOperations.push("DOTConfigureSetting");
            return checkSecurityAccess(securityOperations);
        }

        function ConfigSecurityAccess() {
            var securityOperations = [];
            securityOperations.push("DOTConfigureSetting");
            return checkSecurityAccess(securityOperations);
        }

        function checkSecurityBasedOnStatus(status) {
            switch (status) {
                case "Draft":
                    return DraftSecurityAccess();
                    break;
                case "Planned":
                    return PlannedSecurityAccess();
                    break;
                case "Approved":
                    return PlannedSecurityAccess();
                    break;
                case "Scheduled":
                    return ScheduledSecurityAccess();
                    break;
                case "Activated":
                    return ActivateSecurityAccess();
                    break;
                case "Completed":
                    return ActivateSecurityAccess();
                    break;
                case "Rejected":
                    return DraftSecurityAccess();
                    break;
                default:
            }
        }


        $scope.$on("Intuition.ActionBarItemClicked", actionbarClicked);

        function actionbarClicked(event, actionText) {
            if (actionText == "TASKS_SAVE") {
                $scope.$apply(function () {
                    vm.saveTaskDetails();
                });
            }
        }
    }

    function dosLink() {
        var directive = {
            replace: true,
            scope: {
                remove: "&onRemove",
                link: "=data",
                iconstatus: "=iconstatus",
                istemplate: "=istemplate",
                readonly: "=readonly",
                islinks: "=islinks",
                index: "@"
            },
            link: function (scope, element, attrs) {
                var oldvaue = {};
                scope.edit = function () {
                    oldvaue["Url"] = scope.link.Url;
                    oldvaue["DisplayName"] = scope.link.DisplayName;
                    scope.showme = true;
                }
                scope.save = function () {
                    if (scope.link.Url == '' || scope.link.Url == null) {
                        scope.showme = true;
                        return false;
                    }
                    else {
                        var url = scope.link.Url;
                        var pattern = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
                        if (pattern.test(url)) {
                            scope.showme = false;
                            oldvaue = {};
                            return true;
                        }
                        else {
                            scope.showme = true;
                            return false;
                        }
                    }
                }
                scope.cancel = function () {
                    scope.link.Url = oldvaue.Url;
                    scope.link.DisplayName = oldvaue.DisplayName;
                    oldvaue = {};
                    scope.showme = false;
                }
            },
            restrict: "E",
            controllerAs: "link",
            templateUrl: "../app/tasks/links.html"
        };
        return directive;
    }

    function dosAttachment() {

        var directive = {
            replace: true,

            scope: {
                remove: "&onRemove",
                attachment: "=data",
                iconstatus: "=iconstatus",
                istemplate: "=istemplate",
                readonly: "=readonly",
                index: "@"
            },

            link: function (scope, element, attrs) {
                var oldvalue = {};

                scope.edit = function () {
                    oldvalue["Attachfile"] = scope.attachment.Attachfile;
                    oldvalue["AttachDisplayName"] = scope.attachment.AttachDisplayName;
                    scope.showme = true;
                }
                scope.save = function () {
                    scope.showme = false;
                    oldvalue = {};
                }
                scope.cancel = function () {
                    scope.attachment.Attachfile = oldvalue.Attachfile;
                    scope.attachment.AttachDisplayName = oldvalue.AttachDisplayName;
                    oldvalue = {};
                    scope.showme = false;
                }
            },
            restrict: "E",
            controllerAs: "attachment",
            templateUrl: "../app/tasks/attachments.html"

        };
        return directive;
    }



})();



