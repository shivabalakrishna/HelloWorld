﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview startup module for the application 
* @author Badrinarayana G.V
*/

(function () {
    'use strict';
    angular.module('app.tasks.module', []);

})();

