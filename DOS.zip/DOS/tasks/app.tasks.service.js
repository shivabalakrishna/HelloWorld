(function () {
    'use strict';

    angular.module('app.tasks.module')
           .factory("app.tasks.service", taskService)

    taskService.$inject = ['app.common.httpService', 'app.common.appcontext.factory'];

    function taskService(httpService, appContext) {

        var service = {
            getGrouppedTasks: getGrouppedTasks,
            getTaskConfigData: getTaskConfigData,
            setTasks: setTasks,
            getTaskDetails: getTaskDetails,
            createPriority: createPriority,
            updatePriority: updatePriority,
            getAttachmentConfigurations: getAttachmentConfigurations,
            getUsers: getUsers,
            addAttachment: addAttachment,
            getAllTasks: getAllTasks,
            checkAssetAccessForUser: checkAssetAccessForUser,
            createType: createType,
            updateType: updateType,
            addComment: addComment,
            startTask: startTask,
            carryForwardTask: carryForwardTask,
            completeTask: completeTask,
            submitTask: submitTask,
            submitTaskTemplates: submitTaskTemplates,
            deleteTask: deleteTask,
            updatePercentComplete: updatePercentComplete,
            getAllTaskSummary: getAllTaskSummary,
            getAllComments: getAllComments,
            setTaskTemplates: setTaskTemplates,
            getTaskTemplateDetail: getTaskTemplateDetail,
            getRotationDetailsForAsset: getRotationDetailsForAsset
        };
        return service;

        function getGrouppedTasks(taskViewModel) {
            var data = {
                "taskViewModel": taskViewModel
            };
            return httpService.postData("GetGroupedTasks", data);
        }

        function getTaskConfigData(assetName) {
            var options = {};
            options.params = {
                AssetName: assetName
            };
            return httpService.getData("GetTaskConfigData", options);
        }

        function setTasks(taskDetails) {
            return httpService.postData("SetTasks", taskDetails);
        }


        function setTaskTemplates(taskDetails) {
            return httpService.postData("SetTaskTemplates", taskDetails);
        }

        function getTaskDetails(taskId) {
            var options = {};
            options.params = {
                TaskId: taskId
            };
            return httpService.getData("GetTaskDetail", options);
        }

        function getTaskTemplateDetail(taskTemplateId) {
            var options = {};
            options.params = {
                TaskTemplateId: taskTemplateId
            };
            return httpService.getData("GetTaskTemplateDetail", options);
        }

        function createPriority(pname, pvalue) {
            var options = {};
            options.TaskPriority = {
                PriorityDisplayName: pname,
                PriorityOrder: pvalue
            };
            return httpService.postData("SetTaskPriority", options);
        }
        function getRotationDetailsForAsset(resourceId, startTime) {
            var options = {};
            options.params = { resourceId: resourceId, startTime: startTime };
            return httpService.getData("GetRotationDetailsForAsset", options);
        }

        function updatePriority(pname, pvalue, pid) {
            var options = {};
            options.TaskPriority = {
                PriorityDisplayName: pname,
                PriorityOrder: pvalue,
                PriorityId: pid
            };
            return httpService.postData("SetTaskPriority", options);
        }

        function createType(tdisplayname, tname) {
            var options = {};
            options.TaskType = {
                TypeDisplayName: tdisplayname,
                TypeName: tname
            };
            return httpService.postData("SetTaskType", options);
        }

        function updateType(tdisplayname, tname, tid) {
            var options = {};
            options.TaskType = {
                TypeDisplayName: tdisplayname,
                TypeName: tname,
                TypeId: tid
            };
            return httpService.postData("SetTaskType", options);
        }

        function getAttachmentConfigurations() {
            var options = {};
            options.params = {
                //AssetName: assetName
            };
            return httpService.getData("GetAttachmentConfigurations", options);
        }

        function getUsers(assetName) {
            var options = {};
            options.params = {
                AssetName: assetName
            };
            return httpService.getData("GetUsers", options);
        }

        function addAttachment(files, filesList, taskId) {
            return httpService.uploadFiles("AddAttachment", files, filesList, taskId);
        }

        function getAllTasks(taskGridFilter) {
            var data = {
                "taskGridFilter": taskGridFilter
            };
            return httpService.postData("GetAllTasks", data);
        }

        function checkAssetAccessForUser(assetName, operationsList) {
            var options = {};
            options.params = { asset: assetName, operations: operationsList };
            return httpService.getData("CheckAssetAccessForUser", options);
        }

        function getAllTaskSummary(data) {
            return httpService.postData("GetAllTaskSummary", data);
        }

        function getAllComments(taskId, starttime) {
            var options = {};
            options.params = { TaskId: taskId, stime: starttime };
            return httpService.getData("GetAllComments", options)
        }

        //work flow actions
        function updatePercentComplete(data) {
            return httpService.postData("UpdateCompletionPercentOfTasks", data);
        }
        function submitTask(data) {
            return httpService.postData("SubmitTasks", data);
        }

        function submitTaskTemplates(taskTemplateId) {
            var data = { taskTemplateId: taskTemplateId };
            return httpService.postData("SubmitTaskTemplates", data);
        }

        function completeTask(data) {
            return httpService.postData("CompleteTasks", data);
        }
        function carryForwardTask(data) {
            return httpService.postData("CarryForwardTasks", data);
        }
        function startTask(data) {
            return httpService.postData("StartTasks", data);
        }


        function deleteTask(data) {
            return httpService.postData("DeleteTasks", data);
        }
        function addComment(data) {
            return httpService.postData("AddComments", data);
        }

    }
})();