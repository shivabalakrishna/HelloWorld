﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview startup module for the application 
* @author Badrinarayana G.V
*/

(function () {
    'use strict';

    angular.module('MeetingsApp', [

            'ngRoute', //for routing
            'pascalprecht.translate', // for localizing set of of strings partially
            'ngSanitize',
            //'ngPrint',

            'kendo.directives',  // to use kendo widgets           
            //'demo.module', //for demo purpose and samples, only for developers to refer
            // below are application moduls
            'app.core.config',
            'app.layout.module',
            'app.common.factory.module',
            'app.common.service.module',
            'app.common.directives.module',
            'app.common.utilities.module',
            'app.core.security.checkAccess',
            'app.meetings.module',
            'ngSanitize'

    ])
        .config(configure)
        .run(function ($rootScope) {

            //$rootScope.$on("$includeContentLoaded", function (event, url) {
            //    logger.debug(url);
            //});

            //$rootScope.$on("$includeContentError", function (event, url) {
            //    logger.debug(url);
            //});

            //$rootScope.$on("$includeContentRequested", function (event, url) {
            //    logger.debug(url);
            //});

            $rootScope.$on('$routeChangeStart', function (event, next, current) {
                //show loading gif                              
                $rootScope.$emit("showLoadingIcon");

                //var currentPath = current.originalPath;
                //var nextPath = next.originalPath;

                //logger.debug('Starting to leave %s to go to %s', currentPath, nextPath);
            });
            $rootScope.$on('$routeChangeSuccess', function () {
                //hide loading gif
                $rootScope.$emit("hideLoadingIcon");
            });
            $rootScope.$on('$routeChangeError', function () {
                //hide loading gif                
                $rootScope.$emit("hideLoadingIcon");
            });
        });

    configure.$inject = ['$routeProvider', '$locationProvider', '$translateProvider', '$httpProvider', '$compileProvider'];

    function configure($routeProvider, $locationProvider, $translateProvider, $httpProvider, $compileProvider) {

        $routeProvider
            .when('/meetings', {
                templateUrl: "../app/meetings/meetings.html",
                resolve: {
                    translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                        //$translatePartialLoader.addPart('instructions');
                        //$translatePartialLoader.addPart('common');                        

                        //$translateProvider.fallbackLanguage("en-US");
                        //return $translate.refresh();
                    }]
                }
            })
         .otherwise({
             templateUrl: "../app/meetings/meetings.html"
         });

        //only one digest cycle will run for multiple ajax request whose response receive around same time with in 10 ms
        $httpProvider.useApplyAsync(true);
        //$compileProvider.debugInfoEnabled(false);

        //since we are uisng only element directives, disabling below 2
        $compileProvider.commentDirectivesEnabled = false;
        $compileProvider.cssClassDirectivesEnabled = false;


        //$locationProvider.html5Mode(true);
        $translateProvider.preferredLanguage($("#CultureCode").val());
        $translateProvider.fallbackLanguage('en-US');


        $translateProvider.useLoader('$translatePartialLoader', {
            urlTemplate: 'app/resources/translation/{lang}/{part}.json',
        });


        if ($("#CultureCode").val() !== "en-US") {
            var cultureFileName = $("#CultureScriptToLoad").val().replace("en-IN", $("#CultureCode").val());
            var messageFileName = $("#messageScriptToLoad").val().replace("en-IN", $("#CultureCode").val());
            $("#CultureScript").html("<script src='" + cultureFileName + "'></script><script src='" + messageFileName + "'></script>");
            kendo.culture($("#CultureCode").val());
        }
        
        //logger.debug($("#CultureCode").val());
    }



    function getQueryStringByName(name, url) {
        if (!url) {
            url = window.location.href;
        }
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

})();
