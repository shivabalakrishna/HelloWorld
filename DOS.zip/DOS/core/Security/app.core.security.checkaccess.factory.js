﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview checkAccessFactory to check permission for views.
* @author Badrinarayana G V 
*/
(function () {
    'use strict';

    angular.module('app.core.security.checkAccess', [])
    .factory('app.core.security.checkAccessFactory', checkAccess);

    checkAccess.$inject = ['app.common.factory.loggerFactory'];

    function checkAccess(logger) {
        var service = {
            checkAccess: checkAccessFunction,
            checkAccessCallback: checkAccessCallBackFunction,
            hasAccess: false
        };

        return service;

        function checkAccessFunction(viewName) {
            try {
                Intuition.Security.CheckAccessAsync(viewName, service.checkAccessCallback);
            }
            catch (e) {
                logger.error("Error: " + e.Message);
            }
        };

        function checkAccessCallBackFunction(value) {
            logger.info("value: " + value);
            if (value) {
                logger.info('Access Granted');
            }
            else {
                logger.info('access rejected');
            }
            service.hasAccess = value;
        };
    };

})();