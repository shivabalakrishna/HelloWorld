﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview Configuration variables and setup 
* @author Badrinarayana G.V
*/

(function () {
    'use strict';

    var core = angular.module('app.core.config', []);

    var config = {
        appPrefix: '[DOS] ',
        appTitle: 'Instructions',
        version: '1.0.0'
    };

    core.constant('config', config);

    core.config(configure);

    configure.$inject = ['$logProvider'];

    function configure($logProvider) {
        // turn debugging off/on (no info or warn)
        if ($logProvider.debugEnabled) {
            $logProvider.debugEnabled(true);
        }
    }
})();
