﻿



(function () {
    'use strict';

    angular.module('app.meetings.module')
           .factory("app.meetings.service", meetingsService)

    meetingsService.$inject = ['app.common.httpService', 'app.common.appcontext.factory'];

    function meetingsService(httpService, appContext) {

        var service = {
            getMeetings: getMeetings,
            getMeetingTypes: getMeetingTypes,
            getCurrentUserInfo: getCurrentUserInfo,
            getUsersForAssetAndTask: getUsersForAssetAndTask,
            editMeetings: editMeetings,
            deleteMeetings: deleteMeetings,
            getMeetingDetails: getMeetingDetails,
            editMeetingType: editMeetingType,
            getMeetingTypeAttributes: getMeetingTypeAttributes,
            editMeetingTypeAttributes: editMeetingTypeAttributes,
            getTaskConfigData: getTaskConfigData,
            setTask: setTask,
            getTaskDetails: getTaskDetails,
            checkAssetAccessForUser: checkAssetAccessForUser
        };

        return service;

        function getMeetings(meetingSummaryFilter) {

            var data = {
                meetingSummaryFilter: meetingSummaryFilter
            };

            return httpService.postData("GetMeetings", data);
        }


        function editMeetings(meetingDetail) {
            var data = { meetingDetail: meetingDetail };
            return httpService.postData("EditMeetings", data);
        }

        function deleteMeetings(meetingId) {
            var options = {};
            options.params = { "meetingId": meetingId};
            return httpService.getData("DeleteMeetings", options);
        }

        function editMeetingType(meetingType) {
            var data = { meetingType: meetingType };
            return httpService.postData("EditMeetingType", data);
        }

        function getMeetingDetails(meetingId, assetName, meetingTypeName) {
            var options = {};
            options.params = { "meetingId": meetingId, "assetName": assetName, "meetingTypeName": meetingTypeName };
            return httpService.getData("GetMeetingDetails", options);
        }

        function getMeetingTypes() {
            var options = {};
            options.params = {};
            return httpService.getData("GetMeetingTypes", options);
        }


        function getCurrentUserInfo(assetName, operationName) {
            var options = {};
            options.params = { assetName: assetName, operationName: operationName };
            return httpService.getData("GetCurrentUserInfo", options);
        }

        function getUsersForAssetAndTask(assetName, operationName, usersSearchString) {
            var options = {};
            options.params = { assetName: assetName, operationName: operationName, usersSearchString: usersSearchString };
            return httpService.getData("GetUsersForAssetAndTask", options);

        }

        function getMeetingTypeAttributes(meetingTypeName, assetName, attributeName) {
            var options = {};
            options.params = { meetingTypeName: meetingTypeName, assetName: assetName, attributeName: attributeName };
            return httpService.getData("GetMeetingTypeAttributes", options);

        }

        function editMeetingTypeAttributes(meetingTypeAttribute) {
            var data = { meetingTypeAttribute: meetingTypeAttribute };
            return httpService.postData("EditMeetingTypeAttributes", data);
        }

        function getTaskConfigData(assetName) {
            var data = { assetName: assetName };
            return httpService.postData("GetTaskConfigData", data);
        }

        function setTask(task) {
            var data = { TaskDetail: task };
            return httpService.postData("SetTask", data);
        }

        function getTaskDetails(taskIds) {
            var data = { taskIds: taskIds };
            return httpService.postData("GetTaskDetails", data);
        }

        function checkAssetAccessForUser(assetName, operationsList) {
            var options = {};
            options.params = { asset: assetName, operations: operationsList };
            return httpService.getData("CheckAssetAccessForUser", options);
        }
    }

})();