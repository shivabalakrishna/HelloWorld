/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview startup module for the application 
* @author Badrinarayana G.V
*/
//localize all the values
//remove commented code
// private varibale , view  model variable, view model functions, events, service calls, private functions
//dont use scope for view model properties use only for angular events
//remove all the alerts and console logs

(function () {
    'use strict';

    angular.module('app.meetings.module')
           .controller("MeetingsController", MeetingsController)

    MeetingsController.$inject = ['$scope', '$window', '$translate', '$q', '$timeout', '$translatePartialLoader', '$document', '$rootScope', '$location', 'app.common.httpService', 'app.common.factory.loggerFactory',
                                      'app.common.factory.notificationsFactory', 'app.common.utilitiesFactory', 'app.common.appcontext.factory', 'app.meetings.service'];

    function MeetingsController($scope, $window, $translatee, $q, $timeout, $translatePartialLoader, $document, $rootScope, $location, httpService, logger, notifications, utility, appContext, meetingsService) {


        var vm = this;
        vm.hasEditMeetingPermission = false;
        vm.totalMeetings = 0;
        vm.displayedMeetingsCount = 0;
        vm.currentPageNumber = 0;
        vm.lastLoadedAsset = "";
        vm.dropDownValue = "";
        vm.dropDownAssetOptions = "";
        vm.attendee = false;
        vm.Note = '';
        vm.editorNote = '';
        $scope.class = "col-lg-12";
        vm.filter = false;
        vm.meetingSection = true;
        vm.accordianNote = false;
        vm.isActiveNote = false;
        vm.noMeetingsFoundLabel = "";

        vm.accordianCheckList = false;
        vm.isActiveCheckList = false;
        vm.isActiveTasksGrid = false;

        vm.addMeeting = false;
        vm.meetingInProgress = true;
        vm.meetingTitle = "";
        vm.accordianTaskDetail = false;
        vm.isActiveTaskDetail = false;
        vm.meetingBox = false;
        vm.typeBox = false;
        vm.createMeeting = false;
        vm.LocalizedStrings;
        vm.isMeetingCompleted = false;
        vm.confirmDialogPopupMessage = "";
        vm.confirmDialogPopupMessage2 = "";
        vm.isAllUsersSelected = false;
        vm.meetingDetail = null;
        vm.newEmailId = null;
        vm.searchedUser = null;
        vm.meeting_PK_ID = null;
        vm.isPageDirty = false;
        vm.showFilterPanel = false;
        vm.showOverLayer = false;
        vm.appliedFilter = null;
        vm.appliedFilterCount = 0;
        vm.currentMeetingAssetName = "";
        vm.disableNewActionButton = false;
        vm.taskConfigData = null;
        vm.showTaskEditPanel = true;
        vm.currentMeetingParticipants = [];
        vm.currentMeetingsTaskCollections = [];
        vm.disableTaskEditControl = false;
        vm.isTaskPanelExpanded = false;
        vm.isNotesPanelExpanded = false;
        vm.newTask = {
            "TaskId": "00000000-0000-0000-0000-000000000000",
            "Name": null,
            "Type": null,
            "Description": null,
            "AssignedTo": null,
            "TaskPriority": null,
            "TaskPlannedStartDate": null,
            "TaskPlannedEndDate": null,
            "TaskCarryOverDayValue": null,
            "TaskCarryOverHourValue": null,
            "ErrName": "",
            "ErrType": "",
            "ErrDescription": "",
            "ErrAssignedTo": "",
            "ErrTaskPriority": "",
            "ErrTaskPlannedStartDate": "",
            "ErrTaskPlannedEndDate": "",
            "ErrTaskCarryOverDayValue": "",
            "ErrTaskCarryOverHourValue": "",
        }

        //vm.newTask_Name = null;
        //vm.newTask_Type = null;
        //vm.newTask_Details = null;
        //vm.newTask_AssignedTo = null;
        //vm.newTask_TaskPriority = null;
        //vm.newTask_TaskPlannedStartDate = null;
        //vm.newTask_TaskPlannedEndDate = null;
        //vm.newTask_TaskCarryOverDayValue = null;
        //vm.newTask_TaskCarryOverHourValue = null;



        vm.meetings = [];
        vm.meetingTypes = [];
        vm.lastLoadedMeetingsCount = -1;
        vm.currentUserInfo = null;
        vm.allParticipantsForThisMeeting = [];
        vm.allUsersForThisAsset = [];
        vm.allMeetingLeaders = [];

        vm.allAssigneeList = [];

        vm.meetingTypeAttributes = [];

        vm.loadedAsset = "";

        vm.makePageDirty = makePageDirty;
        vm.confirmDialogNoClickCallBackFunction;

        vm.hidePaticpantsPanel = hidePaticpantsPanel;

        vm.onFilterPanelMeetingTypeClick = function (meetingType) {

            if (meetingType.isFilterSelected == null) {
                meetingType.isFilterSelected = true;
            } else {
                meetingType.isFilterSelected = !meetingType.isFilterSelected;
            }
        }

        function hidePaticpantsPanel() {
            vm.attendee = false;

        }


        vm.autoFilledDisplayName = function () {
            vm.meetingTypeDisplayName = vm.meetingTypeName;
        }


        function makePageDirty() {
            if (vm.isMeetingCompleted == false) {
                vm.isPageDirty = true;
            }

        }

        function clearPageDirty() {
            vm.isPageDirty = false;
            vm.clearTaskPanelDirty();
        }


        vm.showOrHidePreviousMeetings = function () {




        }

        vm.showOrHideFilterPanel = function () {

            if (vm.isPageDirty == true) {
                vm.confirmDialogPopupMessage = "Do you want to save the changes?";

                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    vm.showOrHideFilterPanel();
                }
                return;
            }


            vm.typeBox = false;
            vm.attendee = false;

            vm.showFilterPanel = !vm.showFilterPanel;
            vm.showOverLayer = vm.showFilterPanel;

            if (vm.showFilterPanel == true) {
                var meetingDetialPanel = angular.element.find('#meetingDetialPanel');
                var filterPanel = angular.element.find('#filterPanel');
                var height = meetingDetialPanel[0].offsetHeight;
                var width = meetingDetialPanel[0].offsetWidth;
                angular.element(filterPanel).css('height', ((height + 10) + 'px')).css('width', (width + 'px'));

            }



            vm.isAllUsersSelected = false;
            for (var i = 0 ; i < vm.meetingTypes.length; i++) {
                vm.meetingTypes[i].isFilterSelected = false;
            }

            if (vm.appliedFilter != null && vm.appliedFilter.IsFilterSelected != null) {
                vm.isAllUsersSelected = vm.appliedFilter.IsFilterSelected;
            }

            if (vm.appliedFilter != null && vm.appliedFilter.AppliedFilterAttributes != null && vm.appliedFilter.AppliedFilterAttributes.length > 0) {
                for (var i = 0; i < vm.appliedFilter.AppliedFilterAttributes.length; i++) {
                    var typeName = vm.appliedFilter.AppliedFilterAttributes[i].Name;
                    for (var j = 0; j < vm.meetingTypes.length; j++) {
                        if (vm.meetingTypes[j].Name == typeName) {
                            vm.meetingTypes[j].isFilterSelected = true;
                            break;
                        }
                    }
                }
            }
        }

        //For Localized messages
        vm.toLocalDate = function (utcString) {
            if (utcString != null && utcString != "")
                return utility.toLocalDate(utcString);
            else
                return "";
        }

        //For Localized messages
        vm.toLocalDateFormat = function (utcString) {
            if (utcString != null && utcString != "")
                return utility.toLocalDateFormat(utcString);
            else
                return "";
        }

        vm.addEmailAccount = function () {

            if (vm.newEmailId != null && vm.newEmailId != "") {
                if (validateEmail(vm.newEmailId)) {

                    if (getUserInfoFromParticipants(vm.newEmailId) == null) {
                        if (getUserInfo(vm.newEmailId) == null) {
                            addUserEmailId(vm.newEmailId);
                            vm.newEmailId = "";
                        }
                        else {
                            notifications.error("This email id is already exists in users list.", false, true);
                        }
                    }
                    else {
                        notifications.error("This email id is already exists", false, true);
                    }
                }
                else {
                    notifications.error("Invalid email id", false, true);
                }
            }
            else {
                notifications.error("Please enter email id", false, true);
            }
        }

        vm.addUserParticipants = function () {

            if (vm.searchedUser != null && vm.searchedUser != "") {
                if (vm.multiselectUsers != null && vm.multiselectUsers.dataItem()) {
                    vm.multiselectUsers.dataItem().set("isAssigned", true);
                    addUserToOtherLists(vm.multiselectUsers.dataItem())
                }
            }
            else {
                notifications.error("Please select a participant", false, true);
            }
        }

        function addUserEmailId(email) {
            var user = {
                "IsSelected": true,
                "EmailID": email,
                "DisplayName": email,
                "UserPrincipal": ""
            };
            vm.allParticipantsForThisMeeting.push(user);
        }

        function addUserToOtherLists(selectedUserObj) {

            var user = {
                "IsSelected": true,
                "EmailID": selectedUserObj.EmailID,
                "DisplayName": selectedUserObj.DisplayName,
                "UserPrincipal": selectedUserObj.UserPrincipal
            };

            vm.allParticipantsForThisMeeting.push(JSON.parse(JSON.stringify(user)));


            var isLeaderAlreadyPresent = false;


            for (var i = 0 ; i < vm.allMeetingLeaders.length ; i++) {
                if (vm.allMeetingLeaders[i].UserPrincipal == selectedUserObj.UserPrincipal) {
                    isLeaderAlreadyPresent = true;
                    break;
                }
            }

            if (isLeaderAlreadyPresent == false) {
                vm.allMeetingLeaders.push(JSON.parse(JSON.stringify(user)));
            }



            vm.searchedUser = "";

        }
        function removeAddedItemfromDD(user) {
            var raw = vm.multiselectUsers.dataSource.data();
            var length = raw.length;

            // iterate and remove "done" items
            var item, i;
            for (i = length - 1; i >= 0; i--) {

                item = raw[i];
                if (raw[i].UserPrincipal != "") {
                    if (raw[i].UserPrincipal == user.UserPrincipal)
                        vm.multiselectUsers.dataSource.remove(item);
                }
                else {
                    if (raw[i].EmailID == user.EmailID)
                        vm.multiselectUsers.dataSource.remove(item);
                }

            }
            vm.searchedUser = "";
        }
        function validateEmail(email) {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        vm.selectAllUsers = function ($event) {
            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                    vm.allParticipantsForThisMeeting[i].IsSelected = $event;
                }
            }
        }

        function getLocalizedMessages() {
            $translate(['Create_New_Meeting'])
					.then(function (translations) {
					    vm.LocalizedStrings = translations;
					});
        }



        vm.activeButtonNote = function () {
            vm.isActiveNote = !vm.isActiveNote;
        }



        vm.activeButtonCheckList = function () {
            vm.isActiveCheckList = !vm.isActiveCheckList;
        }

        vm.activeButtonTasksGrid = function () {
            vm.isActiveTasksGrid = !vm.isActiveTasksGrid;
        }

        vm.showTaskUpdatePanel = function () {

        }

        vm.attendeeList = function () {

            getAllUsersForThisAsset();

            vm.typeBox = false;
            vm.showFilterPanel = false;
            vm.attendee = !vm.attendee;
            vm.showOverLayer = vm.attendee;

            if (vm.attendee == true) {
                var meetingDetialPanel = angular.element.find('#meetingDetialPanel');
                var participantList = angular.element.find('#participantList');
                var height = meetingDetialPanel[0].offsetHeight;
                var width = meetingDetialPanel[0].offsetWidth;
                angular.element(participantList).css('height', (((height * 2) - 160) + 'px')).css('width', ((width * 2) + 'px'));
            }
        }

        vm.createNewMeeting = function (selectedMeetingType, isNew, existingMeetingAttributeCheckListItems) {

            vm.currentMeetingParticipants = [];

            //if (vm.isPageDirty == true) {
            //    vm.confirmDialogPopupMessage = "Do you want to save the changes??";

            //    $scope.confirmDialogPopup.center();
            //    $scope.confirmDialogPopup.open();
            //    vm.confirmDialogNoClickCallBackFunction = function () {
            //        vm.createNewMeeting(selectedMeetingType, isNew, existingMeetingAttributeCheckListItems);
            //    }
            //    return;
            //}

            if (selectedMeetingType != null) {

                var assetName = appContext.getAssetName();
                if (isNew == true) {
                    //get previous meetings details of the selected type
                    vm.meetingDetail = null;
                    vm.isMeetingCompleted = false;

                    if (vm.addMeeting) {
                        vm.meetingInProgress = true;
                        vm.addMeeting = false;
                    }
                    else {
                        vm.meetingInProgress = false;
                        vm.addMeeting = true;
                    }
                }
                else {
                    assetName = vm.meetingDetail.Meeting.AssetName;
                    vm.isMeetingCompleted = vm.meetingDetail.Meeting.IsCompleted;
                    vm.meetingInProgress = !vm.meetingDetail.Meeting.IsCompleted;
                    vm.addMeeting = false;
                }

                if (vm.hasEditMeetingPermission == false) {
                    vm.isMeetingCompleted = true;
                    vm.meetingInProgress = false;
                }

                setTimeout(function () {
                    vm.meetingType.value(selectedMeetingType.Name);
                }, 100);

                enableOrDisableKendoEditor();

                clearControlValues(true);
                vm.selectedMeetingType = selectedMeetingType;
                if (isNew == true) {
                    if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                        for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                            vm.allParticipantsForThisMeeting[i].IsSelected = false;
                        }
                    }
                }

                getMeetingTypeAttributes(vm.selectedMeetingType.Name, assetName, "CheckList", existingMeetingAttributeCheckListItems);

                vm.meetingTitle = assetName + " " + vm.selectedMeetingType.Name;
                // clearPageDirty();

                if (vm.meetingInProgress && isNew == true) {
                    getPreviouMeetingContent();
                }

                focusControl("meetingNote", "kendoEditor");
                if (vm.addMeeting) {
                    vm.addNewMeeting();
                }
            }
        }

        vm.addNewMeeting = function () {

            if (vm.isPageDirty == true) {
                vm.confirmDialogPopupMessage = "Do you want to save the changes?";

                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    vm.addNewMeeting();
                }
                return;
            }


            clearPageDirty();
            clearControlValues();
            clearCheckList();

            vm.isMeetingCompleted = false;
            vm.addMeeting = true;
            vm.meetingInProgress = false;
            if (vm.hasEditMeetingPermission == false) {
                vm.isMeetingCompleted = true;
                vm.meetingInProgress = false;
            }

            enableOrDisableKendoEditor();
            Intuition.ActionBar.HideIcon("MEETINGS_CANCEL");
            Intuition.ActionBar.HideIcon("MEETINGS_SAVE");
            Intuition.ActionBar.HideIcon("MEETINGS_PUBLISH");
        }

        vm.deleteMeeting = function () {
            event.stopImmediatePropagation();

            vm.confirmDialogPopupMessage = "Are you sure to delete the Meeting '" + vm.meetingDetail.Meeting.MeetingType.Name + "'?";
            vm.confirmDialogPopupMessage2 = "";
            $scope.confirmDialog2.center();
            $scope.confirmDialog2.open();

            vm.confirmDialog2YesClickCallBackFunction = function () {
                meetingsService.deleteMeetings(vm.meetingDetail.Meeting.Meeting_PK_ID)
            .then(function (data) {
                if (!utility.isError(data)) {
                    if (data[0].OperationResult.Status == true) {
                        notifications.success(data[0].OperationResult.Message, false, true);
                        vm.lastLoadedMeetingsCount = -1;
                        vm.currentPageNumber = 0;
                        vm.meeting_PK_ID = null;
                        vm.meetingDetail = null;

                        clearControlValues();
                        vm.getMeetings(false);
                    }
                    else {
                        notifications.error(data[0].OperationResult.Message, false, true);
                    }
                }
            })
            };

        }

        function getPreviouMeetingContent() {

            meetingsService.getMeetingDetails("", appContext.getAssetName(), vm.selectedMeetingType.Name)
                .then(function (data) {
                    if (data != null) {
                        vm.allParticipantsForThisMeeting = [];
                        if (data.Participants != null)
                            populateMeetingParticipants(data.Participants, true);
                        //vm.meetingNote = vm.meetingDetail.Notes[0].Notes;
                        if (data.MeetingTasksAssociations != null)
                            getTaskGrid(data.MeetingTasksAssociations);
                    }
                });


        }


        function enableOrDisableKendoEditor() {
            if (vm.isMeetingCompleted == false && vm.meetingInProgress) {
                if ($('#meetingNote').data() != null && $('#meetingNote').data().kendoEditor != null)
                    $($('#meetingNote').data().kendoEditor.body).attr('contenteditable', true);
                if ($('#newTaskDescription').data() != null && $('#newTaskDescription').data().kendoEditor != null)
                    $($('#newTaskDescription').data().kendoEditor.body).attr('contenteditable', true);
            }
            else {
                if ($('#meetingNote').data() != null && $('#meetingNote').data().kendoEditor != null)
                    $($('#meetingNote').data().kendoEditor.body).attr('contenteditable', false);
                if ($('#newTaskDescription').data() != null && $('#newTaskDescription').data().kendoEditor != null)
                    $($('#newTaskDescription').data().kendoEditor.body).attr('contenteditable', false);
            }

        }



        function clearControlValues(isStartMeetingClick) {
            vm.meeting_PK_ID = null;
            vm.createMeeting = true;


            vm.typeBox = false;
            vm.showOverLayer = false;

            if (vm.hasEditMeetingPermission) {
                Intuition.ActionBar.ShowIcon("MEETINGS_CANCEL");
                Intuition.ActionBar.ShowIcon("MEETINGS_SAVE");
                Intuition.ActionBar.ShowIcon("MEETINGS_PUBLISH");
            }
            vm.meetingNote = "";

            if (isStartMeetingClick == null || isStartMeetingClick == false) {
                vm.meetingStartDateTime = "";
                vm.meetingEndDateTime = "";
                vm.meetingStartDateTime = kendo.toString(new Date(), utility.getCustomDateTimeFormat());
                vm.allMeetingLeaders = [];



                addCurrentUserInfoInMeetingLeader(true);

            }



            vm.currentMeetingAssetName = appContext.getAssetDisplayName();
            vm.showTaskEditPanel = false;
            vm.currentMeetingsTaskCollections = [];
            clearTaskControlValues();
            clearAllErrorMessages();

        }

        function getMeetingTypeAttributes(meetingTypeName, assetName, attributeName, existingMeetingAttributeCheckListItems) {

            if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.MeetingType != null && vm.meetingTypeAttributes.MeetingType.Name == vm.selectedMeetingType.Name && vm.lastLoadedAsset == assetName) {
                clearCheckList();
                tickCheckBoxForAlreadySelected(existingMeetingAttributeCheckListItems);
            }
            else {

                meetingsService.getMeetingTypeAttributes(meetingTypeName, assetName, attributeName)
                         .then(function (data) {

                             if (!utility.isError(data)) {
                                 vm.meetingTypeAttributes = data[0];
                                 clearCheckList();
                                 tickCheckBoxForAlreadySelected(existingMeetingAttributeCheckListItems);
                             }

                         });


            }

            vm.lastLoadedAsset = assetName;
        }

        function clearCheckList() {
            if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.CheckListItems != null) {
                for (var i = 0; i < vm.meetingTypeAttributes.CheckListItems.length; i++) {
                    vm.meetingTypeAttributes.CheckListItems[i].IsChecked = false;
                }
            }
        }

        function getChecklistForSelectedMeeting() {

            if (vm.meetingDetail != null && vm.meetingDetail.MeetingAttribute != null && vm.meetingDetail.MeetingAttribute.CheckListItems != null) {
                vm.meetingChecklist = vm.meetingDetail.MeetingAttribute.CheckListItems.filter(function (el) { return el.IsChecked == true });
                vm.meetingChecklist = vm.meetingChecklist.concat(vm.meetingTypeAttributes.CheckListItems)
                vm.meetingChecklist = removeDuplicates(vm.meetingChecklist, "Name");
            }
        }

        function tickCheckBoxForAlreadySelected(existingMeetingAttributeCheckListItems) {
            if (existingMeetingAttributeCheckListItems != null && vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.CheckListItems != null) {
                getChecklistForSelectedMeeting();

                for (var i = 0; i < existingMeetingAttributeCheckListItems.length; i++) {
                    if (existingMeetingAttributeCheckListItems[i].IsChecked == true) {
                        var selectedCheckListItemName = existingMeetingAttributeCheckListItems[i].Name.toLowerCase();
                        for (var j = 0; j < vm.meetingTypeAttributes.CheckListItems.length; j++) {
                            var thisCheckListItemName = vm.meetingTypeAttributes.CheckListItems[j].Name.toLowerCase();
                            if (thisCheckListItemName == selectedCheckListItemName) {
                                vm.meetingTypeAttributes.CheckListItems[j].IsChecked = true;
                            }
                        }
                    }
                }
            }
        }

        vm.openTypeDD = function () {
            vm.attendee = false;
            vm.showFilterPanel = false;

            vm.typeBox = !vm.typeBox;
            vm.showOverLayer = vm.typeBox;

            if (vm.typeBox == true) {

            }

        }

        vm.applyFilter = function () {
            var appliedFilterAttributes = [];
            vm.appliedFilterCount = 0;

            for (var i = 0 ; i < vm.meetingTypes.length ; i++) {
                if (vm.meetingTypes[i].isFilterSelected == true) {
                    var meetingTypeName = vm.meetingTypes[i].Name;
                    var meetingTypeDisplayName = vm.meetingTypes[i].DisplayName;
                    appliedFilterAttributes.push({ "Name": meetingTypeName, "DisplayName": meetingTypeDisplayName })
                    vm.appliedFilterCount++;
                }
            }
            var isFilterSelected = vm.isAllUsersSelected == true;

            if (isFilterSelected == true) {
                vm.appliedFilterCount++;
            }


            vm.appliedFilter = {
                "IsFilterSelected": isFilterSelected,
                "AppliedFilterAttributes": appliedFilterAttributes
            };

            vm.lastLoadedMeetingsCount = -1;
            vm.currentPageNumber = 0;
            vm.meeting_PK_ID = null;
            vm.meetingDetail = null;

            clearControlValues();

            vm.getMeetings(false);

            vm.showFilterPanel = false;
            vm.showOverLayer = false;
        }

        vm.clearFilter = function (isAfterEdit) {
            vm.appliedFilter = {
                "IsFilterSelected": false,
                "AppliedFilterAttributes": []
            };

            getMeetingList(false);
            vm.showFilterPanel = false;
            vm.showOverLayer = false;
        }

        vm.getMeetings = function (isAfterEdit) {

            var pageSize = 25;

            if (!angular.isDefined(appContext.getAssetName()))
                return;

            var startTime = appContext.getStartTime();
            var endTime = appContext.getEndTime();
            if (startTime == null || startTime == "" || endTime == null || endTime == "")
                return


            if (vm.lastLoadedMeetingsCount >= 0 && vm.lastLoadedMeetingsCount < pageSize) // to avoid call backs on scroll 
                return;

            $rootScope.$emit("showLoadingIcon");

            angular.element("#tblConInfo", window.parent.document).find("#liCont").html(appContext.getAssetDisplayName()).show();

            vm.currentPageNumber++;


            var isFilterSelected = false;
            var additionalFilter = null;


            if (vm.appliedFilter != null && vm.appliedFilter.IsFilterSelected != null) {
                isFilterSelected = vm.appliedFilter.IsFilterSelected;
            }

            if (vm.appliedFilter != null && vm.appliedFilter.AppliedFilterAttributes != null && vm.appliedFilter.AppliedFilterAttributes.length > 0) {
                additionalFilter = [];
                var values = [];
                for (var i = 0 ; i < vm.appliedFilter.AppliedFilterAttributes.length; i++) {
                    values.push(vm.appliedFilter.AppliedFilterAttributes[i].Name);
                }
                additionalFilter.push({ "Key": "MeetingType", "Value": values });
            }



            var meetingSummaryFilter = {
                "StartTime": startTime,
                "EndTime": endTime,
                "Asset": appContext.getAssetName(),
                "AdditionalFilter": additionalFilter,
                "PageSize": pageSize,
                "PageNumber": vm.currentPageNumber,
                "HierarchyName": appContext.getHierarchyName(),
                "MyMeetings": isFilterSelected
            };



            vm.noMeetingsFoundLabel = "";
            meetingsService.getMeetings(meetingSummaryFilter)
                       .then(function (data) {
                           if (!utility.isError(data)) {
                               vm.totalMeetings = data.TotalCount;

                               if (vm.currentPageNumber == 1) {
                                   vm.meetings = data.MeetingList;

                               }
                               else {
                                   for (var i = 0 ; i < data.MeetingList.length; i++)
                                       vm.meetings.push(data.MeetingList[i]);
                               }

                               vm.lastLoadedMeetingsCount = data.MeetingList.length;
                               vm.displayedMeetingsCount = vm.meetings.length;

                               if (vm.totalMeetings == 0) {
                                   // setTimeout(function () {
                                   vm.addNewMeeting();
                                   //  }, 1000);
                                   vm.noMeetingsFoundLabel = "No meeting found.";
                               }
                               else {
                                   if (isAfterEdit == false) {
                                       Intuition.ActionBar.HideIcon("MEETINGS_CANCEL");
                                       Intuition.ActionBar.HideIcon("MEETINGS_SAVE");
                                       Intuition.ActionBar.HideIcon("MEETINGS_PUBLISH");
                                   }
                               }

                               if (vm.currentPageNumber == 1) {

                                   if (vm.meeting_PK_ID != null && vm.meeting_PK_ID != "") {
                                       var isFound = false;
                                       for (var i = 0; i < vm.meetings.length; i++) {
                                           if (vm.meetings[i].Meeting_PK_ID == vm.meeting_PK_ID) {
                                               isFound = true;
                                               break;
                                           }
                                       }
                                       if (isFound == true) {
                                           if (isAfterEdit != true) {
                                               vm.getMeetingDetails(vm.meeting_PK_ID);
                                           }
                                       }
                                       else {

                                       }
                                   }
                                   else if (vm.currentPageNumber == 1 && vm.meetings.length > 0) {
                                       setTimeout(function () {
                                           vm.getMeetingDetails(vm.meetings[0].Meeting_PK_ID);
                                       }, 500);

                                   }
                               }
                           }
                       });
        }

        function getMeetingTypes() {
            meetingsService.getMeetingTypes()
                       .then(function (data) {
                           if (!utility.isError(data)) {
                               vm.meetingTypes = data;
                               vm.selectedMeetingType = vm.meetingTypes[0];
                           }
                       });
        }

        function getCurrentUserInfo() {
            var assetName = appContext.getAssetName();
            var operationName = "Task.View Meeting";
            meetingsService.getCurrentUserInfo(assetName, operationName)
                       .then(function (data) {
                           if (!utility.isError(data)) {
                               var currentUser = {
                                   "Mail": data.Mail,
                                   "DisplayName": data.DisplayName,
                                   "UserPrincipal": data.Mail
                               };

                               vm.currentUserInfo = currentUser;
                               addCurrentUserInfoInMeetingLeader();


                           }
                       });
        }

        function addCurrentUserIntoMeetingLeader() {

            var isLeaderAlreadyPresent = false;
            var currentUser = [];

            for (var i = 0 ; i < vm.allMeetingLeaders.length ; i++) {
                if (vm.allMeetingLeaders[i].UserPrincipal == vm.currentUserInfo.UserPrincipal) {
                    currentUser = vm.allMeetingLeaders[i];
                    isLeaderAlreadyPresent = true;
                    break;
                }
            }
            if (isLeaderAlreadyPresent == false) {
                currentUser = {
                    "IsSelected": false,
                    "EmailID": vm.currentUserInfo.Mail,
                    "DisplayName": vm.currentUserInfo.DisplayName,
                    "UserPrincipal": vm.currentUserInfo.UserPrincipal
                };
                vm.allMeetingLeaders.push(currentUser);
            }

            setTimeout(function () {
                vm.meetingLeaderDropDown.value(vm.currentUserInfo.UserPrincipal);
            }, 100);

            return JSON.parse(JSON.stringify(currentUser));

        }

        function addCurrentUserInfoInMeetingLeader(isAddToParticipant) {
            if (vm.currentUserInfo != null && vm.currentUserInfo.UserPrincipal != null) {
                var userInfo = getUserInfoFromParticipants(vm.currentUserInfo.Mail, vm.currentUserInfo.UserPrincipal);

                var currentUser = addCurrentUserIntoMeetingLeader();
                if (userInfo == null) {
                    var clonedCurrentUser = JSON.parse(JSON.stringify(currentUser));
                    clonedCurrentUser.IsAssigned = true;
                    vm.allParticipantsForThisMeeting.push(clonedCurrentUser);
                }
            }
        }

        function getUserInfo(userPrincipalOrMailId) {
            var result = null;

            if (userPrincipalOrMailId == null)
                return result;

            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                    var resultUser = vm.allParticipantsForThisMeeting[i];
                    if (userPrincipalOrMailId && resultUser.UserPrincipal && resultUser.UserPrincipal.toLowerCase() == userPrincipalOrMailId.toLowerCase()) {
                        result = resultUser;
                        break;
                    }
                    else if (resultUser.EmailID != null && resultUser.EmailID.toLowerCase() == userPrincipalOrMailId.toLowerCase()) {
                        result = resultUser;
                        break;
                    }
                }
            }
            if (result == null)
                if (vm.allUsersForThisAsset != null && vm.allUsersForThisAsset.length > 0) {
                    for (var i = 0 ; i < vm.allUsersForThisAsset.length; i++) {
                        var resultUser = vm.allUsersForThisAsset[i];
                        if (userPrincipalOrMailId && resultUser.UserPrincipal && resultUser.UserPrincipal.toLowerCase() == userPrincipalOrMailId.toLowerCase()) {
                            result = resultUser;
                            break;
                        }
                        else if (resultUser.EmailID != null && resultUser.EmailID.toLowerCase() == userPrincipalOrMailId.toLowerCase()) {
                            result = resultUser;
                            break;
                        }
                    }
                }
            return result;
        }

        function getUserInfoFromParticipants(emailID, userPrincipal) {
            var result = null;
            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                    var resultUser = vm.allParticipantsForThisMeeting[i];
                    if (userPrincipal) {
                        if (resultUser.UserPrincipal && resultUser.UserPrincipal.toLowerCase() == userPrincipal.toLowerCase()) {
                            result = resultUser;
                            break;
                        }
                    }
                    else if (resultUser.EmailID != null && resultUser.EmailID.toLowerCase() == emailID.toLowerCase()) {
                        result = resultUser;
                        break;
                    }
                }
            }
            return result;
        }
        function getAllUsersForThisAsset(callBackFunction) {
            var isAlreadyParticipantsExist = false;
            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0)
                isAlreadyParticipantsExist = true;
            //else if (vm.allMeetingLeaders != null && vm.allMeetingLeaders != null) {
            //    vm.allParticipantsForThisMeeting=
            //}
            if (vm.allUsersForThisAsset == null || vm.allUsersForThisAsset == 0) {

                //isAlreadyParticipantsExist = false;
                bindParticipantsDD();
            }
            else {

                if (isAlreadyParticipantsExist == false) {
                    addCurrentUserInfoInMeetingLeader(true);
                }

                disableParticipantsInDD();
                return;
            }



            vm.loadedAsset = appContext.getAssetName();
            var operationName = "Task.View Meeting";
            meetingsService.getUsersForAssetAndTask(vm.loadedAsset, operationName, "")
                       .then(function (data) {

                           if (!isAlreadyParticipantsExist) {
                               vm.allParticipantsForThisMeeting = [];
                               vm.allMeetingLeaders = [];
                               addCurrentUserInfoInMeetingLeader(true);
                           }
                           vm.allAssigneeList = [];
                           vm.UsersDatasource = [];


                           if (!utility.isError(data)) {

                               if (data.response != null && data.response.Users != null) {
                                   vm.allUsersForThisAsset = [];
                                   for (var i = 0 ; i < data.response.Users.length; i++) {
                                       var resultUser = data.response.Users[i];

                                       if (resultUser.Name != null && resultUser.DisplayName != null
                                           && resultUser.Name != "" && resultUser.DisplayName != "") {
                                           var user = {
                                               "IsSelected": false,
                                               "EmailID": resultUser.Mail,
                                               "DisplayName": resultUser.DisplayName,
                                               "UserPrincipal": resultUser.Name,
                                               "EID": resultUser.EID,
                                               "isAssigned": false
                                           };
                                           vm.allUsersForThisAsset.push(user);

                                           if (vm.currentUserInfo != null && vm.currentUserInfo.UserPrincipal != null && vm.currentUserInfo.UserPrincipal == resultUser.Mail) {
                                               var currentUser = {
                                                   "Mail": resultUser.Mail,
                                                   "DisplayName": resultUser.DisplayName,
                                                   "UserPrincipal": resultUser.Name
                                               };
                                               vm.currentUserInfo = currentUser;

                                               for (var j = 0 ; j < vm.allMeetingLeaders.length; j++) {
                                                   if (vm.allMeetingLeaders[j].UserPrincipal == resultUser.Mail) {
                                                       vm.allMeetingLeaders[j].UserPrincipal = resultUser.Name;
                                                   }
                                               }

                                               for (var j = 0 ; j < vm.allParticipantsForThisMeeting.length; j++) {
                                                   if (vm.allParticipantsForThisMeeting[j].UserPrincipal == resultUser.Mail) {
                                                       vm.allParticipantsForThisMeeting[j].UserPrincipal = resultUser.Name;
                                                   }
                                               }
                                           }

                                       }
                                   }
                                   disableParticipantsInDD();
                                   for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                                       var userIndex;
                                       var dd = $.grep(vm.allUsersForThisAsset, function (user, index) {
                                           if (user.UserPrincipal == vm.allParticipantsForThisMeeting[i].UserPrincipal) {
                                               userIndex = index;
                                               return index;
                                           }

                                       });
                                       if (vm.allUsersForThisAsset[userIndex])
                                           vm.allUsersForThisAsset[userIndex].isAssigned = true;

                                   }
                                   //if (isUpdateOnlyTaskAtendeeList) {
                                   vm.allAssigneeList = JSON.parse(JSON.stringify(vm.allUsersForThisAsset));
                                   //return;
                                   //}
                                   //vm.UsersDatasource = vm.allUsersForThisAsset;
                                   bindParticipantsDD();
                                   //vm.allMeetingLeaders = JSON.parse(JSON.stringify(vm.allParticipantsForThisMeeting));
                                   vm.allAssigneeList = JSON.parse(JSON.stringify(vm.allUsersForThisAsset));

                                   if (vm.currentMeetingParticipants != null && vm.currentMeetingParticipants.length > 0) {
                                       for (var i = 0; i < vm.currentMeetingParticipants.length; i++) {
                                           var email = vm.currentMeetingParticipants[i].EmailID;
                                           var userPrincipal = vm.currentMeetingParticipants[i].UserPrincipal;
                                           var userInfo = getUserInfo(userPrincipal);
                                           if (userInfo != null && userInfo.IsAttended == true) {
                                               userInfo.IsSelected = true;
                                           }
                                       }
                                       vm.currentMeetingParticipants = [];
                                   }



                                   if (vm.allMeetingLeaders.length == 1) {
                                       setTimeout(function () {
                                           vm.meetingLeaderDropDown.value(vm.allMeetingLeaders[0].UserPrincipal);
                                       }, 100);
                                   }



                                   setTimeout(function () {
                                       if (vm.meetingDetail == null) {
                                           if (vm.meetingLeaderDropDown != null && vm.meetingLeaderDropDown.value != null)
                                               vm.meetingLeaderDropDown.value(vm.currentUserInfo.UserPrincipal);
                                       }
                                       else {
                                           if (vm.meetingLeaderDropDown != null && vm.meetingLeaderDropDown.value != null)
                                               vm.meetingLeaderDropDown.value(vm.meetingDetail.Meeting.MeetingLeader.UserPrincipal);
                                       }
                                   }, 10);
                               }


                           }
                           if (callBackFunction != null) {
                               callBackFunction();
                           }
                       });
        }


        function bindParticipantsDD() {
            vm.multiSelectUserOptions = {
                optionLabel: "Select participants",
                dataTextField: "DisplayName",
                dataValueField: "UserPrincipal",
                valuePrimitive: true,
                autoBind: true,
                dataSource: vm.allUsersForThisAsset,
                filter: "contains",
                autoClose: false,
                select: function (e) {
                    if (e.dataItem.isAssigned) {
                        e.preventDefault();
                    }
                },
                template: "<span class='#: isAssigned ? 'k-state-disabled': 'enable'#'>#: DisplayName # </span>",

            };
        }


        function enableParticipantsInDD() {
            for (var i = 0 ; i < vm.allUsersForThisAsset.length; i++) {
                vm.allUsersForThisAsset[i].isAssigned = false;
            }

        }


        function disableParticipantsInDD() {
            enableParticipantsInDD();
            if (vm.allParticipantsForThisMeeting.length > 0) {
                for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                    var inte;
                    var dd = $.grep(vm.allUsersForThisAsset, function (n, index) {
                        if (n.UserPrincipal == vm.allParticipantsForThisMeeting[i].UserPrincipal) {
                            inte = index;
                            return index;
                        }

                    });
                    if (vm.allUsersForThisAsset[inte])
                        vm.allUsersForThisAsset[inte].isAssigned = true;
                }

            }
            else {
                for (var jj = 0 ; jj < vm.allUsersForThisAsset.length; jj++) {
                    vm.allUsersForThisAsset[jj].isAssigned = false;
                }
            }
            bindParticipantsDD();
        }

        function initialize() {
            if (parent.updatedAsset != null && parent.startTime != null && parent.endTime != null) {
                appContext.setAssetInfo(parent.updatedAsset);
                appContext.setStartTime(parent.startTime);
                appContext.setEndTime(parent.endTime);
            }

            if (appContext.getAssetName() == null)
                return;

            clearBeforeInitalize();
            clearPageDirty();
            vm.meeting_PK_ID = null;
            vm.meetingDetail = null;
            vm.totalMeetings = 0;
            clearControlValues();

            if (vm.meetingTypes != null && vm.meetingTypes.length == 0) {
                getMeetingTypes();
            }

            if (vm.currentUserInfo == null) {
                getCurrentUserInfo();
            }

            if (vm.loadedAsset != appContext.getAssetName()) {
                getTaskConfigData();

                var securityOperations = [];
                securityOperations.push("DOTEditMeeting")
                checkSecurityAccess(securityOperations);
            }

            getMeetingList();

            vm.meetingTypeAttributes = null;


        }

        function getTaskConfigData() {
            var assetName = appContext.getAssetName();
            vm.disableNewActionButton = false;
            vm.taskConfigData = null;
            meetingsService.getTaskConfigData(assetName)
                 .then(function (data) {
                     if (!utility.isError(data)) {

                         vm.taskConfigData = data.ConfigData;

                         if (data.ConfigData == null || data.ConfigData.TaskPriorities == null || data.ConfigData.TaskPriorities.length == 0 || data.ConfigData.TaskTypes == null || data.ConfigData.TaskTypes.length == 0) {
                             vm.disableNewActionButton = true;
                         } else {

                         }
                     }
                 });


        }

        function getPriorityInfo(priorityOrder) {
            if (vm.taskConfigData != null && vm.taskConfigData.TaskPriorities != null) {
                for (var i = 0 ; i < vm.taskConfigData.TaskPriorities.length; i++) {
                    if (vm.taskConfigData.TaskPriorities[i].Order == priorityOrder) {
                        return vm.taskConfigData.TaskPriorities[i];
                    }
                }
            }
            return null;
        }

        function getTaskTypeDisplayName(typeName) {
            if (vm.taskConfigData != null && vm.taskConfigData.TaskTypes != null) {
                for (var i = 0 ; i < vm.taskConfigData.TaskTypes.length; i++) {
                    if (vm.taskConfigData.TaskTypes[i].Name == typeName) {
                        return vm.taskConfigData.TaskTypes[i].DisplayName;
                    }
                }
            }
            return "";
        }

        function getMeetingList(isAfterEdit) {
            vm.currentPageNumber = 0;
            vm.lastLoadedMeetingsCount = -1;
            vm.meetings = [];
            vm.getMeetings(isAfterEdit);
        }

        function actionbarClicked(event, actionText) {

            if (actionText == "MEETINGS_SAVE") {
                $scope.$apply(function () {
                    editMeetingDetails(actionText);
                });
            }
            else if (actionText == "MEETINGS_CANCEL") {
                $scope.$apply(function () {
                    onCancelActionBarClick();
                });
            }
            else if (actionText == "MEETINGS_PUBLISH") {
                $scope.$apply(function () {
                    editMeetingDetails(actionText);
                });
            }
            //Intuition.ActionBar.HideIcon("MEETINGS_CANCEL");
            //Intuition.ActionBar.ShowIcon("MEETINGS_SAVE");
        }

        function onCancelActionBarClick() {

            if (vm.isPageDirty == true) {
                vm.confirmDialogPopupMessage = "Do you want to save the changes?";
                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    onCancelActionBarClick();
                };
                return;
            }

            Intuition.ActionBar.HideIcon("MEETINGS_CANCEL");
            Intuition.ActionBar.HideIcon("MEETINGS_SAVE");
            Intuition.ActionBar.HideIcon("MEETINGS_PUBLISH");


            clearControlValues();
            if (vm.totalMeetings != 0) {
                vm.getMeetingDetails(vm.meetings[0].Meeting_PK_ID);
            }
            else {
                vm.addNewMeeting();
            }
        }

        vm.newMeetings = {
            "ErrLeaderName": null,
            "ErrParticipant": null,
            "ErrMeetingsStartDate": null,
            "ErrMeetingsEndDate": null,
            "ErrMeetingsNotes": null
        }

        vm.meetingLeaderChange = function () {
            vm.newMeetings.ErrLeaderName = "";
            var mLeader = getUserInfo(vm.meetingLeaderDropDown.value());
            if (mLeader == null) {
                vm.newMeetings.ErrLeaderName = "Please select the meeting leader";
            }
        }

        function onMeetingLeaderDropDownOpen(e) {
            //getAllUsersForThisAsset(function () {
            //    setTimeout(function () {
            //        var dropdownlist = $("#meetingLeaderDropDown").data("kendoDropDownList");
            //        dropdownlist.open();
            //    }, 1);


            //});//point1: Should not load getallusers if dd opens
        }


        function onMeetingTypeDropDownOpen(e) {
            //if (vm.isPageDirty == true) {
            //    vm.confirmDialogPopupMessage = "Do you want to save the changes??";

            //    $scope.confirmDialogPopup.center();
            //    $scope.confirmDialogPopup.open();
            //    vm.confirmDialogNoClickCallBackFunction = function () {

            //    }
            //    var previousValue = vm.meetingType.value();
            //    setTimeout(function () {
            //        vm.meetingType.value(previousValue);
            //    }, 10)

            //    e.preventDefault();
            //    return false;;
            //}
        }

        vm.meetingTypeChange = function (meetingType) {
            //if (vm.isPageDirty == true) {
            //    vm.confirmDialogPopupMessage = "Do you want to save the changes??";

            //    $scope.confirmDialogPopup.center();
            //    $scope.confirmDialogPopup.open();
            //    vm.confirmDialogNoClickCallBackFunction = function () {
            //        vm.createNewMeeting(meetingType, true, null);
            //    }
            //    var previousValue = vm.meetingType.value();
            //    setTimeout(function () {
            //        vm.meetingType.value(previousValue);
            //    }, 10);

            //    return false;;
            //}

            //vm.createNewMeeting(meetingType, true, null);
            //vm.meetingType.value(meetingType.Name);
            vm.selectedMeetingType = getMeetingTypeForGivenName(meetingType.Name);
        }


        vm.participantRowClick = function (user) {
            if (vm.isMeetingCompleted == false) {
                user.IsSelected = !user.IsSelected;
            }
        }

        vm.particpantSelectionChange = function () {
            vm.newMeetings.ErrParticipant = "";

            var mLeader = getUserInfo(vm.meetingLeaderDropDown.value());

            if (mLeader == null) {
                vm.newMeetings.ErrLeaderName = "Please select the meeting leader";
            }

            var meetingLaeder = {
                "Name": "",
                "DisplayName": mLeader.DisplayName,
                "IsAttended": true,
                "EmailID": mLeader.EmailID,
                "UserPrincipal": mLeader.UserPrincipal,
                "PersonID": "00000000-0000-0000-0000-000000000000"
            };

            var paticipants = [];

            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                var isMeetingLeaderPresentInParticipants = false;
                for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                    //if (vm.allParticipantsForThisMeeting[i].IsSelected == true) {

                    var paticipantName = "";
                    var paticipantDisplayName = vm.allParticipantsForThisMeeting[i].DisplayName;
                    var paticipantEmail = vm.allParticipantsForThisMeeting[i].EmailID;
                    var paticipantUserPrincipal = "";
                    if (vm.allParticipantsForThisMeeting[i].UserPrincipal != null && vm.allParticipantsForThisMeeting[i].UserPrincipal != "") {
                        paticipantUserPrincipal = vm.allParticipantsForThisMeeting[i].UserPrincipal;
                    }


                    paticipants.push({
                        "Name": "",
                        "DisplayName": paticipantDisplayName,
                        "EmailID": paticipantEmail,
                        "UserPrincipal": paticipantUserPrincipal
                    });

                    if (meetingLaeder.EmailID == paticipantEmail) {
                        isMeetingLeaderPresentInParticipants = true;
                    }
                }
                //}

                if (isMeetingLeaderPresentInParticipants == false) {
                    paticipants.push({
                        "Name": "",
                        "DisplayName": meetingLaeder.DisplayName,
                        "EmailID": meetingLaeder.EmailID,
                        "UserPrincipal": meetingLaeder.UserPrincipal,
                    });
                }
            }

            if (paticipants != null && paticipants.length <= 1) {
                vm.newMeetings.ErrParticipant = "Please select participants";

            }

        }


        function newMeetingEditorChange() {
            vm.newMeetings.ErrMeetingsNotes = "";
            if (vm.meetingNote == null || vm.meetingNote == "") {
                vm.newMeetings.ErrDescription = "Please enter the notes";
            }
        }


        vm.newMeetingStartTimeChange = function () {
            vm.newMeetings.ErrMeetingsStartDate = "";
            if (vm.meetingStartDateTime == null || vm.meetingStartDateTime == "") {
                vm.newMeetings.ErrMeetingsStartDate = "Please enter start time";
            }
        }

        vm.isValidMeetingStartDate = function () {
            if (vm.meetingStartDateTime != null && vm.meetingStartDateTime != "") {
                var date = kendo.parseDate(vm.meetingStartDateTime, utility.getCustomDateTimeFormat());
                if (!date) {
                    vm.newMeetings.ErrMeetingsStartDate = "Please provide a valid start time";
                }
            }
        }

        vm.newMeetingEndTimeChange = function () {
            vm.newMeetings.ErrMeetingsEndDate = "";
            if (vm.meetingEndDateTime == null || vm.meetingEndDateTime == "") {
                vm.newMeetings.ErrMeetingsEndDate = "Please enter end time";
            }
        }

        vm.isValidMeetingEndDate = function () {
            if (vm.meetingEndDateTime != null && vm.meetingEndDateTime != "") {
                var date = kendo.parseDate(vm.meetingEndDateTime, utility.getCustomDateTimeFormat());
                if (!date) {
                    vm.newMeetings.ErrMeetingsEndDate = "Please provide a valid end time";
                }
            }
        }

        function validateMeetingInputs(isCompleted, isCallBack) {
            var isNotificationWarningShown = false;

            var invalidControlList = [];

            var isParticipantPresent = false;
            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                isParticipantPresent = true;
            }
            else if (vm.currentMeetingParticipants != null && vm.currentMeetingParticipants.length > 0) {
                isParticipantPresent = true;
            }
            else {
                vm.newMeetings.ErrParticipant = "Please select participants";
                notifications.warning("Please select participants", false, true);
                isNotificationWarningShown = true;
                invalidControlList.push({ "Id": "particpantButton", "Type": "button", "ErrorMessage": "" });
                vm.attendeeList();
            }


            if (!angular.isDefined(appContext.getAssetName()))
                return false;


            var isMeetingLeaderPresentInParticipants = false;

            var mLeader = getUserInfo(vm.meetingLeaderDropDown.value());


            if (mLeader == null && vm.currentMeetingParticipants != null && vm.currentMeetingParticipants.length > 0) {
                mLeader = getUserFromCurrentMeeting(vm.meetingLeaderDropDown.value());
            }

            if (isParticipantPresent == false) {
                vm.newMeetings.ErrParticipant = "Please select participants";
                if (isNotificationWarningShown == false) {
                    isNotificationWarningShown = true;
                    notifications.warning(vm.newMeetings.ErrParticipant, false, true);
                }
                invalidControlList.push({ "Id": "particpantButton", "Type": "button" });
                vm.attendeeList();
            }

            if (mLeader == null && isParticipantPresent == true) {

                vm.newMeetings.ErrLeaderName = "Please select the meeting leader";
                invalidControlList.push({ "Id": "meetingLeaderDropDown", "Type": "kendoDropDownList" });
                if ((vm.isTaskPanelExpanded == true || vm.isNotesPanelExpanded == true) && isNotificationWarningShown == false) {
                    isNotificationWarningShown = true;
                    notifications.warning(vm.newMeetings.ErrLeaderName, false, true);
                }
            }




            var paticipants = [];

            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                    //if (vm.allParticipantsForThisMeeting[i].IsSelected == true) {

                    var meetingLaeder = {
                        "Name": "",
                        "DisplayName": mLeader.DisplayName,
                        "IsAttended": true,
                        "EmailID": mLeader.EmailID,
                        "UserPrincipal": mLeader.UserPrincipal,
                        "PersonID": "00000000-0000-0000-0000-000000000000"
                    };

                    var paticipantName = "";
                    var paticipantDisplayName = vm.allParticipantsForThisMeeting[i].DisplayName;
                    var paticipantEmail = vm.allParticipantsForThisMeeting[i].EmailID;
                    var paticipantUserPrincipal = "";
                    if (vm.allParticipantsForThisMeeting[i].UserPrincipal != null && vm.allParticipantsForThisMeeting[i].UserPrincipal != "") {
                        paticipantUserPrincipal = vm.allParticipantsForThisMeeting[i].UserPrincipal;
                    }


                    paticipants.push({
                        "Name": "",
                        "DisplayName": paticipantDisplayName,
                        "EmailID": paticipantEmail,
                        "UserPrincipal": paticipantUserPrincipal
                    });

                    if (meetingLaeder.EmailID == paticipantEmail) {
                        isMeetingLeaderPresentInParticipants = true;
                    }
                    //}
                }

                if (isMeetingLeaderPresentInParticipants == false) {
                    paticipants.push({
                        "Name": "",
                        "DisplayName": meetingLaeder.DisplayName,
                        "EmailID": meetingLaeder.EmailID,
                        "UserPrincipal": meetingLaeder.UserPrincipal,
                    });
                }
            } else {
                if (vm.currentMeetingParticipants != null && vm.currentMeetingParticipants.length > 0) {
                    for (var i = 0 ; i < vm.currentMeetingParticipants.length; i++) {
                        var paticipant = vm.currentMeetingParticipants[i];
                        paticipants.push({
                            "Name": "",
                            "DisplayName": paticipant.DisplayName,
                            "EmailID": paticipant.EmailID,
                            "UserPrincipal": paticipant.UserPrincipal,
                        });
                    }
                }

            }

            if (paticipants != null && paticipants.length <= 1) {
                vm.newMeetings.ErrParticipant = "Please select participants";
                if (paticipants.length == 1) {
                    vm.newMeetings.ErrParticipant = "Please select participants other than Leader";
                }

                if (isNotificationWarningShown == false) {
                    isNotificationWarningShown = true;
                    notifications.warning(vm.newMeetings.ErrParticipant, false, true);

                }
                vm.attendeeList();
                invalidControlList.push({ "Id": "particpantButton", "Type": "button" });
            }

            if ($.trim($("<div>" + vm.meetingNote + " </div>").text()) == "") {
                vm.newMeetings.ErrMeetingsNotes = "Please enter notes";
                invalidControlList.push({ "Id": "meetingNote", "Type": "kendoEditor" });
                if ((vm.isTaskPanelExpanded == true) && isNotificationWarningShown == false) {
                    isNotificationWarningShown = true;
                    notifications.warning(vm.newMeetings.ErrMeetingsNotes, false, true);
                }
            }

            if ($.trim(vm.meetingStartDateTime) == "") {
                vm.newMeetings.ErrMeetingsStartDate = "Please provide start time";
                invalidControlList.push({ "Id": "meetingStartDateTime", "Type": "kendoDateTimePicker" });
                if ((vm.isTaskPanelExpanded == true || vm.isNotesPanelExpanded == true) && isNotificationWarningShown == false) {
                    isNotificationWarningShown = true;
                    notifications.warning(vm.newMeetings.ErrMeetingsStartDate, false, true);
                }
            }
            else {
                var date = kendo.parseDate(vm.meetingStartDateTime, utility.getCustomDateTimeFormat());
                if (!date) {
                    vm.newMeetings.ErrMeetingsStartDate = "Please provide a valid start time";
                    invalidControlList.push({ "Id": "meetingStartDateTime", "Type": "kendoDateTimePicker" });
                    if ((vm.isTaskPanelExpanded == true || vm.isNotesPanelExpanded == true) && isNotificationWarningShown == false) {
                        isNotificationWarningShown = true;
                        notifications.warning(vm.newMeetings.ErrMeetingsStartDate, false, true);
                    }
                }
            }


            if (isCompleted == true) {
                if ($.trim(vm.meetingEndDateTime) == "") {

                    if (Number(kendo.parseDate(vm.meetingStartDateTime, utility.getCustomDateTimeFormat())) > Number(new Date())) {
                        vm.newMeetings.ErrMeetingsEndDate = "Please provide end time";
                        invalidControlList.push({ "Id": "meetingEndDateTime", "Type": "kendoDateTimePicker" });
                        if ((vm.isTaskPanelExpanded == true || vm.isNotesPanelExpanded == true) && isNotificationWarningShown == false) {
                            isNotificationWarningShown = true;
                            notifications.warning(vm.newMeetings.ErrMeetingsEndDate, false, true);
                        }
                    }
                    else if (Number(kendo.parseDate(vm.meetingStartDateTime, utility.getCustomDateTimeFormat())) < Number(new Date())) {
                        vm.meetingEndDateTime = kendo.toString(new Date(), utility.getCustomDateTimeFormat());
                    }

                }
            }
            if ($.trim(vm.meetingEndDateTime) != "") {

                var date = kendo.parseDate(vm.meetingEndDateTime, utility.getCustomDateTimeFormat());
                if (!date) {

                    vm.newMeetings.ErrMeetingsEndDate = "Please provide a valid end time";
                    invalidControlList.push({ "Id": "meetingEndDateTime", "Type": "kendoDateTimePicker" });
                    if ((vm.isTaskPanelExpanded == true || vm.isNotesPanelExpanded == true) && isNotificationWarningShown == false) {
                        isNotificationWarningShown = true;
                        notifications.warning(vm.newMeetings.ErrMeetingsEndDate, false, true);
                    }
                }

                if (Number(kendo.parseDate(vm.meetingStartDateTime, utility.getCustomDateTimeFormat())) >= Number(kendo.parseDate(vm.meetingEndDateTime, utility.getCustomDateTimeFormat()))) {
                    vm.newMeetings.ErrMeetingsEndDate = "End time should be greater than start time";
                    invalidControlList.push({ "Id": "meetingEndDateTime", "Type": "kendoDateTimePicker" });
                    if ((vm.isTaskPanelExpanded == true || vm.isNotesPanelExpanded == true) && isNotificationWarningShown == false) {
                        isNotificationWarningShown = true;
                        notifications.warning(vm.newMeetings.ErrMeetingsEndDate, false, true);
                    }
                }
            }
            if (invalidControlList != null && invalidControlList.length > 0) {
                focusControl(invalidControlList[0].Id, invalidControlList[0].Type);
                return false;
            }
            else
                return true;
        }


        function getUserFromCurrentMeeting(mailID) {
            var result = null;
            if (vm.currentMeetingParticipants != null && vm.currentMeetingParticipants.length > 0) {
                for (var i = 0 ; i < vm.currentMeetingParticipants.length; i++) {
                    var resultUser = vm.currentMeetingParticipants[i];
                    if (resultUser.EmailID != null && resultUser.EmailID.toLowerCase() == mailID.toLowerCase()) {
                        result = {
                            "DisplayName": resultUser.DisplayName,
                            "EmailID": resultUser.EmailID,
                            "UserPrincipal": resultUser.UserPrincipal,
                        }
                        break;
                    }
                }
            }
            return result;
        }

        function editMeetingDetails(actionText, isSilentSave) {

            var isCompleted = false;

            if (actionText == "MEETINGS_SAVE") {
                isCompleted = false;
            }
            else if (actionText == "MEETINGS_PUBLISH") {
                isCompleted = true;
            }


            if (!angular.isDefined(appContext.getAssetName()))
                return;


            if (!validateMeetingInputs(isCompleted))
                return;


            if (vm.isTaskPanelDirty) {
                setTask();
                return;
            }

            var isMeetingLeaderPresentInParticipants = false;

            var mLeader = getUserInfo(vm.meetingLeaderDropDown.value());


            if (mLeader == null && vm.currentMeetingParticipants != null && vm.currentMeetingParticipants.length > 0) {
                mLeader = getUserFromCurrentMeeting(vm.meetingLeaderDropDown.value());
            }

            if (mLeader == null) {
                notifications.warning("Please select the meeting leader", false, true);
                return;
            }

            var meetingLaeder = {
                "Name": "",
                "DisplayName": mLeader.DisplayName,
                "IsAttended": true,
                "EmailID": mLeader.EmailID,
                "UserPrincipal": mLeader.UserPrincipal,
                "PersonID": "00000000-0000-0000-0000-000000000000"
            };

            var paticipants = [];

            if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
                for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
                    // if (vm.allParticipantsForThisMeeting[i].IsSelected == true) {

                    var paticipantName = "";
                    var paticipantDisplayName = vm.allParticipantsForThisMeeting[i].DisplayName;
                    var paticipantEmail = vm.allParticipantsForThisMeeting[i].EmailID;
                    var participantIsAttended = vm.allParticipantsForThisMeeting[i].IsSelected;
                    var paticipantUserPrincipal = "";
                    if (vm.allParticipantsForThisMeeting[i].UserPrincipal != null && vm.allParticipantsForThisMeeting[i].UserPrincipal != "") {
                        paticipantUserPrincipal = vm.allParticipantsForThisMeeting[i].UserPrincipal;
                    }
                    paticipants.push({
                        "Name": "",
                        "DisplayName": paticipantDisplayName,
                        "EmailID": paticipantEmail,
                        "UserPrincipal": paticipantUserPrincipal,
                        "IsAttended": participantIsAttended
                    });

                    if (meetingLaeder.EmailID == paticipantEmail) {
                        isMeetingLeaderPresentInParticipants = true;
                    }
                    // }
                }

                if (isMeetingLeaderPresentInParticipants == false) {
                    paticipants.push({
                        "Name": "",
                        "DisplayName": meetingLaeder.DisplayName,
                        "EmailID": meetingLaeder.EmailID,
                        "UserPrincipal": meetingLaeder.UserPrincipal,
                        "IsAttended": "true",
                    });
                }

            }
            else {
                if (vm.currentMeetingParticipants != null && vm.currentMeetingParticipants.length > 0) {
                    for (var i = 0 ; i < vm.currentMeetingParticipants.length; i++) {
                        var paticipant = vm.currentMeetingParticipants[i];
                        paticipants.push({
                            "Name": "",
                            "DisplayName": paticipant.DisplayName,
                            "EmailID": paticipant.EmailID,
                            "UserPrincipal": paticipant.UserPrincipal,
                        });
                    }
                }

            }

            var notes = [];
            notes.push({
                "Notes": vm.meetingNote,
                "PlainNotes": $("<div>" + vm.meetingNote + "</div>").text(),
                "UserName": "",
                "CreatedTime": null,
                "IsPinned": false,
                "IsResponse": false,
                "NoteTypeName": null,
                "NoteTypeDisplayName": null,
                "NoteId": "00000000-0000-0000-0000-000000000000"

            });

            var meetingType = {
                "MeetingTypePKID": vm.selectedMeetingType.MeetingTypePKID,
                "Name": vm.selectedMeetingType.Name,
                "DisplayName": vm.selectedMeetingType.DisplayName,
            };

            var meeting_PK_ID = "00000000-0000-0000-0000-000000000000";


            if (vm.meeting_PK_ID != null) {
                meeting_PK_ID = vm.meeting_PK_ID;
            }

            var assetName = appContext.getAssetName();
            var assetId = appContext.getAssetId()
            var assetDisplayName = appContext.getAssetDisplayName();
            if (vm.meetingDetail != null) {
                assetName = vm.meetingDetail.Meeting.AssetName;
                assetId = vm.meetingDetail.Meeting.AssetEquipID;
                assetDisplayName = vm.meetingDetail.Meeting.AssetDisplayName;
            }

            var meeting = {
                "Meeting_PK_ID": meeting_PK_ID,
                "StartTime": utility.toUTCDate(vm.meetingStartDateTime, false),
                "EndTime": utility.toUTCDate(vm.meetingEndDateTime, false),
                "AssetName": assetName,
                "AssetDisplayName": assetDisplayName,
                "CreatedBy": null,
                "MeetingLeader": meetingLaeder,
                "AssetEquipID": assetId,
                "MeetingType": meetingType,
                "IsCompleted": isCompleted
            };



            var checkListItems = null;
            if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.CheckListItems != null && vm.meetingTypeAttributes.CheckListItems.length > 0) {
                checkListItems = vm.meetingTypeAttributes.CheckListItems;
            }

            var meetingAttribute = null;

            if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.CheckListItems != null) {
                meetingAttribute = {
                    "MeetingAttributePKID": vm.meetingTypeAttributes.MeetingAttributePKID,
                    "AssetName": appContext.getAssetName(),
                    "AssetEquipId": appContext.getAssetId(),
                    "MeetingPKID": meeting_PK_ID,
                    "CheckListItems": checkListItems

                };
            }
            var meetingTasksAssociations = [];

            if (vm.currentMeetingsTaskCollections != null && vm.currentMeetingsTaskCollections.length > 0) {
                for (var i = 0 ; i < vm.currentMeetingsTaskCollections.length ; i++) {
                    var isLinkedTask = vm.currentMeetingsTaskCollections[i].State == "Draft" ? false : true;
                    meetingTasksAssociations.push({ "TaskID": vm.currentMeetingsTaskCollections[i].TaskId, "IsLinkedTask": isLinkedTask });
                }
            }

            var meetingDetail = {
                "Notes": notes,
                "Participants": paticipants,
                "Meeting": meeting,
                "MeetingAttribute": meetingAttribute,
                "MeetingTasksAssociations": meetingTasksAssociations
            };

            meetingsService.editMeetings(meetingDetail)
                  .then(function (data) {
                      if (!utility.isError(data)) {
                          if (data[0].OperationResult.Status == true) {
                              clearPageDirty();
                              if (isCompleted) {
                                  notifications.success("Submitted successfully", false, true);
                              }
                              else {
                                  notifications.success("Saved successfully", false, true);
                              }
                              meetingDetail.Meeting.Meeting_PK_ID = data[0].MeetingDetail.Meeting.Meeting_PK_ID;
                              vm.meetingDetail = meetingDetail;
                              populateMeetingContent(isCompleted);
                              vm.meeting_PK_ID = meetingDetail.Meeting.Meeting_PK_ID;
                              getMeetingList(true);
                          }
                          else
                              notifications.error(data[0].OperationResult.Message, false, true);
                      }
                  });


        }
        /*******************************/


        function getTaskObjectForGrid(task) {
            var typeDisplayName = getTaskTypeDisplayName(task.TypeName);

            var priorityInfo = getPriorityInfo(task.PriorityOrder);
            var priority_PK_Id = "";
            var priorityDisplayName = "";
            if (priorityInfo != null) {
                priority_PK_Id = priorityInfo.TaskPriority_PK_Id;
                priorityDisplayName = priorityInfo.DisplayName;
            }

            var assignedTo = "";
            var assigneeList = null;
            if (task.TaskDetails.PersonAssignees != null && task.TaskDetails.PersonAssignees.length > 0) {
                for (var i = 0 ; i < task.TaskDetails.PersonAssignees.length; i++) {
                    if (assignedTo != "")
                        assignedTo += ", ";
                    assignedTo += task.TaskDetails.PersonAssignees[i].DIsplayName;
                }
                assigneeList = task.TaskDetails.PersonAssignees;
            }


            var startDate = vm.toLocalDateFormat(task.StartTime);
            var endDate = vm.toLocalDateFormat(task.EndTime);
            var carryOverDays = parseInt(task.TaskDetails.CarryOverDays);
            var carryOverHours = parseInt(task.TaskDetails.CarryOverHours);

            var task = {
                "Name": task.Name,
                "Type": task.TypeName,
                "TypeDisplayName": typeDisplayName,
                "PriorityId": priority_PK_Id,
                "PriorityOrder": task.PriorityOrder,
                "Priority": priorityDisplayName,
                "Description": task.TaskDetails.Description,
                "AssignedTo": assignedTo,
                "AssigneeList": task.TaskDetails.PersonAssignees,
                "State": task.State,
                "TaskPlannedStartDate": startDate,
                "TaskPlannedEndDate": endDate,
                "TaskId": task.TaskId,
                "CarryOverDays": carryOverDays,
                "CarryOverHours": carryOverHours,
                "TaskType": "Current Tasks"
            }
            return task;
        }

        vm.showTaskDetail = function (task, $event) {
            $event.preventDefault();
            $event.stopPropagation();
            onSelectTasksFillInputs(task);
        }

        function onSelectTasksFillInputs(task) {

            if (vm.isTaskPanelDirty) {

                vm.confirmDialogPopupMessage = "Do you want to save the changes?";
                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    onSelectTasksFillInputs(task);
                };
                return;
            }

            if (vm.allUsersForThisAsset == null || vm.allUsersForThisAsset.length == 0) {
                getAllUsersForThisAsset(function () {
                    setTimeout(function () {
                        onSelectTasksFillInputs(task);
                    }, 10);
                });
                return;
            }

            clearTaskErrorMessage();

            vm.newTask.TaskId = task.TaskId;
            vm.newTask.Name = task.Name;
            vm.newTask.Type.value(task.Type);
            vm.newTask.Description = task.Description;

            vm.newTask.TaskPlannedStartDate = kendo.toString(task.TaskPlannedStartDate, utility.getCustomDateTimeFormat());
            vm.newTask.TaskPlannedEndDate = kendo.toString(task.TaskPlannedEndDate, utility.getCustomDateTimeFormat());
            vm.newTask.TaskPriority.value(task.PriorityOrder);
            vm.newTask.TaskCarryOverDayValue = task.CarryOverDays;
            vm.newTask.TaskCarryOverHourValue = task.CarryOverHours;

            var assignees = [];
            if (task.AssigneeList != null && task.AssigneeList.length > 0) {
                for (var i = 0 ; i < task.AssigneeList.length; i++) {
                    assignees.push(task.AssigneeList[i].UserPrincipal);
                }
            }

            vm.newTask.AssignedTo.value(assignees);
            vm.showTaskEditPanel = true;

            vm.clearTaskPanelDirty();
            focusControl("newTaskName", "text");
            vm.disableTaskEditControl = false;

            if (vm.isMeetingCompleted == true || task.State != "Draft") {
                vm.disableTaskEditControl = true;
            }
            if (vm.hasEditMeetingPermission == false) {
                vm.disableTaskEditControl = false;
            }

            enableOrDisableTaskPanelKendoEditor();
        }

        vm.cancelTaskDetails = function ($event) {
            $event.preventDefault();
            $event.stopImmediatePropagation();
            $event.stopPropagation();

            if (vm.isTaskPanelDirty) {

                vm.confirmDialogPopupMessage = "Do you want to save the changes?";
                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    vm.cancelTaskDetails($event);
                };
                return;
            }

            vm.showTaskEditPanel = false;

        }

        function clearAllErrorMessages() {
            vm.newMeetings.ErrLeaderName = "";
            vm.newMeetings.ErrMeetingsStartDate = "";
            vm.newMeetings.ErrMeetingsEndDate = "";
            vm.newMeetings.ErrMeetingsNotes = "";
            clearTaskErrorMessage();
        }

        function clearTaskErrorMessage() {
            vm.newTask.ErrName = "";
            vm.newTask.ErrType = "";
            vm.newTask.ErrDescription = "";
            vm.newTask.ErrAssignedTo = "";
            vm.newTask.ErrTaskPriority = "";
            vm.newTask.ErrTaskPlannedStartDate = "";
            vm.newTask.ErrTaskPlannedEndDate = "";
        }

        vm.createNewTask = function () {

            if (vm.disableNewActionButton == true) {
                return;
            }

            if (vm.isTaskPanelDirty) {
                vm.confirmDialogPopupMessage = "Do you want to save the changes?";
                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    vm.createNewTask();
                };
                return;
            }

            if (vm.allUsersForThisAsset == null || vm.allUsersForThisAsset.length == 0) {
                getAllUsersForThisAsset(function () {
                    vm.createNewTask();
                });
                return;
            }

            clearTaskErrorMessage();
            clearTaskControlValues();

            vm.showTaskEditPanel = true;







            vm.clearTaskPanelDirty();
            if (vm.newTask.AssignedTo != null && vm.newTask.AssignedTo.value != null)
                vm.newTask.AssignedTo.value("");
            focusControl("newTaskName", "text");
            vm.disableTaskEditControl = false;
            enableOrDisableTaskPanelKendoEditor();
        }


        function enableOrDisableTaskPanelKendoEditor() {
            if (vm.disableTaskEditControl == false) {

                if ($('#newTaskDescription').data() != null && $('#newTaskDescription').data().kendoEditor != null)
                    $($('#newTaskDescription').data().kendoEditor.body).attr('contenteditable', true);
            }
            else {

                if ($('#newTaskDescription').data() != null && $('#newTaskDescription').data().kendoEditor != null)
                    $($('#newTaskDescription').data().kendoEditor.body).attr('contenteditable', false);
            }

        }

        function clearTaskControlValues() {
            vm.newTask.TaskId = "00000000-0000-0000-0000-000000000000";
            vm.newTask.Name = "";
            if (vm.newTask.Type != null)
                vm.newTask.Type.value("");
            vm.newTask.Description = "";
            vm.newTask.TaskPlannedStartDate = kendo.toString(new Date(), utility.getCustomDateTimeFormat());
            vm.newTask.TaskPlannedEndDate = "";
            if (vm.newTask.TaskPriority != null)
                vm.newTask.TaskPriority.value("");
            vm.newTask.TaskCarryOverDayValue = "";
            vm.newTask.TaskCarryOverHourValue = "";
        }

        function getAddorUpdateTaskData() {

            var assetName = appContext.getAssetName();
            var assetId = appContext.getAssetId();
            var assetDisplayName = appContext.getAssetDisplayName();

            if (vm.meetingDetail != null) {
                assetName = vm.meetingDetail.Meeting.AssetName;
                assetId = vm.meetingDetail.Meeting.AssetEquipID;
                assetDisplayName = vm.meetingDetail.Meeting.AssetDisplayName;
            }

            var assignees = vm.newTask.AssignedTo.value();
            var assigneesDetails = [];

            for (var i = 0; i < assignees.length; i++) {
                var emailId = assignees[i];
                var userInfo = getUserInfo(emailId);
                if (userInfo != null) {
                    var assignee = {
                        "IsGroup": false,
                        "UserPrincipal": userInfo.UserPrincipal,
                        "EID": userInfo.EID,
                        "DisplayName": userInfo.DisplayName,
                        "EmailID": userInfo.EmailID
                    };
                    assigneesDetails.push(assignee);
                }
            }

            var unformattedTaskDescription = $('<div>' + vm.newTask.Description + '</div>').text();
            var taskDetail = {
                AssetName: assetName,
                AssetDisplayName: assetDisplayName,
                EquipmentId: assetId,
                TaskId: vm.newTask.TaskId,
                TaskName: vm.newTask.Name,
                StartDate: utility.toUTCDate(vm.newTask.TaskPlannedStartDate, false),
                EndDate: utility.toUTCDate(vm.newTask.TaskPlannedEndDate, false),
                PriorityOrder: vm.newTask.TaskPriority.value(),
                ActualStartTime: "",
                ActualEndTime: "",
                State: "Draft",
                TypeName: vm.newTask.Type.value(),
                CarryOverDays: parseInt(vm.newTask.TaskCarryOverDayValue),
                CarryOverHours: parseInt(vm.newTask.TaskCarryOverHourValue),
                TaskDescription: vm.newTask.Description,
                PlainDescription: unformattedTaskDescription,
                AssignedTo: assigneesDetails,
                LinkDetails: null,
                AttachmentDetails: null
            }

            return taskDetail;
        }


        vm.saveTaskDetails = function ($event) {
            $event.stopPropagation();
            setTask();
        }

        function setTask() {

            if (validateTaskInputs() == false || validateMeetingInputs(false) == false)
                return;

            var task = getAddorUpdateTaskData();

            meetingsService.setTask(task)
              .then(function (data) {
                  if (!utility.isError(data)) {
                      if (data[0].Status == "True") {

                          vm.clearTaskPanelDirty();

                          if (vm.newTask.TaskId == "00000000-0000-0000-0000-000000000000") {
                              vm.newTask.TaskId = data[0].Reference;
                              data[0].Task.TaskId = vm.newTask.TaskId;
                              var taskObject = getTaskObjectForGrid(data[0].Task);
                              vm.currentMeetingsTaskCollections.push(taskObject);
                              editMeetingDetails("MEETINGS_SAVE", true);
                          }
                          else {

                              var taskObject = getTaskObjectForGrid(data[0].Task);
                              if (vm.currentMeetingsTaskCollections != null && vm.currentMeetingsTaskCollections.length > 0) {
                                  for (var i = 0 ; i < vm.currentMeetingsTaskCollections.length ; i++) {
                                      if (vm.currentMeetingsTaskCollections[i].TaskId == vm.newTask.TaskId) {
                                          vm.currentMeetingsTaskCollections[i] = taskObject;
                                          break;
                                      }
                                  }
                              }
                          }
                      }
                      else {
                          notifications.error(data[0].Message, false, true);
                      }

                  }
              });
        }


        /******************/
        vm.isTaskPanelDirty = false;

        vm.makeTaskPanelDirty = function () {
            if (vm.isMeetingCompleted == false) {
                vm.isTaskPanelDirty = true;
                vm.makePageDirty();
            }
        }


        vm.clearTaskPanelDirty = function () {
            vm.isTaskPanelDirty = false;
        }

        vm.newTaskNameChange = function () {
            vm.newTask.ErrName = "";
            if (vm.newTask.Name == null || vm.newTask.Name == "") {
                vm.newTask.ErrName = "Please enter the name";
                return false;
            }
            vm.makeTaskPanelDirty();
        }

        vm.newTaskTypeChange = function () {
            vm.makeTaskPanelDirty();
            vm.newTask.ErrType = "";
            if (vm.newTask.Type == null || vm.newTask.Type.value().length == 0) {
                vm.newTask.ErrType = "Please select type";
                return false;
            }

        }

        vm.newTaskAssigneChange = function () {
            vm.makeTaskPanelDirty();
            vm.newTask.ErrAssignedTo = "";
            if (vm.newTask.AssignedTo == null || vm.newTask.AssignedTo.value().length == 0) {
                vm.newTask.ErrAssignedTo = "Please select Assignee";
                return false;
            }
        }

        function newTaskDescriptionChange() {
            vm.makeTaskPanelDirty();
            vm.newTask.ErrDescription = "";
        }

        vm.newTaskPriorityChange = function () {
            vm.makeTaskPanelDirty();
            vm.newTask.ErrTaskPriority = "";

            if (vm.newTask.TaskPriority == null || vm.newTask.TaskPriority.value().length == 0) {
                vm.newTask.ErrTaskPriority = "Please select priority";
                return false;
            }
        }


        vm.newTaskStartTimeChange = function () {
            vm.makeTaskPanelDirty();
            vm.newTask.ErrTaskPlannedStartDate = "";
            if (vm.newTask.TaskPlannedStartDate == null || vm.newTask.TaskPlannedStartDate == "") {
                vm.newTask.ErrTaskPlannedStartDate = "Please enter start time";
            }
        }

        vm.isValidStartDate = function () {
            if (vm.newTask.TaskPlannedStartDate != null && vm.newTask.TaskPlannedStartDate != "") {
                var date = kendo.parseDate(vm.newTask.TaskPlannedStartDate, utility.getCustomDateTimeFormat());
                if (!date) {
                    vm.newTask.ErrTaskPlannedStartDate = "Please provide a valid start time";
                }
            }
        }

        vm.newTaskEndTimeChange = function () {
            vm.makeTaskPanelDirty();
            vm.newTask.ErrTaskPlannedEndDate = "";
            if (vm.newTask.TaskPlannedEndDate == null || vm.newTask.TaskPlannedEndDate == "") {
                vm.newTask.ErrTaskPlannedEndDate = "Please enter end time";
            }
        }

        vm.newTaskCarryOverDayChange = function ($event) {
            if ($event != null)
                vm.makeTaskPanelDirty();
        }

        vm.newTaskCarryOverHourChange = function ($event) {
            if ($event != null)
                vm.makeTaskPanelDirty();
        }

        vm.isValidEndDate = function () {
            if (vm.newTask.TaskPlannedEndDate != null && vm.newTask.TaskPlannedEndDate != "") {
                var date = kendo.parseDate(vm.newTask.TaskPlannedEndDate, utility.getCustomDateTimeFormat());
                if (!date) {
                    vm.newTask.ErrTaskPlannedEndDate = "Please provide a valid end time";

                }
                else {
                    if (Number(kendo.parseDate(vm.newTask.TaskPlannedStartDate, utility.getCustomDateTimeFormat())) >= Number(kendo.parseDate(vm.newTask.TaskPlannedEndDate, utility.getCustomDateTimeFormat()))) {
                        vm.newTask.ErrTaskPlannedEndDate = "End time should be greater than start time";
                    }
                }
            }




        }

        function validateTaskInputs() {
            var isValid = true;
            var invalidControlList = [];

            clearTaskErrorMessage();


            if (vm.newTask.Name == null || vm.newTask.Name == "") {
                vm.newTask.ErrName = "Please enter the name";
                invalidControlList.push({ "Id": "newTaskName", "Type": "text" });
            }
            if (vm.newTask.Type == null || vm.newTask.Type.value().length == 0) {
                vm.newTask.ErrType = "Please select type";
                invalidControlList.push({ "Id": "newTaskType", "Type": "kendoDropDownList" });
            }
            if (vm.newTask.Description == null || vm.newTask.Description == "") {
                vm.newTask.ErrDescription = "Please enter the description";
                invalidControlList.push({ "Id": "newTaskDescription", "Type": "kendoEditor" });
            }
            if (vm.newTask.AssignedTo == null || vm.newTask.AssignedTo.value().length == 0) {
                vm.newTask.ErrAssignedTo = "Please select Assignee";
                invalidControlList.push({ "Id": "newTaskAssignedTo", "Type": "kendoMultiSelect" });
            }
            if (vm.newTask.TaskPriority == null || vm.newTask.TaskPriority.value().length == 0) {
                vm.newTask.ErrTaskPriority = "Please select priority";
                invalidControlList.push({ "Id": "newTaskPriority", "Type": "kendoDropDownList" });
            }
            if (vm.newTask.TaskPlannedStartDate == null || vm.newTask.TaskPlannedStartDate == "") {
                vm.newTask.ErrTaskPlannedStartDate = "Please enter start time";
                invalidControlList.push({ "Id": "newTaskStartTime", "Type": "kendoDateTimePicker" });
            }
            else {
                var date = kendo.parseDate(vm.newTask.TaskPlannedStartDate, utility.getCustomDateTimeFormat());
                if (!date) {
                    vm.newTask.ErrTaskPlannedStartDate = "Please provide a valid start time";
                    invalidControlList.push({ "Id": "newTaskStartTime", "Type": "kendoDateTimePicker" });
                }
            }

            if (vm.newTask.TaskPlannedEndDate == null || vm.newTask.TaskPlannedEndDate == "") {
                vm.newTask.ErrTaskPlannedEndDate = "Please enter end time";
                invalidControlList.push({ "Id": "newTaskEndTime", "Type": "kendoDateTimePicker" });
            }
            else {
                date = kendo.parseDate(vm.newTask.TaskPlannedEndDate, utility.getCustomDateTimeFormat());
                if (!date) {
                    vm.newTask.ErrTaskPlannedEndDate = "Please provide a valid end time";
                    invalidControlList.push({ "Id": "newTaskEndTime", "Type": "kendoDateTimePicker" });
                }
                else {
                    if (Number(kendo.parseDate(vm.newTask.TaskPlannedStartDate, utility.getCustomDateTimeFormat())) >= Number(kendo.parseDate(vm.newTask.TaskPlannedEndDate, utility.getCustomDateTimeFormat()))) {
                        vm.newTask.ErrTaskPlannedEndDate = "End time should be greater than start time";
                        invalidControlList.push({ "Id": "newTaskEndTime", "Type": "kendoDateTimePicker" });
                    }
                }
            }
            if (invalidControlList != null && invalidControlList.length > 0) {
                focusControl(invalidControlList[0].Id, invalidControlList[0].Type);
                return false;
            }
            else {
                return true;
            }


        }

        function focusControl(controlId, controlType) {

            if (controlId != null) {

                if (controlType == "kendoDropDownList" || controlType == "kendoComboBox" || controlType == "kendoNumericTextBox" || controlType == "kendoMultiSelect" || controlType == "kendoEditor") {
                    var kendoControl = $("#" + controlId).data(controlType);
                    if (kendoControl != null) {
                        setTimeout(function () {
                            kendoControl.focus();
                        }, 100);
                    }
                }
                else {
                    setTimeout(function () {
                        var itemCount = $("#" + controlId).length;
                        if (itemCount > 0)
                            $("#" + controlId).focus();
                    }, 100);
                }
            }
        }


        vm.confirmDialogYesClick = function () {
            $scope.confirmDialogPopup.close();
            if (vm.isTaskPanelDirty) {
                setTask();
            }
            else {
                editMeetingDetails("MEETINGS_SAVE");
            }

        }

        vm.confirmDialogNoClick = function () {
            $scope.confirmDialogPopup.close();
            clearPageDirty();
            vm.confirmDialogNoClickCallBackFunction();
        }

        vm.confirmDialog2YesClick = function () {
            $scope.confirmDialog2.close();
            vm.confirmDialog2YesClickCallBackFunction();

        }




        vm.confirmDialog2NoClick = function () {
            $scope.confirmDialog2.close();
        }


        vm.confirmDialogCancelClick = function () {
            $scope.confirmDialogPopup.close();
        }

        vm.getMeetingDetails = function (meetingId) {

            if (vm.isPageDirty == true) {
                vm.confirmDialogPopupMessage = "Do you want to save the changes?";
                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    vm.getMeetingDetails(meetingId);
                };
                return;
            }


            vm.meeting_PK_ID = meetingId;
            var meeting = {
                "Meeting_PK_ID": meetingId
            };

            meetingsService.getMeetingDetails(meetingId, null, null)
                    .then(function (data) {
                        if (!utility.isError(data)) {
                            vm.meetingDetail = data;

                            populateMeetingContent(true);
                        }
                    });
        }


        function removeDuplicates(arr, prop) {
            var new_arr = [];
            var lookup = {};

            for (var i in arr) {
                lookup[arr[i][prop]] = arr[i];
            }

            for (i in lookup) {
                new_arr.push(lookup[i]);
            }

            return new_arr;
        }

        function populateMeetingContent(doRefreshTask) {

            vm.meeting_PK_ID = vm.meetingDetail.Meeting.Meeting_PK_ID;

            vm.selectedMeetingType = getMeetingTypeForGivenName(vm.meetingDetail.Meeting.MeetingType.Name);
            var checkListItems = null;
            if (vm.meetingDetail.MeetingAttribute != null && vm.meetingDetail.MeetingAttribute.CheckListItems != null && vm.meetingDetail.MeetingAttribute.CheckListItems.length > 0) {
                checkListItems = vm.meetingDetail.MeetingAttribute.CheckListItems;
            }
            populateMeetingParticipants(vm.meetingDetail.Participants, false);

            if (doRefreshTask == true)
                vm.createNewMeeting(vm.selectedMeetingType, false, checkListItems);

            vm.currentMeetingAssetName = vm.meetingDetail.Meeting.AssetDisplayName;

            var userInfo = getUserInfoFromParticipants(vm.meetingDetail.Meeting.MeetingLeader.EmailID, vm.meetingDetail.Meeting.MeetingLeader.UserPrincipal);
            if (userInfo == null) {
                var user2 = {
                    "IsSelected": false,
                    "EmailID": vm.meetingDetail.Meeting.MeetingLeader.EmailID,
                    "DisplayName": vm.meetingDetail.Meeting.MeetingLeader.DisplayName,
                    "UserPrincipal": vm.meetingDetail.Meeting.MeetingLeader.UserPrincipal
                };
                vm.allMeetingLeaders.push(user2);
            }
            setTimeout(function () {
                if (vm.meetingLeaderDropDown != null && vm.meetingLeaderDropDown.value != null)
                    vm.meetingLeaderDropDown.value(vm.meetingDetail.Meeting.MeetingLeader.UserPrincipal);
            }, 100);




            vm.meetingStartDateTime = vm.toLocalDate(vm.meetingDetail.Meeting.StartTime);

            if (vm.meetingDetail.Meeting.EndTime != null && vm.meetingDetail.Meeting.EndTime != "")
                vm.meetingEndDateTime = vm.toLocalDate(vm.meetingDetail.Meeting.EndTime);
            else
                vm.meetingEndDateTime = "";


            vm.meetingNote = vm.meetingDetail.Notes[0].Notes;

            if (vm.meetingDetail.Meeting.IsCompleted == true) {
                Intuition.ActionBar.HideIcon("MEETINGS_CANCEL");
                Intuition.ActionBar.HideIcon("MEETINGS_SAVE");
                Intuition.ActionBar.HideIcon("MEETINGS_PUBLISH");
            }
            vm.meeting_PK_ID = vm.meetingDetail.Meeting.Meeting_PK_ID;
            vm.meetingTitle = vm.currentMeetingAssetName + " " + vm.selectedMeetingType.Name


            if (doRefreshTask == true) {
                getTaskGrid(vm.meetingDetail.MeetingTasksAssociations);
            }

            clearPageDirty();
        }


        function populateMeetingParticipants(meetingParticipants, isPreviousMeetingParticipants) {

            vm.currentMeetingParticipants = [];
            vm.allParticipantsForThisMeeting = [];

            if (meetingParticipants != null && meetingParticipants.length > 0) {

                vm.currentMeetingParticipants = JSON.parse(JSON.stringify(meetingParticipants));
                vm.allParticipantsForThisMeeting = JSON.parse(JSON.stringify(meetingParticipants));

                if (isPreviousMeetingParticipants == true) {
                    for (var i = 0; i < vm.currentMeetingParticipants.length; i++) {
                        vm.allParticipantsForThisMeeting[i].IsAttended = false;
                    }
                }

                var previousMeetingLeadersWithUserPrincipal = JSON.parse(JSON.stringify(meetingParticipants));
                var usersWithUserPrincipal = $.grep(previousMeetingLeadersWithUserPrincipal, function (leader, index) {
                    return (leader.UserPrincipal != null && leader.UserPrincipal != '');

                });


                vm.allMeetingLeaders = [];
                vm.allMeetingLeaders = JSON.parse(JSON.stringify(usersWithUserPrincipal));

                var mLeader = getUserInfo(vm.currentUserInfo.Mail);

                if (mLeader == null) {
                    addCurrentUserInfoInMeetingLeader();
                }
                else {
                    setTimeout(function () {
                        vm.meetingLeaderDropDown.value(mLeader.UserPrincipal);

                    }, 100);
                }



                for (var i = 0; i < meetingParticipants.length; i++) {
                    var email = meetingParticipants[i].EmailID;
                    var userPrincipal = meetingParticipants[i].UserPrincipal;
                    var userInfo = getUserInfoFromParticipants(email, userPrincipal);
                    if (userInfo != null) {
                        if (isPreviousMeetingParticipants == true) {
                            userInfo.IsSelected = false;
                        }
                        else {
                            if (userInfo.IsAttended == true) {
                                userInfo.IsSelected = true;
                            }
                        }
                    }


                }


            }
        }

        function getTaskGrid(meetingTasksAssociations) {
            var taskIds = [];
            if (meetingTasksAssociations != null && meetingTasksAssociations.length > 0) {
                for (var i = 0 ; i < meetingTasksAssociations.length; i++) {
                    taskIds.push(meetingTasksAssociations[i].TaskID);
                }
                getTaskDetails(taskIds);
            }
        }

        function getTaskDetails(taskIds) {

            meetingsService.getTaskDetails(taskIds)
                .then(function (data) {
                    if (!utility.isError(data)) {
                        if (data.Tasks != null && data.Tasks.length > 0) {

                            UpdateMeetingsTasksGrid(data.Tasks);



                        }
                        else
                            notifications.error("Error occured while getting task details", false, true);
                    }
                });

        }

        function UpdateMeetingsTasksGrid(tasks) {
            vm.currentMeetingsTaskCollections = [];


            if (tasks != null && tasks.length > 0) {
                for (var i = 0 ; i < tasks.length; i++) {
                    var taskObject = getTaskObjectForGrid(tasks[i]);
                    vm.currentMeetingsTaskCollections.push(taskObject);
                }
            }

        }

        function getMeetingTypeForGivenName(meetingTypeName, meetingTypeDisplayName) {
            var meetingType = null;
            for (var i = 0 ; i < vm.meetingTypes.length; i++) {
                meetingType = vm.meetingTypes[i];
                if (meetingType.Name == meetingTypeName) {
                    if (meetingTypeDisplayName != null && meetingTypeDisplayName != "")
                        meetingType.DisplayName = meetingTypeDisplayName;
                    return meetingType;
                }
                else {
                    meetingType = null;
                }
            }
            return meetingType;
        }


        //Create Meeting Popup
        vm.createNewMeetingType = function () {

            if (vm.isPageDirty == true) {
                vm.confirmDialogPopupMessage = "Do you want to save the changes?";

                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    vm.createNewMeetingType();
                }
                return false;;
            }


            vm.disableMeetingTypeNameTextbox = false;
            vm.meetingTypePKID = "00000000-0000-0000-0000-000000000000";
            vm.meetingTypeName = "";
            vm.meetingTypeDisplayName = "";
            openEditMeetingTypePopup();
        }

        vm.editMeetingType = function (meetingType) {

            if (vm.isPageDirty == true) {
                vm.confirmDialogPopupMessage = "Do you want to save the changes?";

                $scope.confirmDialogPopup.center();
                $scope.confirmDialogPopup.open();
                vm.confirmDialogNoClickCallBackFunction = function () {
                    vm.editMeetingType(meetingType);
                }
                var previousValue = vm.meetingType.value();
                setTimeout(function () {
                    vm.meetingType.value(previousValue);
                }, 10);

                return false;;
            }



            vm.disableMeetingTypeNameTextbox = true;
            vm.meetingTypePKID = meetingType.MeetingTypePKID;
            vm.meetingTypeName = meetingType.Name;
            vm.meetingTypeDisplayName = meetingType.DisplayName;
            openEditMeetingTypePopup();
        }

        function openEditMeetingTypePopup() {

            $scope.editMeetingTypePopup.center();
            $scope.editMeetingTypePopup.open();
            focusControl("txtMeetingTypeName", "text");
        }
        //Save Meeting in Create Meeting Popup
        vm.onMeetingTypeSave = function () {
            if (vm.meetingTypeName == "") {
                notifications.warning("Please enter the meeting type name", false, true);
                return;
            }
            else if (vm.meetingTypeDisplayName == "") {
                notifications.warning("Please enter the meeting type display name", false, true);
                return;
            }

            else if (vm.meetingTypeName != "" && vm.disableMeetingTypeNameTextbox == false) {

                for (var i = 0 ; i < vm.meetingTypes.length; i++) {
                    if (vm.meetingTypes[i].Name.toLowerCase() == vm.meetingTypeName.toLowerCase()) {
                        notifications.warning("Given meeting type name is already exists. Please provide different name", false, true);
                        return;
                    }
                }

            }
            if (vm.meetingTypePKID == "")
                vm.meetingTypePKID = "00000000-0000-0000-0000-000000000000";

            var meetingType = {
                "MeetingTypePKID": vm.meetingTypePKID,
                "Name": vm.meetingTypeName,
                "DisplayName": vm.meetingTypeDisplayName

            }
            addOreditMeetingType(meetingType);
        }

        //Cancel Meeting in Create Meeting Popup
        vm.onMeetingTypeCancel = function () {
            $scope.editMeetingTypePopup.close();
        }

        function addOreditMeetingType(meetingType) {
            meetingsService.editMeetingType(meetingType)
                 .then(function (data) {
                     if (!utility.isError(data)) {
                         if (data[0].Status == true) {
                             $scope.editMeetingTypePopup.close();
                             notifications.success("Meeting type saved successfully", false, true);

                             var newMeetingType = getMeetingTypeForGivenName(meetingType.Name, meetingType.DisplayName);
                             if (newMeetingType == null) {
                                 vm.meetingTypes.push(meetingType);
                             }
                             setTimeout(function () {
                                 vm.meetingType.value(meetingType.Name);
                                 vm.meetingTypeChange(meetingType);
                             }, 10);


                         }
                         else
                             notifications.error(data[0].OperationResult.Message, false, true);
                     }
                 });
        }

        vm.checkListName = null;

        vm.checkListItemClick = function (checkListItem) {
            if (vm.isMeetingCompleted == false)
                checkListItem.IsChecked = !checkListItem.IsChecked;
        }


        vm.addCheckListClick = function () {

            vm.checkListName = "";
            $scope.editCheckListPopup.center();
            $scope.editCheckListPopup.open();
            setTimeout(function () { focusControl("txtCheckListName", "text"); }, 1000);

        }

        vm.deleteChecklist = function (event, checkListItem) {
            event.stopImmediatePropagation();


            if (checkListItem != null) {
                vm.confirmDialogPopupMessage = "Are you sure to delete the discussion point '" + checkListItem.Name + "'?";
                vm.confirmDialogPopupMessage2 = "";
                $scope.confirmDialog2.center();
                $scope.confirmDialog2.open();

                vm.confirmDialog2YesClickCallBackFunction = function () {
                    deleteDiscussionPoint(checkListItem);
                };
            }
        }


        function deleteDiscussionPoint(checkListItem) {
            var MeetingTypeAttributePKID = "00000000-0000-0000-0000-000000000000";
            if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.MeetingTypeAttributePKID != null) {
                MeetingTypeAttributePKID = vm.meetingTypeAttributes.MeetingTypeAttributePKID;
            }
            var checkListItems = [];
            if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.CheckListItems != null && vm.meetingTypeAttributes.CheckListItems.length > 0) {
                checkListItems = vm.meetingTypeAttributes.CheckListItems;
            }
            checkListItems = checkListItems.filter(function (el) { return el.Name !== checkListItem.Name });
            var meetingType = {
                "MeetingTypePKID": vm.selectedMeetingType.MeetingTypePKID,
                "Name": vm.selectedMeetingType.Name,
                "DisplayName": vm.selectedMeetingType.DisplayName,
            }
            var assetName = appContext.getAssetName();
            var assetId = appContext.getAssetId()
            if (vm.meetingDetail != null) {
                assetName = vm.meetingDetail.Meeting.AssetName;
                assetId = vm.meetingDetail.Meeting.AssetEquipID;
            }
            var meetingAttribute = {
                "MeetingTypeAttributePKID": MeetingTypeAttributePKID,
                "MeetingType": meetingType,
                "AssetName": assetName,
                "AssetEquipId": assetId,
                "CheckListItems": checkListItems
            };

            meetingsService.editMeetingTypeAttributes(meetingAttribute)
                  .then(function (data) {

                      if (!utility.isError(data)) {
                          if (data[0].OperationResult.Status == true) {
                              $scope.editCheckListPopup.close();
                              notifications.success("Discussion point deleted successfully", false, true);
                              vm.meetingTypeAttributes = data[0].MeetingTypeAttribute;
                              getChecklistForSelectedMeeting();
                              makePageDirty();
                          }
                          else
                              notifications.error(data[0].OperationResult.Message, false, true);
                      }
                  });
        }
        vm.onCheckListItemCancel = function () {
            $scope.editCheckListPopup.close();
        }

        vm.onCheckListItemSave = function () {
            var isChecklistDuplicate = false;
            if ($.trim(vm.checkListName) == "") {
                notifications.warning("Please enter name", false, true);
                return;
            }
            else {
                if (vm.meetingTypeAttributes)
                    angular.forEach(vm.meetingTypeAttributes.CheckListItems, function (checklist) {
                        if (checklist.Name.toLowerCase() == $.trim(vm.checkListName).toLowerCase()) {
                            isChecklistDuplicate = true;
                        }
                    });
            }

            if (!isChecklistDuplicate) {
                var MeetingTypeAttributePKID = "00000000-0000-0000-0000-000000000000";
                if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.MeetingTypeAttributePKID != null) {
                    MeetingTypeAttributePKID = vm.meetingTypeAttributes.MeetingTypeAttributePKID;
                }

                var checkListItems = [];
                if (vm.meetingTypeAttributes != null && vm.meetingTypeAttributes.CheckListItems != null && vm.meetingTypeAttributes.CheckListItems.length > 0) {
                    checkListItems = vm.meetingTypeAttributes.CheckListItems;
                }
                checkListItems.push({ "Name": $.trim(vm.checkListName), "IsChecked": false });

                var meetingType = {
                    "MeetingTypePKID": vm.selectedMeetingType.MeetingTypePKID,
                    "Name": vm.selectedMeetingType.Name,
                    "DisplayName": vm.selectedMeetingType.DisplayName,
                }
                var assetName = appContext.getAssetName();
                var assetId = appContext.getAssetId()
                if (vm.meetingDetail != null) {
                    assetName = vm.meetingDetail.Meeting.AssetName;
                    assetId = vm.meetingDetail.Meeting.AssetEquipID;
                }
                var meetingAttribute = {
                    "MeetingTypeAttributePKID": MeetingTypeAttributePKID,
                    "MeetingType": meetingType,
                    "AssetName": assetName,
                    "AssetEquipId": assetId,
                    "CheckListItems": checkListItems
                };

                meetingsService.editMeetingTypeAttributes(meetingAttribute)
                      .then(function (data) {

                          if (!utility.isError(data)) {
                              if (data[0].OperationResult.Status == true) {
                                  $scope.editCheckListPopup.close();
                                  notifications.success("Discussion point saved successfully", false, true);
                                  vm.meetingTypeAttributes = data[0].MeetingTypeAttribute;
                                  getChecklistForSelectedMeeting();
                                  makePageDirty();
                              }
                              else
                                  notifications.error(data[0].OperationResult.Message, false, true);
                          }
                      });
            }
            else {
                notifications.warning("Discussion Point already exists", false, true);
                return;
            }

        }


        vm.tasksSelected = [];

        vm.deleteNewTask = function () {
            if (vm.tasksSelected != null && vm.tasksSelected.length > 0) {

                vm.confirmDialogPopupMessage = "Are you sure to delete the selected task(s)?";
                vm.confirmDialogPopupMessage2 = "(Tasks copied from previous meeting will get disassociated from this meeting)";
                $scope.confirmDialog2.center();
                $scope.confirmDialog2.open();
                vm.confirmDialog2YesClickCallBackFunction = function () {
                    deleteTasks();
                };

            }
        }

        function deleteTasks() {
            if (vm.tasksSelected != null && vm.tasksSelected.length > 0) {
                var tempObject = []
                for (var i = 0 ; i < vm.tasksSelected.length; i++) {
                    var taskId = vm.tasksSelected[i];
                    for (var j = 0; j < vm.currentMeetingsTaskCollections.length; j++) {
                        if (vm.currentMeetingsTaskCollections[j].TaskId == taskId) {
                            vm.currentMeetingsTaskCollections.splice(j, 1);
                            break;
                        }
                    }
                }
                makePageDirty();
                vm.showTaskEditPanel = false;
            }
        }

        vm.dateTimeControlOptions = {
            format: utility.getCustomDateTimeFormat()
        };

        vm.taskGridOptions = {

            dataSource: {
                data: vm.currentMeetingsTaskCollections
            },
            group: { field: "TaskType" },
            columns: [

                {
                    field: "Name", title: "Task Name",
                    template: $('#hyperLinkColumn').html(),
                    headerAttributes: { title: "Task Name" }, attributes: { title: "#= Name #" }, width: "10%", filterable: true
                },
                    { field: "TypeDisplayName", title: "Type", headerAttributes: { title: "Type" }, attributes: { title: "#= TypeDisplayName #" }, width: "10%", template: "#= TypeDisplayName #", filterable: { multi: true } },

                    { field: "Priority", title: "Priority", headerAttributes: { title: "Priority" }, attributes: { title: "#= Priority #" }, width: "10%", template: "#= Priority #", filterable: { multi: true } },
                    {
                        field: "TaskPlannedStartDate",
                        title: "Start Time",
                        template: "#= kendo.toString(TaskPlannedStartDate, '" + utility.getCustomDateTimeFormat() + "')#",
                        headerAttributes: { title: "Start Time" },
                        attributes: { title: "#= kendo.toString(TaskPlannedStartDate, '" + utility.getCustomDateTimeFormat() + "')#" },
                        filterable: false,
                        width: "120px"
                    },
                    {
                        field: "TaskPlannedEndDate",
                        title: "End Time",
                        template: "#= kendo.toString(TaskPlannedEndDate, '" + utility.getCustomDateTimeFormat() + "')#",
                        headerAttributes: { title: "End Time" },
                        attributes: { title: "#= kendo.toString(TaskPlannedEndDate, '" + utility.getCustomDateTimeFormat() + "')#" },
                        filterable: false,
                        width: "120px"
                    },
                      {
                          field: "State", title: "Status", headerAttributes: { title: "Status" }, attributes: { title: "#= State #" }, width: "10%", template: "#= State #", filterable: { multi: true }
                      },
                    { field: "AssignedTo", title: "Assignees", headerAttributes: { title: "Assignees" }, attributes: { title: "#= AssignedTo #" }, width: "30%", template: "#= AssignedTo #", filterable: false }


            ],
            scrollable: false,
            sortable: true,
            filterable: true,
            selectable: "multiple, row",
            change: function (e) {

                var selected = $.map(this.select(), function (item) {
                    return $(item);
                });

                vm.tasksSelected = [];
                if (selected.length > 1) {
                    for (var i = 0 ; i < selected.length; i++) {
                        var task = this.dataItem(selected[i]);
                        if (task != null && task.TaskId != null)
                            vm.tasksSelected.push(task.TaskId);
                    }
                }
                else {
                    var task = this.dataItem(this.select());
                    if (task != null && task.TaskId != null)
                        vm.tasksSelected.push(task.TaskId);
                    //onSelectTasksFillInputs(task);
                }
            },
            dataBound: function (e) {

            }

        };

        vm.kendoeMeetingLeaderOptions = {
            height: 400,
            valueTemplate: '<span class="selected-value"" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>',
            template: '<span class="k-state-default" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>',
            open: onMeetingLeaderDropDownOpen
        };

        vm.kendoNewTaskTypeOptions = {
            valueTemplate: '<span class="selected-value"" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>',
            template: '<span class="k-state-default" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>',
        };

        vm.kendoNewTaskPriorityOptions = {
            valueTemplate: '<span class="selected-value"" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>',
            template: '<span class="k-state-default" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>'

        };



        vm.allAssigneeListOptions = {
            tagTemplate: '<span class="selected-value"" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>',
            template: '<span class="k-state-default" title="{{dataItem.DisplayName}}">{{dataItem.DisplayName}}</span>',
            placeholder: "Assignees",
            dataTextField: "DisplayName",
            dataValueField: "EmailID",
            valuePrimitive: true,
            autoBind: false,
            filter: "contains"
        };


        vm.carryOverHourDatasource = [
           { HourName: "0", HourValue: "0" },
           { HourName: "1", HourValue: "1" },
           { HourName: "2", HourValue: "2" },
           { HourName: "3", HourValue: "3" },
           { HourName: "4", HourValue: "4" },
           { HourName: "5", HourValue: "5" },
           { HourName: "6", HourValue: "6" },
           { HourName: "7", HourValue: "7" },
           { HourName: "8", HourValue: "8" },
           { HourName: "9", HourValue: "9" },
           { HourName: "10", HourValue: "10" },
           { HourName: "11", HourValue: "11" },
           { HourName: "12", HourValue: "12" },
           { HourName: "13", HourValue: "13" },
           { HourName: "14", HourValue: "14" },
           { HourName: "15", HourValue: "15" },
           { HourName: "16", HourValue: "16" },
           { HourName: "17", HourValue: "17" },
           { HourName: "18", HourValue: "18" },
           { HourName: "19", HourValue: "19" },
           { HourName: "20", HourValue: "20" },
           { HourName: "21", HourValue: "21" },
           { HourName: "22", HourValue: "22" },
           { HourName: "23", HourValue: "23" },
        ];

        vm.meetingTypeDDOptions = {
            template: '<div class="pull-left addPriorityDropDown width100--20" ng-click="vm.meetingTypeChange(dataItem)" title="{{dataItem.DisplayName}}" data-id={{dataItem.Name}} >{{dataItem.DisplayName}}</div><div><i title="Click here to edit meeting type" class="icon-edit pull-right small-icon" ng-click="vm.editMeetingType(dataItem);$event.stopPropagation();"></i></div>',
            headerTemplate: '<div class="k-widget k-header cursorPoniter" style="padding:4px; padding-bottom:8px;" title="Click here to add new meeting type" ng-click="vm.createNewMeetingType();$event.stopPropagation();" >Add New Type <i class="icon-add pull-right small-icon"></i></div>',
            open: onMeetingTypeDropDownOpen,

        };

        vm.carryOverHourDDOptions = {
            dataSource: vm.carryOverHourDatasource,
            dataTextField: "HourName",
            dataValueField: "HourValue",
            autoBind: 'true'
        };

        //Kendo Editor

        vm.kendoemeetingditorOptions = {
            change: function (e) { makePageDirty(); newMeetingEditorChange(); },
            keydown: function (e) { makePageDirty(); newMeetingEditorChange(); },
            resizable: {
                content: true,
                toolbar: true
            },
            pasteCleanup: {
                none: true
            }, tools: [
                         "insertUnorderedList",
                         "insertOrderedList",
                         "bold",
                         "italic",
                         "underline",
                         "strikethrough",
                         "foreColor",
                         "backColor",
                         "cleanFormatting",
                         "justifyLeft",
                         "justifyCenter",
                         "justifyRight",
                         "justifyFull",
                         "indent",
                         "createTable",
                         "addRowAbove",
                         "addRowBelow",
                         "addColumnLeft",
                         "addColumnRight",
                         "deleteRow",
                         "deleteColumn",

                         "fontSize",
                         {
                             name: "fontName",
                             items: [
                                          { text: "Andale Mono", value: "Andale Mono" },
                                          { text: "Arial", value: "Arial" },
                                          { text: "Arial Black", value: "Arial Black" },
                                          { text: "Comic Sans MS", value: "Comic Sans MS" },
                                          { text: "Courier New", value: "Courier New" },
                                          { text: "Garamond", value: "Garamond, serif" },
                                          { text: "Georgia", value: "Georgia" },
                                          { text: "Impact", value: "Impact" },
                                          { text: "Times New Roman", value: "Times New Roman" },
                                          { text: "Trebuchet MS", value: "Trebuchet MS" },
                                          { text: "Verdana", value: "Verdana" },
                                          { text: "Webdings", value: "Webdings" }
                             ]
                         }
            ]
        }


        vm.kendoeNewTaskEditorOptions = {
            change: function (e) { newTaskDescriptionChange(); },
            keydown: function (e) { newTaskDescriptionChange(); },
            resizable: {
                content: true,
                toolbar: true
            },
            pasteCleanup: {
                none: true
            }, tools: [
                         "insertUnorderedList",
                         "insertOrderedList",
                         "indent",
                         "bold",
                         "italic",
                         "underline",
                         "strikethrough",
                         "foreColor",
                         "backColor",
                         "cleanFormatting",
                         "justifyLeft",
                         "justifyCenter",
                         "justifyRight",
                         "justifyFull",
                         "createTable",
                         "addRowAbove",
                         "addRowBelow",
                         "addColumnLeft",
                         "addColumnRight",
                         "deleteRow",
                         "deleteColumn",

                         "fontSize",
                         {
                             name: "fontName",
                             items: [
                                          { text: "Andale Mono", value: "Andale Mono" },
                                          { text: "Arial", value: "Arial" },
                                          { text: "Arial Black", value: "Arial Black" },
                                          { text: "Comic Sans MS", value: "Comic Sans MS" },
                                          { text: "Courier New", value: "Courier New" },
                                          { text: "Garamond", value: "Garamond, serif" },
                                          { text: "Georgia", value: "Georgia" },
                                          { text: "Impact", value: "Impact" },
                                          { text: "Times New Roman", value: "Times New Roman" },
                                          { text: "Trebuchet MS", value: "Trebuchet MS" },
                                          { text: "Verdana", value: "Verdana" },
                                          { text: "Webdings", value: "Webdings" }
                             ]
                         }
            ]
        }


        //For kendo editor
        var defaultTools = kendo.ui.Editor.defaultTools;
        defaultTools["insertLineBreak"].options.shift = true;
        defaultTools["insertParagraph"].options.shift = true;

        $scope.$on("Intuition.ActionBarItemClicked", actionbarClicked);

        $scope.$on("ASSET_CHANGED", function () {
            initialize();
        });


        $scope.$on("SHIFT_CHANGED", function () {
            initialize();
        });

        $scope.$on("TAB_CHANGED", tabChanged);

        function tabChanged(event, context) {

            if (context.currentViewName == "Meetings") {
                initialize();
            }
        }

        function clearBeforeInitalize() {
            vm.allParticipantsForThisMeeting = [];
            vm.allUsersForThisAsset = [];

            vm.allMeetingLeaders = [];
            vm.allAssigneeList = [];
            addCurrentUserInfoInMeetingLeader();
            vm.isTaskPanelExpanded = false;
            vm.isNotesPanelExpanded = false;
        }

        function collapseLeftPanel() {
            if ($("body", window.parent.document).find("#expandCollapse").hasClass("Collapsed") == false)
                $("body", window.parent.document).find("#expandCollapse").trigger("click");
        }



        vm.removeParticipant = function (user) {

            var index = vm.allParticipantsForThisMeeting.indexOf(user);
            vm.allParticipantsForThisMeeting.splice(index, 1);

            if (user != null && user.UserPrincipal != null && user.UserPrincipal != vm.currentUserInfo.UserPrincipal) {
                var index = vm.allMeetingLeaders.indexOf(user);
                vm.allMeetingLeaders.splice(index, 1);
            }
            //enabling removed users in dropdown
            var raw = vm.multiselectUsers.dataSource.data();
            var length = raw.length;

            // iterate and remove "done" items
            var item, i, isremoved = false;
            for (i = length - 1; i >= 0; i--) {

                item = raw[i];
                if (raw[i].UserPrincipal != "") {
                    if (raw[i].UserPrincipal == user.UserPrincipal) {
                        vm.multiselectUsers.dataSource.remove(item);
                        isremoved = true;
                        item.isAssigned = false;
                        vm.multiselectUsers.dataSource.add(item);

                    }
                }
                else {
                    if (raw[i].EmailID == user.EmailID) {
                        vm.multiselectUsers.dataSource.remove(item);
                        item.isAssigned = false;
                        isremoved = true;
                        vm.multiselectUsers.dataSource.add(item);
                    }
                }

            }
            // if (isremoved == true)
            //   vm.multiselectUsers.dataSource.add(item);
            //for (i = 0; i < vm.allAssigneeList.lenth; i++) {

            //    if (vm.allParticipantsForThisMeeting != null && vm.allParticipantsForThisMeeting.length > 0) {
            //        for (var i = 0 ; i < vm.allParticipantsForThisMeeting.length; i++) {
            //            vm.allParticipantsForThisMeeting[i].IsSelected = $event;
            //        }
            //    }             

            //}
        }

        function checkSecurityAccess(securityOperations) {
           
            var deferred = $q.defer();
            meetingsService.checkAssetAccessForUser(appContext.getAssetName(), securityOperations)
                               .then(function (data) {
                                   if (!utility.isError(data)) {
                                       for (var i = 0; i < data.length; i++) {
                                           if (data[i].Key == "DOTEditMeeting") {
                                               vm.hasEditMeetingPermission = data[i].Value;

                                               if (vm.hasEditMeetingPermission == false) {
                                                   Intuition.ActionBar.HideIcon("MEETINGS_CANCEL");
                                                   Intuition.ActionBar.HideIcon("MEETINGS_SAVE");
                                                   Intuition.ActionBar.HideIcon("MEETINGS_PUBLISH");
                                               }
                                           }
                                       }
                                       deferred.resolve(true);
                                   }
                                   else {
                                       deferred.resolve(false);
                                   }
                               });

            return deferred.promise;
        }

        initialize(); //while on Page Load

        collapseLeftPanel();

    }

})();