﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview Controller for the application shell 
* @author Badrinarayana G.V
*/


(function () {
    'use strict';

    angular
        .module('app.layout.module')
        .controller('ShellController', shell);

    shell.$inject = ['$scope', '$rootScope', '$location', '$timeout', 'config', 'app.common.factory.notificationsFactory'
                    , 'app.common.factory.intuition.intuitionEventsFactory'];

    function shell($scope, $rootScope, $location, $timeout, config, notifications, intuitionEvents) {



        //NG: to remove the default path from browser history and set the overview path.
        //$location.path('#/Home/Index');
        //$location.replace();
        //$location.path('/Instructions');



        angular.element(document).ready(function () {

            //UserPreferences.Ajax.GetUserPreferences([UserPreferences.Keys.Instruction_Asset, UserPreferences.Keys.Instruction_Filters]);

            if (angular.element("body", window.parent.document).find(".OverLayerCustom").length == 0) {
                var overLayerDiv = "<div class='OverLayerCustom' style='position:absolute;height:100%;width:100%;top:0px;left:0px;background-color:grey;opacity:0.3;display:none;'></div>";
                angular.element("body", window.parent.document).append(overLayerDiv);
            }
            if (angular.element("body", window.parent.document).find(".LoadingIconCustom").length == 0) {
                var loadingDiv = "<div class='LoadingIconCustom' style='background-image: url(\"/MES/OpMgmt/UI/WebUI/Content/kendo/Bootstrap/loading-image.gif\");width: 65px;height: 65px;margin-top: -25px;margin-left: -25px;z-index: 90003;display: none;-moz-box-shadow: 0px 0px 10px 2px #888888;-webkit-box-shadow: 0px 0px 10px 2px #888888;box-shadow: 0px 0px 10px 2px #888888;border: 1px solid #c5cbd4;background-color: white;position: fixed;top: 50%;left: 50%;'></div>";
                angular.element("body", window.parent.document).append(loadingDiv);
            }

        });


        var vm = this;
        vm.showLoadingIcon = false;
        vm.title = config.appTitle;

        //when kendo widgets are created, it will fire this event
        $scope.$on("kendoRendered", activate);


        // showing the progress bar
        $rootScope.$on('showLoadingIcon', function ($scope) {
            //vm.showLoadingIcon = true;

            angular.element(".OverLayerCustom", window.parent.document).show();
            angular.element(".LoadingIconCustom", window.parent.document).show();


        });

        //hiding the progress bar
        $rootScope.$on('hideLoadingIcon', function ($rootScope) {
            //vm.showLoadingIcon = false;

            angular.element(".OverLayerCustom", window.parent.document).hide();
            angular.element(".LoadingIconCustom", window.parent.document).hide();

        });

        function activate() {
            console.log("kendoRendered");
            notifications.notifier = vm.notifier;
            notifications.customNotifier = vm.customNotification;
            notifications.setNotificationLocalizedString(); //NG: to set the localized string for notification.            
        };



        //NG: on scope destroy do clean up:
        $scope.$on('$destroy', onScopeDestroy);

        function onScopeDestroy() { }

    }

})();
