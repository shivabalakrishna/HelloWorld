
(function () {
    'use strict';

    angular
      .module('app.layout.module')
      .controller('SplitterController', splitterController);

    splitterController.$inject = ['$scope'];

    function splitterController($scope) {
        var vm = this;

        initialize();

        function initialize() {

            vm.splitterOptions = {
                orientation: "horizontal",
                panes: [{ size: "20%", collapsible: true }, { min: "50%" }, { height: "100%" }]
            };

            $scope.$on("TOGGLE_SPLITTER", function (event, args) {
                if (args.display)
                    vm.splitter.expand(".k-pane:first");
                else
                    vm.splitter.collapse(".k-pane:first");
                vm.hidesplitter = !args.display;
            });

        }
    }

})();
