/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2015
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview Factory service to subscribe for Intuitin Events (time control and ActionBar events).
* @author Badrinarayana G.V
*/

(function () {
    'use strict';

    angular
        .module('app.common.factory.module')
        .factory('app.common.factory.intuition.intuitionEventsFactory', intuitionEvents);

    intuitionEvents.$inject = ['$location', '$rootScope', 'app.common.factory.loggerFactory', 'app.common.appcontext.factory'];

    function intuitionEvents($location, $rootScope, logger, appContext) {
        var logger = logger;
        var assetChanged = false;
        var service = {
            getStartTime: getStartTime,
            getEndTime: getEndTime,
            actionBarItemClicked: actionBarItemClicked,
            refreshTimeValues: refreshTimeValues
        };

        subscribeForEvents();

        return service;

        function getStartTime() {
            return Intuition.QyeryStrings["StartTime"];
            //return "4/1/2013 12:00:00 AM";
        };

        function getEndTime() {
            return Intuition.QyeryStrings["EndTime"];
            // return "4/1/2015 12:00:00 AM";
        };

        function subscribeForEvents() {
            var activeTabName = $("#tabElement", window.parent.document).find(".selected").attr("data-name");
            $("#hdnCurrentTabName").val(activeTabName);

            //Intuition.EventAggregator.clearEvent(Intuition.Events.ActionbarItemClicked);
            Intuition.EventAggregator.subscribe(Intuition.Events.ActionbarItemClicked, actionBarItemClicked);

            //Intuition.EventAggregator.clearEvent(Intuition.Events.TimeControlRegionToViewEvent);
            Intuition.EventAggregator.subscribe(Intuition.Events.TimeControlRegionToViewEvent, onTimeControlChanged);


            Intuition.EventAggregator.subscribe(Intuition.Events.ViewChangedEvent, onTabChanged);


            Intuition.EventAggregator.clearEvent("ON_TREEVIEW_LOAD");
            Intuition.EventAggregator.subscribe("ON_TREEVIEW_LOAD", onAssetSelection);

            Intuition.EventAggregator.clearEvent("ON_TREEVIEW_CLICK");
            Intuition.EventAggregator.subscribe("ON_TREEVIEW_CLICK", onAssetSelection);

            Intuition.EventAggregator.clearEvent("ASSET_SEARCH_CLICK");
            Intuition.EventAggregator.subscribe("ASSET_SEARCH_CLICK", onAssetSelection);

            Intuition.EventAggregator.clearEvent("ON_INBOUND_URL");
            Intuition.EventAggregator.subscribe("ON_INBOUND_URL", onAssetSelection);



        };

        function onTabChanged(context) {
            $rootScope.$broadcast("TAB_CHANGED", context);
        }

        function onTimeControlChanged(args) {

            if (args.OperationMessageStatus != null && args.OperationMessageStatus == "FAIL") {
                //EquipmentHierarchy.Events.ShowErrorMessage("Please select the End Time", "E");
                return;
            }

            var asset = appContext.getAssetName();
            var hierarchy = appContext.getHierarchyName();

            var shiftStartTime = "";
            var shiftEndTime = "";
            var shiftCrew = "";
            var shiftName = "";
            var prevShiftStartTime = "";
            var prevShiftEndTime = "";
            var nextShiftStartTime = "";
            var errorMessage = "";

            if (args.Attributes != null) {
                for (var i = 0; i < args.Attributes.length; i++) {
                    if (args.Attributes[i].Key == "CurrentShiftStartDateTime") {
                        shiftStartTime = args.Attributes[i].Value;
                    }
                    else if (args.Attributes[i].Key == "CurrentShiftEndDateTime") {
                        shiftEndTime = args.Attributes[i].Value;
                    }
                    else if (args.Attributes[i].Key == "CurrentShiftCrew") {
                        shiftCrew = args.Attributes[i].Value;
                    }
                    else if (args.Attributes[i].Key == "PreviousShiftStartDateTime") {
                        prevShiftStartTime = args.Attributes[i].Value;
                    }
                    else if (args.Attributes[i].Key == "PreviousShiftEndDateTime") {
                        prevShiftEndTime = args.Attributes[i].Value;
                    }
                    else if (args.Attributes[i].Key == "ShiftName") {
                        shiftName = args.Attributes[i].Value;
                    }
                    else if (args.Attributes[i].Key == "NextShiftStartDateTime") {
                        nextShiftStartTime = args.Attributes[i].Value;
                    }
                    else if (args.Attributes[i].Key == "Exception") {
                        errorMessage = args.Attributes[i].Value;
                    }
                }
                for (var i = 0; i < parent.globalStorageTimeControl.TaskTimeControl.attributeCollection.length; i++) {
                    if (parent.globalStorageTimeControl.TaskTimeControl.attributeCollection[i].Key == "PreviousShiftStartDateTime")
                        parent.globalStorageTimeControl.TaskTimeControl.attributeCollection[i].Value = prevShiftStartTime;
                    else if (parent.globalStorageTimeControl.TaskTimeControl.attributeCollection[i].Key == "NextShiftStartDateTime")
                        parent.globalStorageTimeControl.TaskTimeControl.attributeCollection[i].Value = nextShiftStartTime;
                }
            }

            //$("#hdnIsShift").val("true");

            if (shiftStartTime == "" && shiftEndTime == "") {
                shiftStartTime = kendo.toString(kendo.parseDate(args.StartDate), "yyyy-MM-dd HH:mm:ss")
                shiftEndTime = kendo.toString(kendo.parseDate(args.EndDate), "yyyy-MM-dd HH:mm:ss");
                if (errorMessage != "" || args.Attributes == null) {
                    //      $("#hdnIsShift").val("false");
                }
            }

            appContext.setStartTime(shiftStartTime);
            appContext.setEndTime(shiftEndTime);

            //$("#hdnAsset").val(EquipmentHierarchy.SELECTED_ASSET_NAME);
            //$("#hdnAssetDisplayName").val(EquipmentHierarchy.SELECTED_ASSET_OBJ.DisplayName)
            //$("#hdnHierarchy").val(EquipmentHierarchy.HIERARCHY_NAME);
            //$("#hdnShiftStartTime").val(shiftStartTime);
            //$("#hdnShiftEndTime").val(shiftEndTime);
            //$("#hdnShiftCrew").val(shiftCrew);
            //$("#hdnShiftName").val(shiftName);
            //$("#hdnPrevShiftStartTime").val(prevShiftStartTime);
            //$("#hdnPrevShiftEndTime").val(prevShiftEndTime);


            //  EquipmentHierarchy.Events.RefreshAll();
            //emit an event to refresh the summary
            setTimeout(function () {
                publishShift();
            }, 100);


        }

        function publishShift() {
            try {
                if (assetChanged == true)
                    $rootScope.$broadcast("ASSET_CHANGED");
                else
                    $rootScope.$broadcast("SHIFT_CHANGED");
                assetChanged = false;
            }
            catch (ex) {
                console.log(ex);
            }
        }


        function onAssetSelection(assetObjString) {
            assetChanged = true;

            var asset = JSON.parse(assetObjString);
            appContext.setAssetInfo(asset);
            $("#hdnAsset").val(appContext.getAssetName());
            $("#hdnHierarchy").val(appContext.getHierarchyName());

            initializeTimeControl(appContext.getNodeId(), angular.element("#hdnShiftDiscipline").val().trim());

            //setting asset name next to time control
            angular.element("#tblConInfo", window.parent.document).css("left", "40%");
            angular.element("#tblConInfo", window.parent.document).css("display", "block");

            angular.element("#tblConInfo", window.parent.document).find("#liCont").html(appContext.getAssetDisplayName());
            angular.element("#tblConInfo", window.parent.document).find("#liCont").attr("title", appContext.getAssetDisplayName());
            angular.element("#tblConInfo", window.parent.document).find("#liCont").css("float", "left");
            angular.element("#tblConInfo", window.parent.document).find("#liCont").css("max-width", "350px");
            angular.element("#tblConInfo", window.parent.document).find("#liCont").css("color", "#101010");
            angular.element("#tblConInfo", window.parent.document).find("#liCont").css("font-weight", "bold");


            // $rootScope.$broadcast("ASSET_SELECTED");
        }

        function refreshTimeValues(args) {
            if (args != null && args.StartDate != null && args.EndDate != null) {

                Intuition.QyeryStrings["StartTime"] = args.StartDate;
                Intuition.QyeryStrings["EndTime"] = args.EndDate;

                logger.info("Start Time is " + Intuition.QyeryStrings["StartTime"], true);
                logger.info("End Time is " + Intuition.QyeryStrings["EndTime"], true);
            }
        };

        function actionBarItemClicked(context) {

            var actionText = "";

            if (context.context.indexOf("<ClassName>MEETINGS_CANCEL</ClassName>") > -1) {
                actionText = "MEETINGS_CANCEL";
            }
            else if (context.context.indexOf("<ClassName>MEETINGS_SAVE</ClassName>") > -1) {
                actionText = "MEETINGS_SAVE";
            }
            else if (context.context.indexOf("<ClassName>MEETINGS_PUBLISH</ClassName>") > -1) {
                actionText = "MEETINGS_PUBLISH";
            }
            else if (context.context.indexOf("<ClassName>TASKS_SAVE</ClassName>") > -1) {
                actionText = "TASKS_SAVE";
            }
            else if (context.context.indexOf("<ClassName>TASK_FILTER</ClassName>") > -1) {
                actionText = "TASK_FILTER";
            }
            else if (context.context.indexOf("<ClassName>TASK_FILTER_APPLIED</ClassName>") > -1) {
                actionText = "TASK_FILTER_APPLIED";
            }

            logger.info(actionText, true);

            $rootScope.$broadcast("Intuition.ActionBarItemClicked", actionText);

        };

        //InitializeTimeControl during the first load
        function initializeTimeControl(nodeId, ShiftDiscipline) {

            var timeCtrlStartTime = "";
            var timeCtrlEndTime = "";

            var timecontrol = Intuition.TimeControl;
            timecontrol.ControlId = "TaskTimeControl";


            var timeControlServices = Intuition.TimeControlService;

            if (timeCtrlStartTime != "" && timeCtrlEndTime != "") {
                timecontrol.DefaultTime.Service.Name = "CoreTimeService";
                timeControlServices.Name = "CoreTimeService";
                timecontrol.DefaultTime.Phrase.OpeningText.Name = timeCtrlStartTime;
                timecontrol.DefaultTime.Phrase.OpeningText.Type = "datetime";
                timecontrol.DefaultTime.Phrase.MiddleText.Name = "to";
                timecontrol.DefaultTime.Phrase.MiddleText.Type = null;
                timecontrol.DefaultTime.Phrase.ClosingText.Name = timeCtrlEndTime;
                timecontrol.DefaultTime.Phrase.ClosingText.Type = "datetime";
            }
            else {
                timecontrol.DefaultTime.Service.Name = "ShiftShiftResource";
                timeControlServices.Name = "ShiftShiftResource";
                timeControlServices.DisplayAttribute = "ShiftName";
                timecontrol.DefaultTime.Phrase.OpeningText.Name = "CurrentShift";
                timecontrol.DefaultTime.Phrase.OpeningText.Type = "Shift";
            }

            timeControlServices.DisplayMode = "OnlyDateTime";
            timecontrol.Services.Service.push(timeControlServices);

            var date = new Date();
            var effectiveTime = kendo.toString(date, "yyyy-MM-dd HH:mm:ss");
            timecontrol.Services.Service.push(timeControlServices);


            timecontrol.Attributes.Attribute = [];
            timecontrol.Attributes.Attribute.push({ "Key": "ResourceId", "Value": nodeId });
            timecontrol.Attributes.Attribute.push({ "Key": "Discipline", "Value": ShiftDiscipline });
            timecontrol.Attributes.Attribute.push({ "Key": "EffectiveTime", "Value": effectiveTime });
            timecontrol.Attributes.Attribute.push({ "Key": "PreviousShiftStartDateTime", "Value": effectiveTime });
            timecontrol.Attributes.Attribute.push({ "Key": "NextShiftStartDateTime", "Value": effectiveTime });

            Intuition.EventAggregator.publish(Intuition.Events.ViewToTimeControlRegionEvent, [timecontrol]);
        };
    };
})();