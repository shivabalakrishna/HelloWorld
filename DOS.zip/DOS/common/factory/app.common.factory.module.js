﻿(function () {
    'use strict';

    angular.module('app.common.factory.module', []);

})();