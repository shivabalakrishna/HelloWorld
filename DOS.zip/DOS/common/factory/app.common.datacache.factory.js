﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/**
* Manage data caches and expire the cache values.
 Author Badrinarayana G.V
*/

(function () {
    'use strict';

    angular
        .module('app.common.factory.module')
        .factory('app.common.factory.dataCacheFactory', dataCache);

    dataCache.$inject = ['$cacheFactory', 'app.common.factory.loggerFactory'];

    function dataCache($cacheFactory, logger) {
        var cacheTimeKey = 'dataCacheExpirationTimeKey';
        var serviceId = 'dosCacheServiceId';
        var service = {
            getCacheData: getCacheData,
            putCacheData: putCacheData,
            createCache: createCache,
            removeCachedItem: removeCachedItem,
        };

        return service;

        /**
        * Factory to create a cache.
        * @param cacheName - Name of cache to be created.
        * @param expireSeconds - Number of seconds before cached value is considered to be stale
        * @return - Returns the created cache.
        */
        function createCache() {
            logger.debug('Inside createCache');
            logger.debug('createCache: creating cacheFactory: ' + serviceId);
            var cache = $cacheFactory(serviceId);
            return cache;
        }

        /**
        * Get a value from a cache.
        * @param cache - Name of cache where the value is stored.
        * @param key - Name of key to resolve the cached value.
        * @returns - Returns the cached value.
        */
        function getCacheData(cache, key) {
            logger.debug('Inside getCacheData & passed key: ' + key);
            var valueRec = cache.get(key);
            if (valueRec === undefined) {
                logger.debug('getCacheData: cacheFactory deos not contain data: ' + valueRec);
                return undefined;
            }
            logger.debug('getCacheData: returning data from cacheFactory valueRec: ' + valueRec);
            return valueRec;
        }

        /**
        * Put a value in a cache.
        * @param cache - The cache where the value will be put.
        * @param key - The key that will resolve the value.
        * @param value - The value to be put/.
        */
        function putCacheData(cache, key, value) {
            logger.debug('Inside putCacheData');
            logger.debug('putCacheData: with cachekey: ' + key + " value: " + value);
            cache.put(key, value === undefined ? null : value);
        }

        /**
        * Removes the item from the cache
        * @param cache - Name of cache where the value is stored.
        * @param key - Name of key to be removed from the cache.
        */
        function removeCachedItem(cache, key) {
            logger.debug('removeCachedItem key: ' + key);
            cache.remove(key);
        }
    }
})();