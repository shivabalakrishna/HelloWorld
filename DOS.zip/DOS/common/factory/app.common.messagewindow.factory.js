﻿//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/**
* Manage notification mesages.
 Author Badrinarayana G.V
*/

(function () {
    'use strict';

    angular
        .module('app.common.factory.module')
        .factory('app.common.factory.messageWindowFactory', messageWindow);

    function messageWindow() {

        var setOptionsOnce = false;
        var service = {
            show: open,
            close: close,
            error: error,
            warning: warning,
            info: info,
            handle: undefined,
            _setOptions: _setOptions,
            setOptions: setOptions
        };

        return service;

        function setOptions() {
            if (setOptionsOnce === false) {
                var options = {
                    visible: false,
                }; 
                service.handle.setOptions(options);
                setOptionsOnce = true;
            }
        }

        function _setOptions(options) {
            service.handle.options.AutoFocus = options ? (options.autoFocus ? options.autoFocus : true) : true;
            service.handle.options.modal = options ? (options.modal ? options.modal : true) : true;          
        };

        function open(title, message, options) {
            service._setOptions(options);
            service.handle.title(title);
            service.handle.content(message);
            service.handle.center();
            service.handle.open();
        };

        function error(message) {
            service._setOptions();
            service.handle.title('Error');
            service.handle.content(message);
            service.handle.center();
            service.handle.open();
        };

        function info(message) {
            service._setOptions();
            service.handle.title('Info');
            service.handle.content(message);
            service.handle.center();
            service.handle.open();
        };

        function warning(message) {
            service._setOptions();
            service.handle.title('Warning');
            service.handle.content(message);
            service.handle.center();
            service.handle.open();
        };
    }
})();