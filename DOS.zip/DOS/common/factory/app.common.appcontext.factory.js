﻿
(function () {
    'use strict';

    angular
      .module('app.common.factory.module')
      .factory('app.common.appcontext.factory', appContext);

    appContext.$inject = ['app.common.utilitiesFactory', 'app.common.factory.loggerFactory'];

    function appContext(utility, logger) {
        var service = {
            getHierarchyName: getHierarchyName,
            getAssetName: getAssetName,
            getAssetDisplayName: getAssetDisplayName,
            getAssetId: getAssetId,
            getStartTime: getStartTime,
            getEndTime: getEndTime,
            setStartTime: setStartTime,
            setEndTime: setEndTime,
            setAssetInfo: setAssetInfo,
            getNodeId: getNodeId,
            getSiteAssetId: getSiteAssetId,
            getGanttHourSpan: getGanttHourSpan,
            setGanttHourSpan: setGanttHourSpan,

            getSiteName: getSiteName,
            getFilters: getFilters,
            setFilters: setFilters,
            getStatus: getStatus,
            setStatus: setStatus,
            getTemplateId: getTemplateId,
            setTemplateId: setTemplateId,
            getIsLimitType: getIsLimitType,
            setIsLimitType: setIsLimitType,
            getStatusDisplayName: getStatusDisplayName,
            setStatusDisplayName: setStatusDisplayName,
            getEditTemplateStatus: getEditTemplateStatus,
            setEditTemplateStatus: setEditTemplateStatus,
            setIsFreshLoad: setIsFreshLoad,
            getIsFreshLoad: getIsFreshLoad,
            setAssetDisplayName: setAssetDisplayName,

            getConfigData: getConfigData,
            setConfigData: setConfigData,
            getUsers: getUsers,
            setUsers: setUsers

        };

        return service;
        ////////////////


        //private variables
        var hierarchyName = '';
        var assetName = '';
        var assetDisplayName = '';
        var nodeId = '';
        var assetId = '';
        var siteAssetId = '';
        var siteName = '';
        var filters = undefined;

        var startTime = '';
        var endTime = '';
        var status = '';
        var templateId = '';
        var isTemplateEdit = false;
        var islimittype = false;
        var statusdisplayname = '';
        var hourSpan = 1;
        var configData = null;
        var userData = null;

        var isFreshLoad = true;
        function getNodeId() {
            return nodeId;
        }

        function setTimeInfo() {

        }

        function setAssetInfo(asset) {
            hierarchyName = asset.HierarchyName;
            assetName = asset.Name;
            assetDisplayName = asset.DisplayName;
            assetId = asset.AssetId;

            nodeId = asset.NodeId;
            siteAssetId = asset.SiteAssetId;
            siteName = asset.SiteAssetName;

            logger.debug(getAssetName());

            parent.Asset = asset;
            parent.updatedAsset = asset;
        }

        function setAssetDisplayName(val) {
            assetDisplayName = val;
        }

        function getAssetName() {
            return assetName;
        }

        function getAssetDisplayName() {
            return assetDisplayName;
        }

        function getAssetId() {
            return assetId;
        }

        function getHierarchyName() {
            return hierarchyName;
        }

        function getSiteAssetId() {
            return siteAssetId;
        }
        function getSiteName() {
            return siteName;
        }
        function setStartTime(startTime) {
            service.startTime = startTime;
            parent.startTime = startTime;
        }

        function setEndTime(endTime) {
            service.endTime = endTime;
            parent.endTime = endTime;
        }

        function getStartTime() {
            return utility.toUTCDate(service.startTime, true);
        }

        function getEndTime() {
            return utility.toUTCDate(service.endTime, true);
        }

        function getStatusDisplayName() {
            return statusdisplayname;
        }

        function setStatusDisplayName(insStatusDisplayName) {
            statusdisplayname = insStatusDisplayName;
        }
        function getStatus() {
            return status;
        }

        function setStatus(insStatus) {
            status = insStatus;
        }
        function getTemplateId() {
            return templateId;
        }

        function setTemplateId(insTemplateId) {
            templateId = insTemplateId;
        }

        function getEditTemplateStatus() {
            return isTemplateEdit;
        }

        function setEditTemplateStatus(isInsTemplateEdit) {
            isTemplateEdit = isInsTemplateEdit;
        }

        function getIsLimitType() {
            return islimittype;
        }

        function setIsLimitType(isInslimittype) {
            islimittype = isInslimittype;
        }
        function getFilters() {
            return service.filters;
        }

        function setFilters(filters) {
            service.filters = filters;
        }

        function setIsFreshLoad(val) {
            isFreshLoad = val;
        }

        function getIsFreshLoad() {
            return isFreshLoad;
        }

        function setGanttHourSpan(hourSpan) {
            this.hourSpan = hourSpan;
        }

        function getGanttHourSpan() {
            return this.hourSpan;
        }

        function getConfigData() {
            return this.configData;
        }

        function setConfigData(configData) {
            this.configData = configData;
        }

        function getUsers() {
            return this.userData;
        }

        function setUsers(userData) {
            this.userData = userData;
        }
    }
})();
