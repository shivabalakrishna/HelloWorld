(function () {
    'use strict';

    angular
        .module('app.common.factory.module')
        .factory('app.common.factory.notificationsFactory', notifications);

    notifications.$inject = ['$translate', 'app.common.factory.loggerFactory'];

    function notifications($translate,logger) {
        var service = {
            error: error,
            info: info,
            success: success,
            warning: warning,
            notifier: undefined,
            customNotifier: undefined,
            customOption: undefined,
            autoHideSetting: undefined,
            setNotificationLocalizedString: setNotificationLocalizedString,
            localizedStrings: []
        };
       
        return service;

        


        function setCustomNotifierOption(hideAfterinSeconds) {
            service.customNotifier.options.position.bottom = 50;
            service.customNotifier.options.position.right = 50;
       
          
           
            service.customNotifier.setOptions({
                show: onShow,
                autoHideAfter: hideAfterinSeconds,
                //hideOnClick: true,

                templates: [{
                    type: "info",
                    template: " <div class='notification'><div class='notificationLeftInfo'><i class='icon-error notifyIconStyle'></i></div><div class='notificationRightInfo'><span class='info'>#= title #</span><span class='k-icon k-i-close k-i-x pull-right' title='Hide'></span><div class='template-message'>#= message #</div></div></div>"
                }, {
                    type: "warning",
                    template: " <div class='notification'><div class='notificationLeftWarn'><i class='icon-error notifyIconStyle'></i></div><div class='notificationRightWarn'><span class='warn'>#= title #</span><span class='k-icon k-i-close k-i-x pull-right' title='Hide'></span><div class='template-message'>#= message #</div></div></div>"
                }, {
                    type: "error",
                    template: " <div class='notification'><div class='notificationLeftError'><i class='icon-error notifyIconStyle'></i></div><div class=' notificationRightError'><span class='error'>#= title #</span><span class='k-icon k-i-close k-i-x pull-right' title='Hide'></span><div class='template-message'>#= message #</div> </div></div>"
                }, {
                    type: "success",
                    template: " <div class='notification'><div class='notificationLeftSuccess'><i class='icon-validate notifyIconStyle'></i></div><div class='notificationRightSuccess'><span class='success'>#= title #</span><span class='k-icon k-i-close k-i-x pull-right' title='Hide'></span><div class='template-message'>#= message #</div></div></div>"


                        
                }]
               
            });
            
        }

        function setNotificationLocalizedString() {
            try {
                $translate(['Success', 'Warning', 'Info', 'An_Error_Occurred'])
					.then(function (translations) {
					    logger.debug('Translations :' + translations);
					    service.localizedStrings = translations;
					});
            }
            catch (err) {
                logger.debug(err);
            }
        }

        function onShow(e) {
            e.element.parent().css({
                zIndex: 22222
            });
        }

        function setOptions() {
            service.notifier.options.position.bottom = 10;
            service.notifier.options.position.right = 20;
            service.notifier.options.autoHideAfter = 0;
         
            service.notifier.setOptions({
                show: onShow,              
              //autoHideAfter: hideAfterinSeconds,
             // hideOnClick: true,
            });
        };

        function error(message, isDefault, isCustom) {
            
            if (isCustom) {
                if (service.customNotifier) {
                    setCustomNotifierOption(0);
                    
                    service.customNotifier.show({
                        title: service.localizedStrings.An_Error_Occurred,
                        message: message
                    }, "error");
                }
            } else if (isDefault) {
                if (service.notifier) {
                    setOptions();
                    service.notifier.error(message);
                }
            }
        };

        function info(message, isDefault, isCustom) {
            if (isCustom) {
                if (service.customNotifier) {
                    setCustomNotifierOption(5000);
                    service.customNotifier.show({
                        title: service.localizedStrings.Info,
                        message: message
                    }, "info");
                }
            } else if (isDefault) {
                if (service.notifier) {
                    setOptions();
                    service.notifier.show(message, 'info');
                }
            }
        };
        
        function success(message, isDefault, isCustom) {
            if (isCustom) {
                if (service.customNotifier) {
                    setCustomNotifierOption(5000);
                    service.customNotifier.show({
                        title: service.localizedStrings.Success,
                        message: message
                    }, "success");
                }
            } else if (isDefault) {
                if (service.notifier) {
                    setOptions();
                    service.notifier.show(message, 'success');
                }
            }

        };

        function warning(message, isDefault, isCustom) {
            if (isCustom) {
                if (service.customNotifier) {
                    setCustomNotifierOption(5000);
                    service.customNotifier.show({
                        title: service.localizedStrings.Warning,
                        message: message
                    }, "warning");
                }
            }
            else if (isDefault) {
                if (service.notifier) {
                    setOptions();
                    service.notifier.show(message, 'warning');
                }
            }
        };

    }
})();