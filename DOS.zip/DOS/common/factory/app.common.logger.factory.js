﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview Logger Factory - Log methods 
* @author Badrinarayana G.V
* 
*/
(function () {
    'use strict';

    angular
        .module('app.common.factory.module')
        .factory('app.common.factory.loggerFactory', logger);

    logger.$inject = ['$log', 'config']; // replace notifications with message


    function logger($log, config) {
        var appPrefix = config.appPrefix || 'None';
        var service = {
            error: error,
            info: info,
            success: success,
            warn: warn,
            debug: debug,
            // straight to console; bypass toastr
            log: $log.log,
            customInfo: customInfo,
            customWarn: customWarn,
            customError: customError,
            customSuccess: customSuccess,
        };

        return service;

        /////////////////////
        // Info logging methods
        /////////////////////

        /**
        * Log an info message
        * @param message - Message text
        * @param showNotifier - Set to true to show the message in a notification
        * @param data - Message data for logging only
        */
        function info(message, showNotifier, data) {
            var logMessage = appPrefix + 'Info: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.info(logMessage);
            //notifications.info(message, showNotifier);
        }

        function customInfo(message, showNotifier, data) {
            var logMessage = appPrefix + 'Info: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.info(logMessage);
            //notifications.info(message, false, showNotifier);
        }

        /////////////////////
        //Success logging methods
        /////////////////////


        /**
        * Log a success message
        * @param message - Message text
        * @param showNotifier - Set to true to show the message in a notification
        * @param data - Message data for logging only
       */
        function success(message, showNotifier, data) {            
            var logMessage = appPrefix + 'Success: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.log(logMessage);
            //notifications.success(message, showNotifier);
        }

        function customSuccess(message, showNotifier, data) {
            var logMessage = appPrefix + 'Success: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.log(logMessage);
            //notifications.success(message, false, showNotifier);
        }



        /////////////////////
        //Warning logging methods
        /////////////////////


        /**
        * Log a warning messsage always showing a user notification
        * @param message - Message text
        * @param data - Message data for logging only
        */
        function warn(message, showNotifier, data) {
            var logMessage = appPrefix + 'Warning: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.warn(logMessage);
            //notifications.warning(message, showNotifier);
        }

        function customWarn(message, showNotifier, data) {
            var logMessage = appPrefix + 'Warning: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.warn(logMessage);
            //notifications.warning(message, false, showNotifier);
        }


        /////////////////////
        //Error logging methods
        /////////////////////


        /**
        * Log an error messsage always showing a user notification
        * @param message - Message text
        * @param data - Message data for logging only
        */
        function error(message, showNotifier, data) {
            var logMessage = appPrefix + 'Error: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.error(logMessage);
            //notifications.error(message, showNotifier);
        }

        function customError(message, showNotifier, data) {
            var logMessage = appPrefix + 'Error: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.error(logMessage);
            //notifications.error(message, false, showNotifier);
        }

        function debug(message, data) {
            var logMessage = appPrefix + 'Debug: ' + message;
            if (data !== undefined) logMessage += ', ' + data;
            $log.debug(logMessage);
        }
    }
}());
