﻿
(function () {
    'use strict';

    angular.module('app.common.utilities.module', []);
})();
