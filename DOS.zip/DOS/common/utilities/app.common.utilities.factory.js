
(function () {
    'use strict';

    angular
      .module('app.common.utilities.module')
      .factory('app.common.utilitiesFactory', utilitiesFactory);

    utilitiesFactory.$inject = ['$window', 'config', 'app.common.factory.loggerFactory', 'app.common.factory.notificationsFactory'];

    function utilitiesFactory($window, config, logger, notification) {
        var service = {
            isError: isError,
            encodeSpecialChars: encodeSpecialChars,
            makePageDirty: makePageDirty,
            isPageDirty: isPageDirty,
            clearPageDirty: clearPageDirty,
            encodeScriptTags: encodeScriptTags,
            toUTCDate: toUTCDate,
            toLocalDate: toLocalDate,
            toLocalDateFormat: toLocalDateFormat,
            toLocalDateWithoutMinutes: toLocalDateWithoutMinutes,
            convertDateStringtoDate: convertDateStringtoDate,
            getCustomDateTimeFormat: getCustomDateTimeFormat,
            getCustomDateFormat: getCustomDateFormat,
            HtmlEncode: HtmlEncode,
            HtmlDecode: HtmlDecode,
            focusControl: focusControl,
            getStatementForCornExporession: getStatementForCornExporession
        };

        return service;

        function isError(dataResult) {
            var isErrorMessage = false;
            var errorMessage = "";

            try {
                if (dataResult.indexOf("Error:") > -1) {
                    errorMessage = dataResult.replace("Error:", "");
                    notification.error(errorMessage, false, true);
                    isErrorMessage = true;
                }
            }
            catch (err) {
                if (err.message == "Object #<Object> has no method 'indexOf'") {
                    isErrorMessage = false;
                    logger.error(err.message);
                }
            }

            if (isErrorMessage)
                logger.error(errorMessage);
            return isErrorMessage;
        }

        function encodeSpecialChars(str) {
            if (str != null) {
                if ((typeof str) == "string")// displays "string"
                {
                    str = str.replace(/</g, '&#60;'); // replace <
                    str = str.replace(/>/g, '&#62;'); // replace >

                    return str.replace(/'/g, '&#39;'); // replace '
                }
                else
                    return str;
            }
            else {
                return "";
            }
        }

        function encodeScriptTags(str) {
            if (str != null) {
                if ((typeof str) == "string")// displays "string"
                {
                    str = str.replace(/<script>/g, '&#60;script&#62;'); // <script> 
                    str = str.replace(/<\/script>/g, '&#60;/script&#62;'); // <script> 
                    return str;
                }
                else
                    return str;
            }
            else {
                return "";
            }
        }

        function HtmlEncode(value) {
            //create a in-memory div, set it's inner text(which jQuery automatically encodes)
            //then grab the encoded contents back out.  The div never exists on the page.\
            value = encodeScriptTags(value);
            return $('<div/>').text(value).html();
        }

        function HtmlDecode(value) {
            return $('<div/>').html(value).text();
        }
        //Below function will return the limisted characters to display
        function GetLimitedCharacters(str) {
            if (str != null)
                return str.length > 30 ? str.substring(0, 30) + "..." : str;
            else
                return "";
        };

        //start for dirty page
        function makePageDirty() {
            angular.element("body").attr("isDirty", "true");
            //BindUnloadEvent();
        }

        function clearPageDirty() {
            angular.element("body").attr("isDirty", "false");
            var isDirty = isPageDirty();
            //if (!isDirty)
            //    UnBindUnloadEvent();
        }

        function isPageDirty() {
            try {
                var isDirty = false;
                if (angular.element("#htmlControlHost", window.parent.document).is(':visible')) {
                    angular.element("#content", window.parent.document).find("iframe").each(function () {
                        if (isDirty == null || isDirty == false) {
                            var tabName = angular.element(this).attr("data-name");
                            if (tabName == "Tasks") {
                                isDirty = angular.element(this).contents().find("body").attr("isDirty");
                                if (isDirty == null || isDirty == "false")
                                    isDirty = false;
                                else
                                    isDirty = true;
                            }
                        }
                    });
                }
                return isDirty;
            }
            catch (err) {
                return false;
            }
        }

        //private methods       

        //function BindUnloadEvent() {
        //    angular.element(window).unbind('beforeunload');
        //    angular.element(window).bind('beforeunload', function () {
        //        var isDirty = isPageDirty();
        //        if (isDirty)
        //            return 'All unsaved chnages will be lost. Do you want to proceed without saving ?';
        //    });
        //}

        //function UnBindUnloadEvent() {
        //    angular.element(window).unbind('beforeunload');
        //}

        //end for dirty page


        //start of utc and local date conversion
        //takes input as datestring in g or another specified format, returns the date in utc string of format "yyyy-MM-dd HH:mm:ss" (stored like this irrespective of culture)
        function toUTCDate(dateString, isDisplayFormat) {

            if (dateString) {
                var date = ''
                if (!isDisplayFormat)
                    date = kendo.parseDate(dateString, getCustomDateTimeFormat());
                else {
                    date = new Date(dateString);

                    if (date == "Invalid Date") { // to make it work in ie, date conversions handled differently in IE
                        dateString = dateString.replace(" ", "T");
                        date = new Date(dateString);
                    }
                }
                ////var utcDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());            
                return date.getUTCFullYear() + "-" + ("0" + (parseInt(date.getUTCMonth()) + 1)).slice(-2) + "-" + ("0" + date.getUTCDate()).slice(-2) + " " + ("0" + date.getUTCHours()).slice(-2) + ":" + ("0" + date.getUTCMinutes()).slice(-2) + ":" + ("0" + date.getUTCSeconds()).slice(-2);
            }
            return null;
        }

        //takes input utc date string  "yyyy-MM-dd HH:mm:ss" and returns local date in "g" format for dipslay purpose
        function toLocalDate(utcString) {
            if (utcString) {

                var dateTimeArray = utcString.split(" ");

                var dateArray = dateTimeArray[0].split("-");
                var timeArray = dateTimeArray[1].split(":");

                var utcDate = new Date(dateArray[0], dateArray[1] - 1, dateArray[2], timeArray[0], timeArray[1], timeArray[2]);
                var offset = utcDate.getTimezoneOffset() * 60000;
                utcDate.setTime(utcDate.getTime() - offset);


                var customDateTimeFormat = getCustomDateTimeFormat();
                return kendo.toString(utcDate, customDateTimeFormat);

            }
            return null;
        }


        function toLocalDateFormat(utcString) {
            if (utcString) {

                var dateTimeArray = utcString.split(" ");

                var dateArray = dateTimeArray[0].split("-");
                var timeArray = dateTimeArray[1].split(":");

                var utcDate = new Date(dateArray[0], dateArray[1] - 1, dateArray[2], timeArray[0], timeArray[1], timeArray[2]);
                var offset = utcDate.getTimezoneOffset() * 60000;
                utcDate.setTime(utcDate.getTime() - offset);

                return utcDate;

            }
            return null;
        }

        function getCustomDateTimeFormat() {
            var customDateTimeFormat = angular.element("#CustomDateTimeFormat").val();
            if (customDateTimeFormat != null && customDateTimeFormat != "")
                return customDateTimeFormat;
            else
                return "g";
        }

        function getCustomDateFormat() {
            var customDateFormat = angular.element("#CustomDateFormat").val();
            if (customDateFormat != null && customDateFormat != "")
                return customDateFormat;
            else
                return "d";
        }


        function toLocalDateWithoutMinutes(utcString) {
            if (utcString) {

                var dateTimeArray = utcString.split(" ");

                var dateArray = dateTimeArray[0].split("-");
                var timeArray = dateTimeArray[1].split(":");

                var utcDate = new Date(dateArray[0], dateArray[1] - 1, dateArray[2], timeArray[0], timeArray[1], timeArray[2]);
                var offset = utcDate.getTimezoneOffset() * 60000;
                utcDate.setTime(utcDate.getTime() - offset);

                utcDate.setHours(utcDate.getHours(), 0, 0);

                return kendo.toString(utcDate, getCustomDateTimeFormat());
            }
            return null;
        }


        function convertDateStringtoDate(dateString) {

            if (dateString) {
                var dateTimeArray = dateString.split(" ");

                var dateArray = dateTimeArray[0].split("-");
                var timeArray = dateTimeArray[1].split(":");
                var date = new Date(dateArray[0], dateArray[1] - 1, dateArray[2], timeArray[0], timeArray[1], timeArray[2]);

                return date;
            }

        }

        function focusControl(controlId, controlType) {

            if (controlId != null) {

                if (controlType == "kendoDropDownList" || controlType == "kendoComboBox" || controlType == "kendoNumericTextBox" || controlType == "kendoMultiSelect" || controlType == "kendoEditor") {
                    var kendoControl = $("#" + controlId).data(controlType);
                    if (kendoControl != null) {
                        setTimeout(function () {
                            kendoControl.focus();
                        }, 100);
                    }
                }
                else {
                    setTimeout(function () {
                        var itemCount = $("#" + controlId).length;
                        if (itemCount > 0)
                            $("#" + controlId).focus();
                    }, 100);
                }
            }
        }



        function getStatementForCornExporession(expression) {

            var statement = "";

            var weekNumberToWord =
            {
                "#1": "First",
                "#2": "Second",
                "#3": "Third",
                "#4": "Fourth",
                "L": "Last"
            };

            var dayShortToDayLong =
                {
                    "MON": "Monday",
                    "TUE": "Tuesday",
                    "WED": "Wednesday",
                    "THU": "Thursday",
                    "FRI": "Friday",
                    "SAT": "Saturday",
                    "SUN": "Sunday",
                };



            if (expression != null && expression != "") {
                var expressionArray = expression.split(" ");
                var minutes = expressionArray[0];
                var hour = expressionArray[1];
                var day = expressionArray[2];
                var month = expressionArray[3];
                var week = expressionArray[4];

                var patternType = "";

                if (week == "*" && month == "*") {
                    statement = "Occurs every " + day.split("/")[1] + " day(s)";
                }
                else if (week == "MON-FRI") {
                    statement = "Occurs every weekdays";
                }
                else if (month == "*" && day == "*") {
                    var days = "";
                    var weeks = week.split(",");
                    if (weeks.length > 0) {
                        for (var i = 0 ; i < weeks.length; i++) {
                            if (days != "") {
                                days += ", ";
                            }
                            days += dayShortToDayLong[weeks[i]];
                        }
                    }
                    statement = "Occurs weekly on " + days;
                }
                else if (week == "*" && month.indexOf("/") > 0) {
                    month = month.split("/")[1];
                    statement = "Occurs monthly on day " + day + " of every " + month + " months";
                }
                else if (month.indexOf("/") > 0 && day == "*") {

                    month = month.split("/")[1];
                    var dayNumber = week.substring(0, 3);
                    var weekNumber = week.substring(3, 5);
                    statement = "Occurs monthly on the " + weekNumberToWord[weekNumber] + " " + dayShortToDayLong[dayNumber] + " of every " + month + " month(s)";
                }
                else {

                    if (day == "*") {
                        var monthName = kendo.cultures.current.calendar.months[[month - 1]];
                        var dayNumber = week.substring(0, 3);
                        var weekNumber = week.substring(3, 5);
                        statement = "Occurs yearly on the " + weekNumberToWord[weekNumber] + " " + dayShortToDayLong[dayNumber] + " of " + monthName;
                        //Occurs yearly on the first Monday of Jan

                    }
                    else {
                        var monthName = kendo.cultures.current.calendar.months[[month - 1]];
                        statement = "Occurs yearly on " + monthName + " " + day;
                        //Occurs yearly on Jan 3
                    }
                }
            }
            return statement;
        }

        //end of utc and local date conversion
    }
})();

