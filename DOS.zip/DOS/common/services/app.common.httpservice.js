﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview data service for server calls. 
* @author Badrinarayana G.V
*/
(function () {
    'use strict';

    angular
        .module('app.common.service.module')
        .run(['$http', function ($http) {
            $http.defaults.headers.common['RequestVerificationToken'] = angular.element("body").attr('ncg-request-verification-token');
        }])
        .service('app.common.httpService', dataService);


    dataService.$inject = ['$rootScope', '$http', '$q', 'app.common.factory.loggerFactory', 'app.common.factory.dataCacheFactory', 'app.common.utilitiesFactory'];

    function dataService($rootScope, $http, $q, logger, dataCache, utility) {
        var asyncCallsCount = 0;
        return {
            //  setConfig: setConfiguration,
            settings: {},
            createCache: createCache,
            getData: getData,
            postData: postData,
            postFiles: postFiles,
            createTask: createTask,
            deleteTask: deleteTask,
            clearCache: clearCache,
            getFileData: getFileData,
            uploadFiles: uploadFiles
        };

       

        function createCache() {
            logger.debug("Inside createCache");
            logger.debug('createCache: before Calling  createCache');
            this.settings.cache = dataCache.createCache();
            logger.debug('createCache: after Calling  createCache');

        }

        function clearCache(cacheKey) {
            if (this.settings.cache !== undefined) {
                dataCache.removeCachedItem(this.settings.cache, cacheKey);
            }
        }

        function getData(url, options) {
            logger.debug('Inside getData');
            var defer = $q.defer();


            if (options && options.useCache && options.useCache == true) {
                logger.debug('getData: useCache: ' + options.useCache);
                if (this.settings.cache == undefined) {
                    logger.debug('getData: before calling createCache');
                    this.createCache();
                    logger.debug('getData: after calling createCache');

                }
                // Check if data is available in cache
                logger.debug("getData: before calling getCacheData with cachekey: " + options.cacheKey);
                var valueRec = dataCache.getCacheData(this.settings.cache, options.cacheKey);
                logger.debug("getData: after calling getCacheData valueRec set to: " + valueRec);

                if (valueRec !== undefined) {
                    logger.debug('getData: returning data from cache for cachekey ' + options.cacheKey);
                    defer.resolve(valueRec);
                }
                else {
                    var self = this;
                    $http({
                        method: "GET",
                        url: url,
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        params: options.params
                    })
                        .success(function (res) {
                            logger.debug('getData: before calling putCacheDate with key: ' + options.cacheKey);
                            dataCache.putCacheData(self.settings.cache, options.cacheKey, res);
                            logger.debug('getData: after calling putCacheDate with key: ' + options.cacheKey);
                            defer.resolve(res);
                            logger.debug('getData: returning data from service');
                        })
                        .error(function (error, status, headers, config) {
                            logger.error(status + ' ' + error, true);
                            defer.reject(error, status, headers, config);

                        });
                }
            } else {
                if (asyncCallsCount == 0)
                    $rootScope.$emit("showLoadingIcon");
                ++asyncCallsCount;
                $http({
                    method: "GET",
                    url: url,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    params: options.params
                }).then(function successCallback(response) {
                    defer.resolve(response.data);
                    --asyncCallsCount;
                    if (asyncCallsCount == 0)
                        $rootScope.$emit("hideLoadingIcon");
                    logger.debug('getData: returning data from webapi');
                }, function errorCallback(response) {
                    --asyncCallsCount;
                    if (asyncCallsCount == 0)
                        $rootScope.$emit("hideLoadingIcon");
                    logger.error(status + ' ' + error);
                    defer.reject(response);
                });
            }

            return defer.promise;
        }

        function postData(url, data) {
            var defer = $q.defer();
            if (asyncCallsCount == 0)
                $rootScope.$emit("showLoadingIcon");
            ++asyncCallsCount;

            $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            }).then(function successCallback(response) {
                --asyncCallsCount;
                if (asyncCallsCount == 0)
                    $rootScope.$emit("hideLoadingIcon");
                logger.info('Data posted successfully');
                defer.resolve(response.data);
            }, function errorCallback(response) {
                --asyncCallsCount;
                if (asyncCallsCount == 0)
                    $rootScope.$emit("hideLoadingIcon");
                logger.error('Error in posting data');
                defer.reject(response);
            });
            return defer.promise;
        }

        function postFiles(url, toSendData) {
            var defer = $q.defer();
            var fileItem = toSendData.file;
            $http({
                method: 'POST',
                url: url,
                headers: { 'Content-Type': 'application/octet-stream' },//http://byterot.blogspot.in/2012/04/aspnet-web-api-series-part-5.html,http://stackoverflow.com/questions/22447952/angularjs-http-post-convert-binary-to-excel-file-and-download
                data: fileItem,
                processData: false,
                //responseType: 'arraybuffer',
                //transformRequest: function (data) {  //Do this to convert our data to FormData
                //    var formData = new FormData();
                //    formData.append("file", data);
                //    formData.append("fileName",data.name)
                //    formData.append("verifyData", toSendData.verify);
                //    formData.append("assestsOnly", toSendData.assetsOnly);
                //    formData.append("projectOnly", toSendData.projectOnly);
                //    formData.append("entireData", toSendData.entireData);
                //    return formData;
                //},
                params: { verifyData: toSendData.verify, fileName: fileItem.name },

            }).then(function successCallback(res) {
                logger.info('Data posted successfully');
                defer.resolve(res);
            }, function errorCallback(err, status) {
                logger.error(' Error in posting data');
                defer.reject(err);
            });
            fileItem = null;
            return defer.promise;
        }

        function uploadFiles(url, files, filesList, taskId) {
            if (asyncCallsCount == 0)
                $rootScope.$emit("showLoadingIcon");
            ++asyncCallsCount;
            if (files.length > 0) {
                if (window.FormData !== undefined) {
                    var data = new FormData();
                    for (var x = 0; x < files.length; x++) {
                        var result = filesList[files[x].name];
                        result.isStarted = true;
                        data.append(files[x].name, files[x]);
                    }
                    data.append("TaskId", taskId);
                    //data.append("uniqueId", uniqueId);
                }
            }
            var defer = $q.defer();
            $http({
                method: 'POST',
                url: url,
                data: data,
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }).then(function successCallback(res) {
                --asyncCallsCount;
                if (asyncCallsCount == 0)
                    $rootScope.$emit("hideLoadingIcon");
                logger.info('Data posted successfully');
                defer.resolve(res);
            }, function errorCallback(err, status) {
                --asyncCallsCount;
                if (asyncCallsCount == 0)
                    $rootScope.$emit("hideLoadingIcon");
                logger.error(' Error in posting data');
                defer.reject(err);
            });
            return defer.promise;
        }


        ///This method is used get the file data from the server and download it into client.  
        //http://stackoverflow.com/questions/26005687/uploading-downloading-byte-arrays-with-angularjs-and-asp-net-web-api
        //http://stackoverflow.com/questions/24080018/download-file-from-a-asp-net-web-api-method-using-angularjs

        function getFileData(url, options) {
            var defer = $q.defer();
            var date = new Date();
            var fileName = "PSADownLoad.xlsx";
            if (options.params.fileName && options.params.fileName.indexOf(".xlsx") > -1) {
                fileName = options.params.fileName;
            }
            $http({
                method: 'GET',
                url: url,
                headers: { 'Content-Type': 'application/octet-stream' },
                responseType: 'arraybuffer',
                params: options.params,
            })
            .success(function (res) {
                var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                var success = false;
                var unsigned8Int = new Uint8Array(res);
                try {
                    // Try using msSaveBlob if supported
                    logger.info("Trying saveBlob method ...");
                    var blob = new Blob([unsigned8Int], { type: contentType });
                    if (navigator.msSaveBlob) {
                        navigator.msSaveBlob(blob, fileName);
                        success = true;
                    }
                    else {
                        // Try using other saveBlob implementations, if available
                        var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
                        if (saveBlob != undefined) {
                            saveBlob(blob, fileName);
                            logger.info("saveBlob succeeded");
                            success = true;
                        }
                    }

                } catch (ex) {
                    logger.error("saveBlob method failed with the following exception:");
                    logger.error(ex);
                }

                if (!success) {
                    // Get the blob url creator
                    var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
                    if (urlCreator) {
                        // Try to use a download link
                        var link = document.createElement('a');
                        if ('download' in link) {
                            // Try to simulate a click
                            try {
                                // Prepare a blob URL
                                logger.info("Trying download link method with simulated click ...");
                                var blob = new Blob([unsigned8Int], { type: contentType });
                                var url = urlCreator.createObjectURL(blob);
                                link.setAttribute('href', url);

                                // Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
                                link.setAttribute("download", fileName);

                                // Simulate clicking the download link
                                var event = document.createEvent('MouseEvents');
                                event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
                                link.dispatchEvent(event);
                                logger.info("Download link method with simulated click succeeded");
                                success = true;

                            } catch (ex) {
                                logger.error("Download link method with simulated click failed with the following exception:");
                                logger.error(ex);
                            }
                        }

                        if (!success) {
                            // Fallback to window.location method
                            try {
                                // Prepare a blob URL
                                // Use application/octet-stream when using window.location to force download
                                logger.info("Trying download link method with window.location ...");
                                var blob = new Blob([unsigned8Int], { type: contentType });
                                var url = urlCreator.createObjectURL(blob);
                                window.location = url;
                                logger.info("Download link method with window.location succeeded");
                                success = true;
                            } catch (ex) {
                                logger.error("Download link method with window.location failed with the following exception:");
                                logger.error(ex);
                            }
                        }
                        logger.info('Data posted successfully');

                    }
                }

                if (!success) {
                    // Fallback to window.open method
                    logger.info("No methods worked for saving the arraybuffer, using last resort window.open");
                    window.open(httpPath, '_blank', '');
                }
                defer.resolve(res);
            })
            .error(function (err, status) {
                logger.error(' Error in posting data');
                defer.reject(err);
            });
            return defer.promise;
        }


        function createTask(task) {
            var defer = $q.defer();


            $http.post('api/TestWebApi', task)
                .success(function (res) {
                    defer.resolve(res);
                })
                .error(function (err, status) {
                    defer.reject(err);
                });

            return defer.promise;
        }

        function deleteTask(id) {
            var defer = $q.defer();


            $http.delete('api/TaskWebApi?taskid=' + id)
                .success(function (res) {
                    defer.resolve(res);
                })
                .error(function (err, status) {
                    defer.reject(err);
                });

            return defer.promise;
        }

    };
})();


