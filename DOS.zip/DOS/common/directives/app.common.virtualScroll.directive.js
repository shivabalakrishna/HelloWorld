﻿

(function () {
    'use strict';

    angular.module('app.common.directives.module')
   .directive('virtualScroll', function () {
       return {
           restrict: 'A',
           scope: {
               scroll: '&scrollCallback',
               totalcount: "=totalcount",
               displayedcount: "=displayedcount"
           },
           link: function (scope, element, attrs) {
               element.on('scroll', function () {
                   scope.$apply(function () {
                       if ($(element).scrollTop() + $(element).innerHeight() >= $(element)[0].scrollHeight) {
                           if ($(element).scrollTop() + $(element).innerHeight() == $(element)[0].scrollHeight) {
                               if (scope.displayedcount != scope.totalcount) {
                                   $(element).scrollTop($(element).scrollTop() - 10);
                                   scope.scroll();
                               }
                           }                        
                       }
                   });

               });
           }
       };
   })

})();