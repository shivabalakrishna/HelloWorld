﻿(function () {
    'use strict';

    angular
        .module('app.common.directives.module')
        .directive('validDate', dateValidation);

    dateValidation.$inject = ['$window','app.common.utilitiesFactory'];

    function dateValidation($window, utility) {
        // Usage:
        //     <hds_dateValidation></hds_dateValidation>
        // Creates:
        // 
        var directive = {
            link: link,
            require: 'ngModel',
            restrict: 'A'
        };
        return directive;

        function link(scope, element, attrs, control) {
            control.$parsers.push(function (viewValue) {              
                var newDate = control.$viewValue;
                control.$setValidity("invalidDate", true);
                if (typeof newDate === "object" || newDate == "") return newDate;  // pass through if we clicked date from popup
                var d = kendo.parseDate(newDate, utility.getCustomDateTimeFormat());
                if (Object.prototype.toString.call(d) === "[object Date]") {
                    // it is a date
                    if (isNaN(d.getTime())) {  // d.valueOf() could also work
                        control.$setValidity("invalidDate", false);
                    }
                    else {
                        // date is valid
                    }
                }
                else {
                    control.$setValidity("invalidDate", false);
                }
                return viewValue;
            });
        }
    }

})();
