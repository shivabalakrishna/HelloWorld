﻿

(function () {
    'use strict';

    angular.module('app.common.directives.module')
   .directive('clickOutside', function ($document) {
       return {
           restrict: 'A',
           scope: {
               toggleContainer: '=showHide',
               overLayer: '=overLayer'
           },
           link: function (scope, el, attr) {

               $document.on('click', function (e) {
                   if (el !== e.target && !el[0].contains(e.target) && !(e.target.className.indexOf("k-") > -1) && !($(e.target).hasClass("enable"))) {
                       scope.$apply(function () {
                           scope.toggleContainer = false;
                           scope.overLayer = false;
                       });
                   }
               });
           }
       };
   })

})();



