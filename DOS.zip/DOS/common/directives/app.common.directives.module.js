﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2015
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview Directives module 
* @author Mike Witt 
*/
(function () {
    'use strict';

    angular.module('app.common.directives.module', []);
})();