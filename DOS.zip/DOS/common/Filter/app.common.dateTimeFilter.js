﻿/////////////////////////////////////////////////////////////////////////
// 			    COPYRIGHT (c) 2016
//			HONEYWELL INTERNATIONAL INC.
// 			    ALL RIGHTS RESERVED
// Legal rights of Honeywell International Inc. in this software 
// is distinct from ownership of any medium in which the 
// software is embodied.  Copyright notices must be reproduced in 
// any copies authorized by Honeywell International Inc.

/** 
* @fileOverview Common DateTime Filter to convert date or object parameter into the local date time format.
* @author Badrinarayana G V
*/


(function () {
    'use strict';

    angular.module('app.common.filter.module')
        .filter('dateTimeFilter', dateTimeFilter);


    function dateTimeFilter() {
        return function (input) {            
            var parsedDate = Date.parse(input);
            if (isNaN(parsedDate)) {
                return input;
            }
            var newObject = JSON.parse(JSON.stringify(input));
            var t = kendo.parseDate(newObject);

            var offset = t.getTimezoneOffset() * 60000;

            t.setTime(t.getTime() - offset);

            return kendo.parseDate(new Date(t), "g");

        };
    }

    angular.module('app.common.filter.module')
       .filter('dateTimeFilterToString', dateTimeFilterToString);

    function dateTimeFilterToString() {
        return function (input) {
            var parsedDate = Date.parse(input);
            if (isNaN(parsedDate)) {
                return input;
            }
            var newObject = JSON.parse(JSON.stringify(input));
            var t = kendo.parseDate(newObject);

            var offset = t.getTimezoneOffset() * 60000;

            t.setTime(t.getTime() - offset);

            return kendo.toString(new Date(t), "g");

        };
    }

})();
